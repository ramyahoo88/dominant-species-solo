const fs = require('node:fs');
const path = require('node:path');
const assert = require('node:assert/strict');
const {inlineLoad} = require('./inline-load.cjs');

const repo = path.resolve(process.argv[2] ?? path.join(__dirname, '../../dominant-species-solo'));
const {PLAYER_REFERENCE} = require(path.join(repo, 'source/benchmark/load.cjs'));
const {playerPlacement,playerChoice} = inlineLoad(repo, PLAYER_REFERENCE, ['player'],
  'return {playerPlacement,playerChoice};');
const strategy = {place:playerPlacement,choose:playerChoice};
const runtime = inlineLoad(repo, 'worktree', ['game'], `
  Object.assign(PAPER,{place:true,all:true,extraAP:0});
  let differences = [];
  const original = runStep;
  runStep = (s,step,choice) => {
    if (step.kind === 'extinction' && step.actor === 'mammals' && s.human !== 'mammals') {
      const candidates = extinctionOptions(s,'mammals');
      const ordered = pBy(candidates,tile => pFirstVP(s,tile));
      if (choice.saved && choice.saved !== ordered) {
        const printed = copy(s);
        original(printed,step,{saved:ordered});
        const actual = copy(s);
        original(actual,step,choice);
        const rows = [actual,printed].map(state => {
          const entry = state.log.findLast(x => x.title === 'Extinction and Survival');
          return {line:entry.body,remaining:occupied(state,'mammals')};
        });
        differences.push({turn:s.turn,actual:choice.saved,printed:ordered,rows,
          candidates,fixture:{format:SAVE_KEY,game:copy(s)}});
      }
    }
    return original(s,step,choice);
  };
  return {play:playBenchmark, take:() => differences.splice(0)};
`);
const subjects = ['birds','reptiles','insects','arachnids','amphibians'];
const animals = ['mammals',...subjects];
let found = null;
let checked = 0;
for (let index = 0; index < 120; index++) {
  const human = subjects[index % subjects.length];
  const setup = {human,rivals:animals.filter(a => a !== human), seed:960000 + index,
    short:index % 2 === 0, policy:['dominance','majority','expansion'][Math.floor(index / subjects.length) % 3]};
  const game = runtime.play(setup, strategy);
  const [first] = runtime.take();
  checked++;
  assert(!game.stalled);
  if (first) {
    const {fixture,...difference} = first;
    found = {setup,difference,checked};
    fs.writeFileSync(path.join(__dirname,'../saves/mammals-extinction-played.json'), JSON.stringify(fixture)+'\n');
    break;
  }
}
fs.writeFileSync(path.join(__dirname,'extinction-search.json'),JSON.stringify({checked,found},null,2)+'\n');
console.log(JSON.stringify({checked,found},null,2));
