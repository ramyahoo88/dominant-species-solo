const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');

const repo = path.resolve(process.argv[2] ?? path.join(__dirname, '../dominant-species-solo'));
const {load} = require(path.join(repo, 'source/benchmark/load.cjs'));
const runtime = load('worktree');
const test = name => JSON.parse(fs.readFileSync(path.join(__dirname,'saves',name+'.json'),'utf8')).game;
const fixture = test('mammals-extinction-tie');
const played = test('mammals-extinction-played');
Object.assign(runtime.get('globalThis'), {assert, fixture, played});

const summary = runtime.run(`(() => {
  const released = botAction;
  // Exercise the proposed Paper-only dispatch in memory.
  botAction = (s, step) => step.kind === 'extinction' && step.actor && s.paperRivals?.includes(step.actor)
    ? {saved:pBy(extinctionOptions(s,step.actor),t => pFirstVP(s,t)) ?? null}
    : released(s,step);
  const test = (s, previous, expected) => {
    validateState(s);
    const step = nextStep(s);
    assert.equal(released(s,step).saved,previous);
    const choice = botAction(s,step);
    assert.equal(choice.saved,expected);
    runStep(s,step,choice);
    validateState(s);
    return {saved:choice.saved,vp:s.animals.mammals.vp};
  };
  const controlled = test(copy(fixture),'D3','C3');
  assert.equal(controlled.vp,3);
  const seeded = test(copy(played),'C2','B2');
  const app = copy(fixture);
  delete app.paper;
  delete app.paperRivals;
  assert.equal(botAction(app,nextStep(app)).saved,'D3');
  return {controlled,seeded,app:'D3'};
})()`);
console.log(JSON.stringify(summary, null, 2));

const replay = load('worktree',['game']);
const {PLAYER_REFERENCE} = require(path.join(repo, 'source/benchmark/load.cjs'));
const player = load(PLAYER_REFERENCE,['player']);
const strategy = {place:player.get('playerPlacement'),choose:player.get('playerChoice')};
const natural = JSON.parse(fs.readFileSync(path.join(__dirname,'benchmarks/extinction-search.json'),'utf8')).found.setup;
replay.run('Object.assign(PAPER,{place:true,all:true,extraAP:0})');
const before = replay.get('playBenchmark')(natural,strategy);
replay.run(`
  const extinctionOriginalBotAction = botAction;
  botAction = (s,step) => step.kind === 'extinction' && step.actor && s.paperRivals?.includes(step.actor)
    ? {saved:pBy(extinctionOptions(s,step.actor),t => pFirstVP(s,t)) ?? null}
    : extinctionOriginalBotAction(s,step);
`);
const after = replay.get('playBenchmark')(natural,strategy);
const summaryFor = game => ({turns:game.turns,winner:game.winner,humanMargin:game.humanMargin,stalled:!!game.stalled,
  vp:Object.fromEntries(Object.entries(game.seats).map(([animal,row]) => [animal,row.vp]))});
assert.equal(before.openingSupply,after.openingSupply);
const matched = {seed:natural.seed,release:summaryFor(before),proposal:summaryFor(after)};
fs.writeFileSync(path.join(__dirname,'benchmarks/extinction-matched.json'),JSON.stringify(matched,null,2)+'\n');
console.log(JSON.stringify(matched,null,2));
