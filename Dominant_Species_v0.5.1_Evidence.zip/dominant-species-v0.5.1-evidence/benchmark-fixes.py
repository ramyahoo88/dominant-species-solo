"""Independent positive and negative reproductions for v0.5.0 findings B1/B2."""
import json
import subprocess
import sys
from pathlib import Path

root=Path(__file__).resolve().parent
repo=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else root.parent/'dominant-species-audit-v051'
bench=repo/'source/benchmark.cjs'
helper=repo/'source/benchmark/balance/final_eval.py'
results=[]
base=['node',str(bench),'--evaluate','--per-cell','2','--policies','dominance','--workers','1']
for name,options,message in [
    ('count-repeat',['--bots','3,3','--modes=m2'],'Rival count listed twice'),
    ('mode-alias',['--bots','3','--modes=m2,-2'],'Rival table listed twice'),
    ('mode-app-repeat',['--bots','3','--modes=app,app'],'Rival table listed twice'),
]:
    run=subprocess.run(base+options,text=True,capture_output=True)
    assert run.returncode and message in run.stderr and not run.stdout
    results.append(dict(case=name,exit=run.returncode,error=message))

run=subprocess.run(base+['--bots','3','--modes=m2'],check=True,text=True,capture_output=True)
good=json.loads(run.stdout)
assert len(good['table'])==1 and good['table'][0]['rivalsAre']=='Easy' and good['table'][0]['extraPawns']==-2
assert good['pooled']['Easy']['dominance']['games']==2
assert good['pooled']['Easy']['dominance']['wins']==1
results.append(dict(case='distinct',result=good['pooled']['Easy']))

def analyze(paper,app):
    return subprocess.run([sys.executable,str(helper),str(root/'benchmarks'/paper),str(root/'benchmarks'/app)],text=True,capture_output=True)

subset=analyze('analysis-subset-hard.json','analysis-subset-app.json')
assert not subset.returncode and '{3: 0.29}' in subset.stdout and 'X35 n/a (no 4/5-rival rows)' in subset.stdout
complete=analyze('release-form-hard-hard.json','release-form-hard-app.json')
assert not complete.returncode and 'X35 +0.18' in complete.stdout
for paper,app in [('analysis-duplicate-hard.json','analysis-subset-app.json'),('analysis-subset-hard.json','analysis-duplicate-app.json')]:
    run=analyze(paper,app)
    assert run.returncode and 'two rows for 3 rivals' in run.stderr
results.append(dict(B2='subset n/a; complete rounded-input sample +0.18; duplicate Paper and App rows rejected'))
print(json.dumps(results,indent=2))
