"""Exercise release UI, actual archived saves, and old/new Easy saves offline."""
import json, os
from pathlib import Path
from playwright.sync_api import sync_playwright

ROOT=Path(__file__).resolve().parent
REPO=Path(os.environ.get('DS_AUDIT_REPO',ROOT.parent/'dominant-species-solo'))
KEY='dominant-species-solo-v1'
def button(p,name):return p.get_by_role('button',name=name,exact=True)
def saved(p):return p.evaluate('(k)=>JSON.parse(localStorage.getItem(k))',KEY)

with sync_playwright() as pw:
    browser=pw.chromium.launch(executable_path=os.environ['DS_AUDIT_CHROMIUM'],args=['--no-sandbox','--no-zygote','--single-process','--disable-gpu','--disable-dev-shm-usage'])
    ctx=browser.new_context(viewport={'width':390,'height':850},offline=True,accept_downloads=True)
    p=ctx.new_page(); errors=[];net=[];out={'matrix':[],'originalSaves':[]}
    p.on('pageerror',lambda e:errors.append(str(e)))
    p.on('request',lambda r:net.append(r.url) if r.url.startswith(('http:','https:')) else None)
    uri=(REPO/'Dominant_Species_Solo.html').as_uri()
    p.goto(uri)
    for n in (2,3,4,5):
        for extra in (-2,-1,0,1):
            p.evaluate('localStorage.clear()');p.reload()
            p.locator(f'input[name=count][value="{n}"]').check()
            p.locator('input[name=rules][value=paper]').check()
            p.locator(f'input[name=extra][value="{extra}"]').check()
            before=p.locator('.setup-title p').inner_text()
            p.locator('form[data-form=start] button[type=submit]').click()
            g=saved(p)['game'];base={2:6,3:5,4:4,5:3}[n];scaled=n==5 and extra==-2
            assert g['animals'][g['human']]['ap']==base+int(scaled)
            assert all(g['animals'][id]['ap']==base+(-1 if scaled else extra) for id in g['rivals'])
            instruction=p.locator('.instruction').first.inner_text()
            out['matrix'].append({'rivals':n,'extra':extra,'setup':before,'instruction':instruction,'ap':{id:v['ap'] for id,v in g['animals'].items()}})
            if scaled:
                out['scaledInstruction']=instruction
                p.screenshot(path=str(ROOT/'screenshots/scaled-easy-instructions.png'),full_page=True)
                (ROOT/'saves/new-v053-five-easy.json').write_text(json.dumps(saved(p)))
                button(p,'Game menu').click()
                with p.expect_download() as d:button(p,'Export save').click()
                exported=Path(d.value.path()).read_bytes()
                p.keyboard.press('Escape')
                p.locator('#import-file').set_input_files({'name':'new-easy.json','mimeType':'application/json','buffer':exported})
                assert saved(p)['game']==g
                p.reload();assert saved(p)['game']==g
    p.locator('#import-file').set_input_files(ROOT/'saves/legacy-v052-five-easy.json')
    g=saved(p)['game']
    assert g['version']=='0.5.3' and g['animals'][g['human']]['ap']==3
    assert all(g['animals'][id]['ap']==1 for id in g['rivals']) and not g['paper'].get('scaledEasy')
    p.reload();assert saved(p)['game']==g
    button(p,'Game menu').click()
    with p.expect_download() as d:button(p,'Export save').click()
    exported=Path(d.value.path()).read_bytes();p.keyboard.press('Escape')
    p.locator('#import-file').set_input_files({'name':'old-easy.json','mimeType':'application/json','buffer':exported})
    assert saved(p)['game']==g
    out['legacy']={'player':3,'eachRival':1,'reloadAndExportImport':True}
    for name,target,vp in [('mammals-extinction-played','B2',None),('mammals-extinction-tie','C3',3)]:
        path=ROOT/'original-saves'/f'{name}.json'
        p.locator('#import-file').set_input_files(path)
        before=saved(p)['game'];assert before['version']=='0.5.3'
        button(p,'Show Mammals move').click()
        preview=p.locator('.result-box').first.inner_text();assert f'save one cube at {target}' in preview
        assert saved(p)['game']==before
        button(p,'Applied · Continue').click();after=saved(p)['game']
        if vp is not None:assert after['animals']['mammals']['vp']-before['animals']['mammals']['vp']==vp
        button(p,'Undo').click();assert saved(p)['game']==before
        button(p,'Show Mammals move').click();button(p,'Applied · Continue').click()
        assert saved(p)['game']==after
        p.reload();assert saved(p)['game']==after
        out['originalSaves'].append({'name':name,'preview':preview,'undoReplayReload':True})
    out.update({'browser':browser.version,'errors':errors,'network':net})
    assert not errors and not net
    browser.close()
(ROOT/'browser-focused.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({'matrixCases':len(out['matrix']),'scaledInstruction':out['scaledInstruction'],'legacy':out['legacy'],'originalSaves':out['originalSaves'],'errors':errors,'network':net},indent=2))
