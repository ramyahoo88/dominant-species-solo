# Dominant Species Solo v0.5.6 audit evidence

Audited commit `95c67db8385929c0b22b551d129b137c0248b1c9` on 15 November 2026, America/Chicago.
The release HTML and an independent rebuild both have SHA-256
`bd7afbb90abc3f1727baacb3d7fa6e170ad3db37ce801eb058ad00fd42218530`.

The forecast corrections and tested cards-only deck/save behavior pass. The release has two findings.

- **P1, medium.** All three shipped PDFs lag behind their current source. The card PDF and rulebook appendix have 30 earlier Migration reminders and two earlier Abundance reminders each. The rulebook and aid sheets 1, 2, 4 and 9 omit new clarification text. The embedded app documents and generated HTML contain the updates. Regenerate the PDFs and require the original verifier and print-fit checks to pass.
- **C1, medium.** In cards-only mode the global Bot decks dialog still shows Tooth & Claw conditional Yes/No cards. How to play begins with the full-board workflow. Both controls should follow the selected mode. The dedicated Rules and Player aids controls provide the correct Red Queen documents.

## Reproduce

Check out the audited commit in a clone that includes v0.5.5 (`4874b18`) in its history. Run these from the extracted evidence root after setting `REPO` to that checkout.

```bash
REPO=/absolute/path/to/dominant-species-solo
node --test "$REPO/source/rules.test.cjs"
node "$REPO/source/smoke.cjs" --check
node "$REPO/source/benchmark.cjs" --selftest
node evidence/check-cards-only.cjs "$REPO" evidence/cards-only
node evidence/check-forecast.cjs "$REPO" evidence/fixtures
python3 evidence/check-printables.py "$REPO" runs/printables
python3 "$REPO/source/paper/verify-printables.py" "$REPO" --output-dir runs/release-verifier
```

The two Python publication checks are expected to exit nonzero for this release. The original verifier stops at `standalone Mammals front 1: text missing or changed`. The audit wrapper records the actual earlier card wording, gathers prose failures and checks the remaining card identity, action order, weak markers, backs and duplex geometry. Its internal verifier progress line can say PASS for continued checks. The final `releaseVerdict` is FAIL and the audit wrapper exits 1. It never edits the audited checkout.

The printables wrapper also rebuilds the HTML, Markdown and `rq_embed.js` in a temporary scratch copy and checks exact byte equality. Its PDF-wording substitutions are confined to that copy, solely for inspecting the remaining content. They are not a recommended fix.

Node.js and Python with PyMuPDF and markdown are required for those commands. Report generation also uses ReportLab and the system DejaVu Sans fonts.

## Results and scope

- 58 repository tests passed.
- The 60-game smoke check matched the unchanged baseline.
- The benchmark self-test completed 24 games with no reported errors.
- 624 cards-only configurations covered every human animal, rival subset of size two through five, and difficulty. There were 43,200 interleaved draws and 5,400 deterministic saved-state replays.
- Exact shipped UI handlers passed setup, drawing, reshuffle, Undo/redraw, reload, export/import, invalid-import preservation, new-game settings, mode switching and the 200-history/60-Undo boundaries under a DOM shim.
- All 48 in-app card faces matched the generated printable HTML.
- 720 constructed endgame positions produced 1,396 actual endgame resolutions. No winning human Mammals save was missed. The legacy switch reproduced v0.5.5 projections and forecasts did not mutate the input states.
- The forecast fixtures preserve the complete prior reproduction states. They are targeted examples, not balance evidence.

No fresh difficulty comparison was run. Browser layout, iframe scrolling, real browser downloads and the print-fit suite remain unverified. Playwright's expected Chromium was absent; installed Chromium failed on a denied socket. A cloud-browser attempt to open the local artifact was rejected by its URL policy, and no workaround was attempted. The browser failure logs are included.

The generated HTML files in `evidence/cards-only` are markup evidence from the DOM-shim tests, not screenshots or proof of visual browser rendering. PDF-page images in `render` document visual inspection of the shipped PDFs.

## Files

- `logs/` contains baseline results, exact failure logs and audit result JSON.
- `evidence/check-cards-only.cjs` exercises the exact shipped HTML script with a minimal DOM shim.
- `evidence/check-forecast.cjs` extends the prior independent scoring harness for the new human save objective.
- `evidence/check-printables.py` gathers publication mismatches and verifies unaffected card data and geometry.
- `runs/printables/printable-review.json` records every detected prose mismatch, source rebuild result and card check.
- `manifest.json` identifies the release and hashes the evidence files.

The release source was reviewed without edits. This archive does not apply a product patch.
