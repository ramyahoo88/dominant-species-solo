# Dominant Species v0.5.4 printables audit

Audited commit: e7a9726c9be7a77cc79cebedaab0b5701d04fee7.
App SHA-256: 4ed8110d6d15be58759fab88ec26e6611dc784812c83aecb03a77f8de44afadf.

Verdict: pass with one low-priority Aquatic wording clarification (P3).
The aids agree with the rulebook; the Aquatic wording is inherited from it.
With fewer than four species in the gene pool, compare the ranks using the
number actually available. The app already does this. No app change is needed.
Mass Exodus and the clarified Competition +6 pass. All 49 repository tests pass.

## Contents

- verify-printables.py: adapted verifier; intended repository location is
  source/paper/verify-printables.py. The patch adds exactly this file.
- print-observations.json: 96 cut-out card faces, 48 aid deck rows, all ten aid
  sheets, complete PDF/HTML character inventory and ordered text blocks,
  per-table coverage, generated setup values/element/food-chain data and
  priority lists. HTML and Markdown regenerate byte for byte.
- aid-line-review.json: explicit manual review units for all ten sheets, with
  rulebook sections, app functions and disposition. This is a review record,
  not a claim that prose equivalence was proved automatically.
- card-edge-cases.cjs/json and saves/aquatic.json: inventory-valid, constructed
  Aquatic small-pool case, reached through Domination and card claim. D2 is
  correct with the one available Bird; a literal four-species comparison
  instead selects E2. This is not a seed-based frequency estimate.
- competition-check.cjs/json: dominant last species, non-dominant last species,
  and dominance lost without removing the victim's last species.
- verifier-negative-controls.py/json: four deliberately broken publications
  rejected, including reversed priority wording with unchanged character counts.
- provenance.json: pinned versions, source and artifact hashes.
- logs: repository test output, verification output and the browser limitation.
- make-report.py: PDF report and evidence metadata generator.

## Reproduce

From the repository root, after applying the patch:

    python3 source/paper/verify-printables.py . --output-dir /tmp/ds-print-check --rebuild
    node --test source/rules.test.cjs

The verifier needs PyMuPDF. Rebuilding HTML/Markdown also needs the existing
printables producer's markdown dependency and Node. It reads the current
version and deck data rather than hard-coding v0.5.4. It locates the first
appendix card page instead of assuming that the appendix is a table.

For optional browser PDF rebuilding (requires a runnable Chromium):

    DS_AUDIT_CHROMIUM=/path/to/chromium python3 source/paper/verify-printables.py . --output-dir /tmp/ds-print-check --rebuild-pdfs

For the focused checks, replace /path/to/repo with the checkout path:

    node card-edge-cases.cjs /path/to/repo
    node competition-check.cjs /path/to/repo

The negative-control script expects this evidence directory beside a checkout
named dominant-species-solo. Its temporary changed PDFs are not retained.

## Verification limits

Current shipped PDFs were rendered with PyMuPDF and visually inspected.
The rulebook contains nine rules pages and six cut-out card pages; the aids
contain ten sheets. Appendix and standalone cards agree in content and cut
geometry. They are not pixel-identical: inherited line-height shifts the
card title/actions slightly inside the same borders. No clipping was found.

Chromium cannot start in this environment because socket creation is denied.
A fresh browser UI run and regenerated-PDF pixel comparison were therefore
not completed. The failed optional command is retained as evidence; it is
not a failed application test. The app does rebuild byte for byte.
No new balance simulations were run, because the app is unchanged.

## Builder coverage observation (T1)

The existing check_aids searches for row labels across the complete aid HTML.
Deleting the Execution Migration row still passes because Planning also has
a Migration row. The adapted verifier checks these tables separately and
checks all of their rendered text. The current published aids contain every
required row; this observation concerns the guard, not missing current text.

No game rules, generated printables or app files were changed by this audit.
Only the verification script was added locally; nothing was pushed.
