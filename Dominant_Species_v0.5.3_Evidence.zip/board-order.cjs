const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');

const repo = path.resolve(process.argv[2] ?? path.join(__dirname, '../dominant-species-solo'));
const {load} = require(path.join(repo, 'source/benchmark/load.cjs'));
const runtime = load('worktree');
Object.assign(runtime.get('globalThis'), {assert, log: console.log});

const tests = runtime.run(`(() => {
  const findings = {};
  const fixtures = {};
  const seed = 520081;

  function position({human = 'birds', rivals = ['mammals','arachnids'], cubes = {}, terrain = {}} = {}) {
    const s = newGame(human, rivals, true, seed, {extra:0});
    s.turn = 3;
    s.phase = 'execution';
    s.cursor = EXECUTION.length;
    s.corners = {};
    for (const tile of terrainIds(s)) {
      for (const animal of s.ids) removeCube(s,tile,animal,s.tiles[tile].cubes[animal],'pool');
    }
    for (const [tile,type] of Object.entries(terrain)) {
      if (s.tiles[tile]) {
        s.tiles[tile].terrain = type;
      } else {
        s.tiles[tile] = {terrain:type,cubes:Object.fromEntries(s.ids.map(animal => [animal,0]))};
        s.stacks[0].left--;
      }
    }
    for (const [tile, animals] of Object.entries(cubes)) {
      for (const [animal,n] of Object.entries(animals)) addCube(s,tile,animal,n);
    }
    return s;
  }

  function check(s, test, {actor = 'mammals', key, name, kind} = {}, evaluate) {
    if (key) {
      s.cursor = EXECUTION.indexOf(key);
      s.pawns[key] = {actor,card:null,focus:null};
    }
    if (name) {
      s.usedCards.push(name);
      s.pending.push({kind:'effect',name,actor,tile:'D3'});
    }
    if (kind === 'spider') s.cursor = EXECUTION.indexOf('!arachnids');
    validateState(s);
    const step = nextStep(s);
    assert.equal(step.actor,actor);
    fixtures[test] = {format:SAVE_KEY,game:copy(s)};
    const choice = botAction(s,step);
    const record = evaluate(choice,step);
    const after = copy(s);
    runStep(after,step,copy(choice));
    validateState(after);
    return {choice,after,record};
  }

  const barren = position({terrain:{A1:'forest',B2:'forest',B3:'forest'}});
  barren.boxes.abundance = ['grub'];
  check(barren,'empty-earth',{key:'abundance-0'}, choice => {
    assert.equal(choice.corner,'-11,-3');
  });
  const noOccupied = position({terrain:{A1:'forest',B2:'forest',B3:'forest'}});
  check(noOccupied,'habitat-fallback',{name:'Habitat'}, choice => {
    assert.equal(choice.corner,'-11,-3');
  });

  // C3 holds the only Mammal cube. The winning corner touches the vacant
  // Wetland D2, and so beats both the west tip of C3 and the other D2 corner.
  const occupiedC3 = position({cubes:{C3:{mammals:1}}});
  occupiedC3.boxes.abundance = ['meat'];
  check(copy(occupiedC3),'abundance-value',{key:'abundance-0'}, choice => {
    assert.equal(choice.corner,'-2,-2');
  });
  check(copy(occupiedC3),'habitat-value',{name:'Habitat'}, choice => {
    assert.equal(choice.corner,'-2,-2');
  });

  // With no cubes the cone counts are all zero. The disk by C3 is left of
  // the disk by D2 (and E3), which touches a higher-value tile.
  const depletion = position();
  depletion.corners = {'2,-2':'seed','-5,-1':'seed'};
  depletion.boxes.depletion = ['seed'];
  const dc = check(depletion,'depletion-tie',{key:'depletion-0'}, choice => {
    assert.equal(choice.corner,'-5,-1');
  }).choice;
  findings.depletion = {actual:dc.corner, highestAdjacentValue:'2,-2'};

  // Each seed disk touches a single existing tile: C3 Jungle (6)
  // against C4 Forest (5). A leftmost or uppermost preference must not
  // outrank the sum. A second tie demonstrates geometry once sums match.
  const speciation = position();
  speciation.corners = {'-5,1':'seed','-4,-2':'seed'};
  const sc = check(speciation,'speciation-terrain-value',{key:'speciation-2'}, choice => {
    assert.equal(choice.corner,'-4,-2');
    assert.deepEqual(choice.add,{C3:3});
  }).choice;
  const specTie = position();
  specTie.corners = {'-4,-2':'seed','-5,-1':'seed'};
  check(specTie,'speciation-board-order',{key:'speciation-2'}, choice => {
    assert.equal(choice.corner,'-5,-1');
  });

  // Overlap distinguishes the sum of touched tile values from their maximum.
  // -1,-1 touches D2(8), C3(6), D3(1) for 15; 1,-1 touches
  // D2(8), E3(7), D3(1) for 16. Both have three matched tiles.
  const specSum = position();
  specSum.corners = {'-1,-1':'seed','1,-1':'seed'};
  const sumChoice = check(specSum,'speciation-sum',{key:'speciation-2'}, choice => {
    assert.equal(choice.corner,'1,-1');
    assert.deepEqual(choice.add,{D2:4,E3:3,D3:1});
  }).choice;
  findings.speciation = {singleTile:sc.corner, sumChoice:sumChoice.corner, equalMaximum:8, sums:[15,16]};

  const wander = position({cubes:{C3:{mammals:1},D2:{mammals:1}}});
  wander.stacks[0].face = 'sea';
  wander.boxes.wanderlust = ['meat'];
  const wc = check(wander,'wanderlust-site-tie',{key:'wanderlust-0'}, choice => {
    assert.equal(choice.tile,'C2');
    assert.equal(choice.corner,'-2,-2');
  }).choice;
  const wanderSites = frontTiles(wander).map(tile => ({
    tile,
    all:NEIGHBORS[tile].filter(n => wander.tiles[n]).length,
    own:NEIGHBORS[tile].filter(n => wander.tiles[n]?.cubes.mammals).length,
  })).filter(c => c.own && c.all === 2);
  assert.equal(wanderSites[0].tile,'B3');
  assert.equal(wanderSites[0].own,1);
  findings.wanderlust = {tiedSites:wanderSites, actual:wc.tile, corner:wc.corner};
  const wanderCorner = position({cubes:{C3:{mammals:1}}});
  wanderCorner.stacks[0].face = 'sea';
  wanderCorner.boxes.wanderlust = ['meat'];
  const wcc = check(wanderCorner,'wanderlust-corner-tie',{key:'wanderlust-0'}, choice => {
    assert.equal(choice.tile,'B3');
    assert.equal(choice.corner,'-5,-1');
  }).choice;
  findings.wanderlust.cornerTie = wcc.corner;

  const aquatic = position();
  check(aquatic,'aquatic-corner',{name:'Aquatic'}, choice => {
    assert.equal(choice.tile,'D2');
    assert.equal(choice.corner,'-2,-2');
  });
  const blight = position();
  blight.corners = {'-4,0':'grass','-5,-1':'water'};
  PAPER.oldCornerOrder = true;
  assert.equal(paperEffect(copy(blight),{actor:'mammals',name:'Blight'}).keep,'-4,0');
  delete PAPER.oldCornerOrder;
  check(blight,'blight-kept-disk',{name:'Blight'}, choice => {
    assert.equal(choice.tile,'C3');
    assert.equal(choice.keep,'-5,-1');
  });
  const migration = position({cubes:{D2:{mammals:1},C3:{mammals:1}},terrain:{C2:'forest'}});
  migration.corners = {'-4,-4':'seed'};
  PAPER.oldCornerOrder = true;
  assert.equal(paperMigration(migration,'mammals',2).moves[0].from,'D2');
  delete PAPER.oldCornerOrder;
  const mc = check(migration,'migration-equal-origins',{key:'migration-5'}, choice => {
    assert.deepEqual(choice.moves,[{from:'C3',to:'C2',n:1},{from:'D2',to:'C2',n:1}]);
  }).choice;
  findings.migration = mc.moves;

  const fertile = position({cubes:{C3:{mammals:1},D2:{mammals:1}}});
  const fc = check(fertile,'fertile-tie',{name:'Fertile'}, choice => assert.equal(choice.tile,'C3'));
  assert.equal(fc.after.animals.mammals.vp,1);
  findings.fertile = {actual:fc.choice.tile, printed:'C3', vp:1};

  const exodus = position({cubes:{D3:{birds:1}}});
  const ec = check(exodus,'mass-exodus-destination',{name:'Mass Exodus'}, choice => {
    assert.equal(choice.tile,'D3');
    assert.deepEqual(choice.moves.birds,[{from:'D3',to:'D4',n:1}]);
  }).choice;
  findings.massExodus = {actual:ec.moves.birds[0].to, printed:'D4', vp:[3,8]};

  const contest = position({human:'mammals',rivals:['birds','arachnids'],terrain:{E5:'forest'},
    cubes:{D4:{mammals:1,arachnids:1},E5:{mammals:1,arachnids:2}}});
  assert.equal(paperHitScore(contest,'D4','mammals','arachnids'),7.5);
  assert.equal(paperHitScore(contest,'E5','mammals','arachnids'),7.5);
  const cc = check(contest,'arachnids-free-competition-tie',{kind:'spider',actor:'arachnids'}, choice => {
    assert.deepEqual(choice.hits,[{tile:'D4',victim:'mammals'}]);
  }).choice;
  findings.arachnids = {actual:cc.hits[0].tile, printed:'D4', score:7.5};

  const extinct = position({terrain:{C3:'tundra'},cubes:{C3:{mammals:1},D3:{mammals:2}}});
  extinct.animals.mammals.ward.D3 = 1;
  assert.deepEqual(extinctionOptions(extinct,'mammals'),['D3','C3']);
  const er = check(extinct,'mammals-extinction-tie',{}, choice => assert.equal(choice.saved,'C3'));
  const printed = copy(extinct);
  runStep(printed,nextStep(printed),{saved:'C3'});
  validateState(printed);
  assert.equal(er.after.animals.mammals.vp,3);
  assert.equal(printed.animals.mammals.vp,3);
  findings.mammalsExtinction = {actual:er.choice.saved, printed:'C3',
    actualSurvivalVP:er.after.animals.mammals.vp, printedSurvivalVP:printed.animals.mammals.vp};

  return {seed,findings,fixtures};
})()`);

const dest = path.join(__dirname, 'saves');
fs.mkdirSync(dest, {recursive:true});
for (const [name, save] of Object.entries(tests.fixtures)) {
  fs.writeFileSync(path.join(dest, name + '.json'), JSON.stringify(save) + '\n');
}
const summary = {seed:tests.seed, checked:Object.keys(tests.fixtures), findings:tests.findings};
fs.writeFileSync(path.join(__dirname, 'board-order.json'), JSON.stringify(summary,null,2)+'\n');
console.log(JSON.stringify(summary,null,2));
