"""Deliberate publication faults: each must be rejected by the verifier."""
import contextlib, importlib.util, io, json, shutil, tempfile
from pathlib import Path
import fitz
ROOT=Path(__file__).resolve().parent
REPO=ROOT.parent/'dominant-species-solo'
spec=importlib.util.spec_from_file_location('verify',REPO/'source/paper/verify-printables.py')
v=importlib.util.module_from_spec(spec);spec.loader.exec_module(v)
results=[]
with tempfile.TemporaryDirectory(prefix='printables-negative-') as temp:
 temp=Path(temp)
 def reset():
  repo=temp/'repo'
  if repo.exists():shutil.rmtree(repo)
  shutil.copytree(REPO/'paper',repo/'paper')
  for name in ['source/src/data.js','source/src/decks.js','source/paper/ladder.json','source/paper/RULES.md','source/paper/paper.js']:
   path=repo/name;path.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(REPO/name,path)
  return repo
 def rejected(name,repo,expected):
  try:
   with contextlib.redirect_stdout(io.StringIO()):v.verify(repo,temp/'out')
  except AssertionError as e:
   assert expected in str(e),(name,str(e));results.append({'case':name,'rejected':True,'message':str(e)})
  else:raise AssertionError(name+' was accepted')
 repo=reset();file=repo/'paper/Paper_Rivals_Rulebook.pdf';d=fitz.open(file);d.delete_page(14);d.save(str(file)+'.new');d.close();Path(str(file)+'.new').replace(file)
 rejected('missing appendix page',repo,'Expected one standalone and appendix card page per animal')
 repo=reset();file=repo/'source/src/decks.js';text=file.read_text();text=text.replace('Food Chain Advantage','Changed Card Name',1);file.write_text(text)
 rejected('changed source card identity',repo,'standalone mammals card 1')
 repo=reset();file=repo/'paper/Paper_Rivals_Player_Aids.pdf';d=fitz.open(file);word=d[1].search_for('Regression')[0];d[1].add_redact_annot(word,fill=(1,1,1));d[1].apply_redactions();d.save(str(file)+'.new');d.close();Path(str(file)+'.new').replace(file)
 rejected('missing word in aid PDF',repo,'aid 2: missing')
 # Reorder complete cells: character totals are unchanged, but ordered row
 # verification must still detect the changed instruction.
 repo=reset();file=repo/'paper/Paper_Rivals_Player_Aids.html';text=file.read_text();text=text.replace('touching the most tiles it occupies → touching the highest first-place value (any touching tile)', 'touching the highest first-place value (any touching tile) → touching the most tiles it occupies',1);file.write_text(text)
 rejected('aid priority order reversed with same character inventory',repo,'missing/reordered block')
 # The source coverage check must be per table, not a search across both.
 body=v.Document((REPO/'paper/Paper_Rivals_Player_Aids.html').read_text()).body
 pages=list(body.all(cls='page'));table=next(pages[1].all('table'))
 labels=[v.normal(next(row.all('td')).text()) for row in table.all('tr') if any(row.all('td'))]
 assert labels.count('migration')==1
 assert 'migration' in [v.normal(next(row.all('td')).text()) for row in next(pages[0].all('table')).all('tr') if any(row.all('td'))]
 # Exercise the production builder's weaker guard to document the reason
 # the adapted verifier checks each table separately.
 import runpy
 producer=runpy.run_path(str(REPO/'source/paper/printables.py'))
 source=(REPO/'source/paper/AIDS.html').read_text()
 line='<tr><td>Migration</td><td>Moves one species at a time, up to the space\'s number (below).</td></tr>'
 assert line in source
 producer['check_aids']((REPO/'source/paper/RULES.md').read_text(),source.replace(line,''))
 results.append({'case':'producer global row-presence limitation','producerAcceptsMissingExecutionMigration':True,'adaptedVerifierUsesSeparateTables':True})
(ROOT/'verifier-negative-controls.json').write_text(json.dumps(results,indent=2)+'\n')
print('PASS: four deliberate publication faults rejected; producer row-coverage limitation reproduced')
