from pathlib import Path
import json,html,hashlib
from reportlab.platypus import SimpleDocTemplate,Paragraph,Spacer,Table,TableStyle,PageBreak,KeepTogether
from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet,ParagraphStyle
from reportlab.lib.enums import TA_LEFT
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
ROOT=Path(__file__).resolve().parents[1];E=ROOT/'evidence';OUT=ROOT/'output';OUT.mkdir(exist_ok=True)
DATA=json.loads((E/'fresh-evaluation.json').read_text());MAN=json.loads((E/'manifest.json').read_text())
for name,file in [('Audit','DejaVuSans.ttf'),('AuditBold','DejaVuSans-Bold.ttf'),('AuditMono','DejaVuSansMono.ttf')]:
 pdfmetrics.registerFont(TTFont(name,'/usr/share/fonts/truetype/dejavu/'+file))
INK=colors.HexColor('#173b35');MUTED=colors.HexColor('#53615d');PALE=colors.HexColor('#edf4f0');LINE=colors.HexColor('#d0dcd5');AMBER=colors.HexColor('#8e540f')
styles=getSampleStyleSheet()
styles.add(ParagraphStyle(name='TitleA',fontName='AuditBold',fontSize=26,leading=31,textColor=INK,spaceAfter=12))
styles.add(ParagraphStyle(name='HeadingA',fontName='AuditBold',fontSize=16,leading=20,textColor=INK,spaceAfter=10))
styles.add(ParagraphStyle(name='SubA',fontName='AuditBold',fontSize=11,leading=15,textColor=INK,spaceBefore=10,spaceAfter=5))
styles.add(ParagraphStyle(name='BodyA',fontName='Audit',fontSize=9.2,leading=14,textColor=colors.HexColor('#23302b'),spaceAfter=8))
styles.add(ParagraphStyle(name='SmallA',fontName='Audit',fontSize=8,leading=11.3,textColor=MUTED,spaceAfter=6))
styles.add(ParagraphStyle(name='CellA',fontName='Audit',fontSize=8.2,leading=11.2,textColor=colors.HexColor('#23302b')))
styles.add(ParagraphStyle(name='CellSmall',fontName='Audit',fontSize=7.4,leading=10,textColor=colors.HexColor('#23302b')))
styles.add(ParagraphStyle(name='CodeA',fontName='AuditMono',fontSize=7.5,leading=10.5,textColor=INK,backColor=PALE,borderPadding=7,spaceAfter=9))
story=[];plain=[]
def p(text,sty='BodyA'):
 story.append(Paragraph(text,styles[sty]));plain.append(text)
def title(s):p(s,'HeadingA')
def sub(s):p(s,'SubA')
def gap(n=5):story.append(Spacer(1,n))
def page():story.append(PageBreak());plain.append('\n--- PAGE ---\n')
def table(headers,rows,widths,small=False):
 sty=styles['CellSmall' if small else 'CellA']
 def c(t):return Paragraph(str(t),sty)
 data=[[Paragraph('<b>'+h+'</b>',sty)for h in headers]]+[[c(x)for x in row]for row in rows]
 t=Table(data,colWidths=widths,repeatRows=1,hAlign='LEFT')
 t.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),PALE),('VALIGN',(0,0),(-1,-1),'TOP'),('LEFTPADDING',(0,0),(-1,-1),7),('RIGHTPADDING',(0,0),(-1,-1),7),('TOPPADDING',(0,0),(-1,-1),6),('BOTTOMPADDING',(0,0),(-1,-1),6),('LINEBELOW',(0,0),(-1,0),.7,INK),('LINEBELOW',(0,1),(-1,-1),.3,LINE)]))
 story.append(t);gap(8);plain.append('\n'.join([' | '.join(headers)]+[' | '.join(map(str,r))for r in rows]))
def code(s):p(html.escape(s).replace('\n','<br/>'),'CodeA')
def link(label,url):return f'<link href="{url}" color="#245a4e">{label}</link>'
COMMIT=MAN['commit'];GH='https://github.com/ramyahoo88/dominant-species-solo/blob/'+COMMIT+'/'
p('Dominant Species Solo','TitleA');p('Comprehensive audit | Web app and Paper Rivals','HeadingA')
p('15 November 2026 | Latest main: <b>4f32abb</b> | App v0.5.4','SmallA')
p('<b>Verdict: suitable for continued play, with one app-bot decision defect and three smaller issues to fix.</b> The rules engine and recent fixes pass the checks run here. The app can nevertheless choose a losing Ice Age because its forecast uses a different Mammals save from actual play. Paper Catastrophe and Hibernation need two short clarifications; the published smoke baseline is stale.')
table(['ID / priority','Confirmed finding','Recommended response'],[
 ['A1 / medium','Ice Age forecast can predict a win that the actual final reset turns into a loss.','Use the actual Extinction save policy in the forecast; add the supplied regression.'],
 ['P1 / low','Paper Catastrophe omits the app\'s occupied-target restriction.','State the restriction in the rulebook and aid sheet 3.'],
 ['P2 / low','Paper Hibernation never fixes the number of species to return.','Specify five, or all eliminated species if fewer; use that number in comparisons.'],
 ['T1 / low','BASELINE_RESULTS.json no longer matches the documented smoke command.','Regenerate it with the release, or label and pin it as historical.']
],[76,235,205])
sub('Evidence at a glance')
p('<b>50/50 repository tests; 4,800 fresh complete games; 0 simulation errors and 0 turn-cap stalls.</b> Additional checks exercised 20,480 choices on 320 generated positions, prior migration/tie regressions, 96 setup combinations, and historical save migrations. All printed content and card data passed the publication verifier.')
p('<b>Browser limitation:</b> fresh Chromium checks could not run in this environment. Prior v0.5.4 browser evidence covers the same app bytes, but it is historical evidence. This report does not claim a fresh browser pass or physical tabletop playtesting.','SmallA')
sub('Version locked for the audit')
p('Main was checked again at the end and still pointed to '+COMMIT+'. The shipped HTML and a separate rebuild are byte-identical (472,594 bytes). No production source, release, or GitHub branch was changed.','SmallA')
code('SHA-256\n4ed8110d6d15be58759fab88ec26e6611dc784812c83aecb03a77f8de44afadf')
page()
title('A1 | Ice Age forecasts the wrong Mammals save')
p('<b>Medium priority - app-bot decision logic.</b> Actual scoring is correct. The problem is in <font face="AuditMono">endEstimate</font>: it saves the first endangered Mammal in tile storage order. The actual app rival saves the endangered species on the tile with the highest first-place value (with its tundra adjustment). The two choices can produce different winners.')
sub('Reproducible position')
p('Import <font face="AuditMono">ice-age-wrong-mammal-save.json</font>. It is the normal card-claim step after Birds score C3. Birds have 9 VP and one surviving species at C3 Jungle. Mammals have 10 VP and one endangered species on each of D3 Tundra and D2 Wetland. Ice Age and Fertile remain available; no later action pawns remain. The save passes the release validator.')
table(['Projection','Mammals save','Mammals final','Birds final','Winner'],[
 ['Current forecast','D3 Tundra','12','16','Birds'],
 ['Actual app reset','D2 Wetland','18','16','Mammals'],
 ['Diagnostic correction','D2 Wetland','18','16','Mammals']
],[121,120,88,84,103])
p('Birds select Ice Age with a computed value of 8. Resolving the card and the remaining reset finishes the game at Mammals 18, Birds 16. The false winning forecast comes from granting Mammals only tundra scoring and Survival instead of the Wetland score. There are no intervening actions to explain the difference.')
sub('Targeted correction')
p('Share the final-reset projection with actual resolution. On a copied state, apply the prospective Ice Age points, the relevant Mammals save, Extinction, Survival and final tile scoring. For a human Mammals player, evaluate the legal save choices rather than assuming storage order. Keep future actions explicitly outside this snapshot estimate.')
p('An isolated diagnostic replacement in the evidence script makes the estimate 18-16 and Birds choose Fertile instead. This demonstrates the cause and a correction direction; it is not a shipped patch. A broader before/after run would still be needed before accepting a production change.')
sub('Scope and confidence')
p('Confirmed on a constructed, inventory-valid position reached through a legal score-and-claim sequence. Its frequency in ordinary play was not measured. It is an endgame decision weakness, not a general scoring defect or proof that a human can force this outcome.')
p('Source: '+link('effects.js, lines 11-26',GH+'source/src/effects.js#L11')+'; '+link('bot.js, Extinction choice',GH+'source/src/bot.js')+'. GMT rulebook p. 20 permits the Mammals save and specifies Extinction, Survival, then final tile scoring. Evidence: focused.cjs, focused.json and the importable save.','SmallA')
page()
title('P1 and P2 | Two deterministic paper choices')
sub('P1 - Catastrophe: which tiles are candidates?')
p('The app\'s Paper rival considers only tiles containing at least one species. The rulebook and aid sheet 3 say to choose the tile causing the greatest weighted removal, without that restriction. An empty center can therefore be the best target under the printed procedure.')
p('In <font face="AuditMono">catastrophe-empty-center.json</font>, D3 is empty, Birds have one species on C3, and Mammals have one on each of the other five surrounding tiles. Birds have just legally claimed Catastrophe.')
table(['Candidate','Opposing species removed','Own removed','Printed weighted total'],[
 ['D3 empty tundra','5','1','5 - 2 = 3'],
 ['E3 occupied savannah','2','0','2']
],[144,132,88,152])
p('The app chooses E3 because D3 is excluded before scoring. Both resulting states pass validation. This is a missing paper restriction, not an illegal move by the app. Keeping the existing app behavior avoids changing the tested bot.')
p('<b>Suggested addition:</b> "Choose among tiles containing at least one species." Then retain the existing survivor, adjacent-removal, weighted-score and tie priorities. Apply it to RULES.md and the Catastrophe row of AIDS.html, then regenerate the printables.')
sub('P2 - Hibernation: how many species return?')
p('The printed row chooses a tile but does not specify how many eliminated species to return or use in its rank comparison. The app always returns <font face="AuditMono">min(5, eliminated species)</font>. The physical card\'s variable quantity therefore remains a player decision unless the paper procedure fixes it.')
p('<b>Suggested opening:</b> "Return 5 eliminated species, or all eliminated species if fewer than 5 are available. Use that number when comparing rank gains." Continue with the current matched-tile, tundra, unoccupied-tile and rank-gain priorities, then the general tie rule.')
p('The supplied Hibernation save returns five Birds to D3 and records protection for all five. A player choosing a smaller legal quantity would not reproduce the app. This is a small completeness issue; no new balancing rule is proposed.')
p('Sources: '+link('RULES.md, Catastrophe and Hibernation',GH+'source/paper/RULES.md#L118')+'; '+link('paper.js, Catastrophe',GH+'source/paper/paper.js#L436')+'; '+link('paper.js, Hibernation',GH+'source/paper/paper.js#L483')+'; aid sheet 3. Evidence: focused.json and both importable saves.','SmallA')
page()
title('Verification and release integrity')
table(['Area','Result and scope'],[
 ['Build identity','PASS. Root HTML and separate rebuild share the complete 4ed8110d... hash. Main remained 4f32abb.'],
 ['Repository tests','PASS. 50 tests; latest Aquatic small-pool/no-match cases and Mass Exodus fallback included.'],
 ['Generated decisions','PASS. 320 synthetic, inventory-valid positions: 8,320 card-effect choices (all 26 in both systems) and 12,160 action choices. No state-value mutation by the choosers or post-resolution conservation/validation failure. These are not all reachable game histories.'],
 ['Prior independent regressions','PASS. 300 Migration positions / 1,050 rival decisions; 1,500 dominance-tie cases; five skip predicates, Empty Earth and the earlier tie-priority fixtures.'],
 ['Setup and historical saves','PASS at engine level. 96 current setup combinations. Actual historical v0.3.6, .3.9, .4.1, .5.0, .5.1, .5.2 and .5.3 states retain their appropriate counts and rule flags after migration.'],
 ['Publication fidelity','PASS. Nine rules pages plus six appendix pages, 48 appendix and 48 standalone card faces, ten aid sheets and 48 aid deck rows. HTML/Markdown rebuilds agree; PDF text and ordered blocks match sources.'],
 ['Visual review','Rendered all 31 publication pages and reviewed contact sheets and selected full-size pages. No clipped rows, missing card faces or obvious overlap found. PDF pixel-identical regeneration was not completed because Chromium was unavailable.'],
 ['Browser / offline flows','NOT RE-RUN successfully. Matching Playwright browser absent; installed Chromium blocked by Unix-socket policy; cloud browser blocked local-file navigation. Source review covers forms, controls and save handling; prior same-hash browser evidence is historical.']
],[126,390],small=True)
sub('T1 - Recorded smoke baseline is stale')
p('The README says the smoke command prints the counts in BASELINE_RESULTS.json. It currently does not. The file was last updated in v0.3.4 (commit 64bcc86). This is a verification-data problem, not a failure to finish the games.')
table(['Metric','Stored baseline','Current run'],[
 ['Completed games','60','60'],['Total steps','24,169','24,175'],['Forfeits','147','151'],['Bot deck draws','5,329','5,336']
],[240,138,138])
p('Refresh the baseline from the exact release, excluding only the machine-dependent timing field, and add a comparison check. If it is intentionally historical, change the filename and README command to pin its source revision.','SmallA')
page()
title('Fresh games | Strategy and difficulty checks')
p('4,800 complete games: 60 scenarios per player strategy, table size and rival system. Seed namespace 111620260; two to five rivals; short/full decks; four policies on each cell\'s shared setups. All finished within the harness\'s turn cap. <b>Errors: 0. Stalls: 0.</b>')
rows=[]
for r in DATA['table']:
 rows.append([str(r['rivals']),r['rivalsAre'],str(r['tuned'])+'%',str(r['dominance'])+'%',str(r['majority'])+'%',str(r['expansion'])+'%'])
table(['Rivals','System / level','Tuned v4','Card chaser','Majorities','Expansion'],rows,[45,125,85,87,87,87],small=True)
p('Each percentage is the scripted player\'s win rate, rounded by the harness, with <b>n = 60 per cell</b>. Food-chain tiebreaks determine the winner. A 50% result at this sample size has a Wilson 95% interval of roughly 38-62%; small reversals between neighboring levels are not evidence of a broken ladder.','SmallA')
p('The tuned player is the existing v4 checkpoint; no new optimization was performed. Majority, card-chasing and expansion are fixed purposeful policies. The supply model uses physical inventories and no hidden future draws for the player. App and Paper use different cell seeds, so this table is not a paired App-versus-Paper experiment.','SmallA')
page()
title('Interpretation and coverage')
sub('Pooled tuned-player results')
rows=[]
for level in ['App','Easy','Standard','Hard','Expert']:
 x=DATA['pooled'][level]['tuned'];rows.append([level,f"{x['wins']}/{x['games']}",f"{x['pct']:.1f}%",f"{x['ci95'][0]}-{x['ci95'][1]}%"])
table(['Rival system','Wins / games','Win rate','Wilson 95% interval'],rows,[168,120,95,133])
p('These pools weight the four table sizes equally. The paper ladder gets harder in the pooled sample. Stronger scripted planning still matters: against App rivals, v4 wins 47.5% versus 22.5% for the card chaser; against Paper Hard, 32.9% versus 14.2%. This sample does not establish optimal play, a dominant strategy, actual human difficulty, or a new estimate of the project\'s X35 balance metric.')
sub('Rules and bot coverage map')
table(['Area','Audit coverage / outcome'],[
 ['Setup, board and scoring','Reviewed player-count component limits, matching versus majority, food-chain ties, Survival, glaciation queue, Extinction and Ice Age resolution. Engine checks passed; A1 affects the forecast.'],
 ['All 12 action rows','Source review, existing targeted assertions and generated resolution checks. Migration gained an independent first-move oracle; Initiative, queued Glaciation and Instinct were reviewed for timing.'],
 ['26 Dominance Cards','Read app and paper selection/resolution branches plus human forms; all effects exercised on generated states. Paper choice gaps are P1/P2. Full original physical-card art was not independently reacquired; earlier CARD_AUDIT.md was treated as prior evidence.'],
 ['Paper overrides and decks','Reviewed planning-first, two-Domination cap, Barren/Empty Earth, blocking, No-face deck use, weak-action filter, fallback and last resort. All 48 printed deck entries verified against source.'],
 ['Published fixes','Aquatic available-cube comparison, Mass Exodus fallback, Competition +6 wording, speciesTie, scaled Easy, Mammals save, corner/board order and the five no-effect card skips pass their checks.'],
 ['Save and UI handling','Reviewed import validation, migration, JSON conservation, preview/undo flow, supply drafts, autosave failure messaging and escaped text rendering. Fresh rendered UI interactions remain unverified.']
],[150,366],small=True)
sub('Administration and practical play')
p('The paper rules still require repeated rank checks, opponent VP ordering and some weighted removal comparisons. The aids collect those procedures well. No stopwatch-based administration study or physical playtest was performed. Test one small and one five-rival table with a human before making claims about speed, clarity or enjoyment.','SmallA')
page()
title('Repair order and reproducible evidence')
p('<b>1.</b> Fix A1 with a shared final-reset projection and the supplied losing-Ice-Age regression. Include a human Mammals save case, a protected Hibernation cube and a Survival tie. Compare the changed bot with the release on matched fresh setups; do not retune difficulty merely to compensate for the correction.')
p('<b>2.</b> Add P1/P2 wording to the rulebook source and aid sheet 3. Regenerate, run the publication verifier and visually inspect the changed pages. These clarifications can preserve the app and existing balance measurements.')
p('<b>3.</b> Refresh or explicitly archive the smoke baseline. Add the smoke comparison and printables verifier to a repeatable release check with declared Python/browser dependencies. The current label-presence guard is useful but does not prove semantic parity.')
p('<b>4.</b> Re-run the repository browser suite in an environment that can launch Chromium, then do a short tabletop check. Consider page numbers and stable section references in the 15-page rulebook as a small usability improvement.')
sub('Main reproduction commands')
p('Use a full clone at commit 4f32abb67c8c611e665be9427a65a54b5c3db8f2. Commands below assume the evidence archive is unpacked beside the repository. README.txt in the archive gives the complete instructions.','SmallA')
code('node --test source/rules.test.cjs\nnode source/smoke.cjs\npython3 source/paper/verify-printables.py \\\n  --output-dir ../print-check --rebuild\nnode ../audit/scripts/focused.cjs . ../audit/evidence\nnode ../audit/scripts/generated-positions.cjs . ../audit/evidence')
code('node source/benchmark.cjs --evaluate \\\n  --weights source/benchmark/tuned_weights_v4.json \\\n  --seed 111620260 --per-cell 60 --workers 8 \\\n  --modes app,m2,m1,0,1 \\\n  --policies tuned,majority,dominance,expansion > fresh.json')
sub('Evidence package')
p('Includes three importable saves, focused and generated-position scripts, a diagnostic-only forecast correction, raw fresh-run output, prior-regression rerun results, test logs, the publication-verifier output, hashes, runtime details and rendering contact sheets. The production application is unchanged.','SmallA')
sub('Sources and precedence')
p('Current repository source and generated paper files are authoritative for this fan variant. '+link('GMT third-printing rulebook', 'https://www.gmtgames.com/living_rules/DS3_Rulebook-web_FINAL.pdf')+' supplies the base rules; paper flat matching, rival tie handling and planning-first are explicit variants. Prior audits and CARD_AUDIT.md support historical coverage and are not substitutes for fresh tests.','SmallA')
p(link('Audited commit on GitHub','https://github.com/ramyahoo88/dominant-species-solo/commit/'+COMMIT)+' | '+link('Audit response v0.5.4',GH+'AUDIT_RESPONSE_v0.5.4.md')+' | '+link('Paper rule source',GH+'source/paper/RULES.md'),'SmallA')
p('Limits: constructed states do not establish occurrence rates; existing scripted players do not prove optimality; no physical playtest, exhaustive proof, fresh browser pass or full rules certification is claimed. No new game-stopping failure was observed in the completed simulations.','SmallA')

def footer(canvas,doc):
 canvas.saveState();canvas.setStrokeColor(LINE);canvas.line(48,42,564,42);canvas.setFont('Audit',7.1);canvas.setFillColor(MUTED);canvas.drawString(48,29,'Dominant Species Solo | 4f32abb | Comprehensive audit');canvas.drawRightString(564,29,str(doc.page));canvas.restoreState()
file=OUT/'Dominant_Species_v0.5.4_Comprehensive_Audit.pdf'
doc=SimpleDocTemplate(str(file),pagesize=(612,792),rightMargin=48,leftMargin=48,topMargin=43,bottomMargin=55,title='Dominant Species Solo v0.5.4 - Comprehensive Audit',author='ChatGPT')
doc.build(story,onFirstPage=footer,onLaterPages=footer)
(OUT/'Audit_Text.txt').write_text('\n\n'.join(plain))
print(file)
