"use strict";

// Usage: node compare-release.cjs REPO OUTPUT_DIR [V1.0.0_REF] [V0.5.7_REF]
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');

const repo = path.resolve(process.argv[2]);
const out = path.resolve(process.argv[3]);
const release = process.argv[4] || '6a9e7fba95c113d2017b45bbf494de985f26bac8';
const baseline = process.argv[5] || 'ffa795b14d3618864345c520549d1120c7d3987b';
const {load, PLAYER_REFERENCE} = require(path.join(repo, 'source/benchmark/load.cjs'));
const player = load(PLAYER_REFERENCE, ['player']);
const humanPolicy = {place: player.get('playerPlacement'), choose: player.get('playerChoice')};

function simulator(ref) {
  const runtime = load(ref, ['game']);
  runtime.get('globalThis').humanPolicy = humanPolicy;
  return runtime.run(`({
    start({human, rivals, short, seed, extra}) {
      const state = newGame(human, rivals, short, seed, extra === null ? null : {extra});
      return {state, supplies: makeSupplies(state, seed)};
    },
    advance({state:s, supplies}, {policy, seed}) {
      if (s.phase === 'supply') {
        const input = nextSupply(s, supplies, seed);
        enterSupply(s, input);
        return {input};
      }
      if (s.phase === 'planning') {
        const {actor} = currentPlanner(s);
        if (actor !== s.human) return {actor, ...botPlacement(s)};
        const slot = humanPolicy.place(s, actor, policy);
        place(s, slot);
        return {actor, slot};
      }
      const step = nextStep(s);
      const choice = step.kind === 'symbiosis' ? symbioticDraw(s, step, seed) :
        step.actor === s.human ? humanPolicy.choose(s, step, policy) : botAction(s, step);
      const result = {step, choice: copy(choice)};
      if (step.kind === 'effect' && step.name === 'Aquatic' && s.paper && step.actor !== s.human) {
        result.aquaticPool = s.animals[step.actor].pool;
        if (result.aquaticPool === 0) {
          const wet = Object.keys(s.tiles).filter(t => ['sea','wetland'].includes(s.tiles[t].terrain));
          const open = wet.filter(t => VERTICES_OF[t].some(k => !s.corners[k]));
          const hasDisk = ELEMENT_IDS.some(el => bagCount(s,el) > 0);
          const candidates = hasDisk && open.length ? open : wet;
          // Zero additions cannot change any rank. Apply the printed matching, value and board-order tiers.
          const fits = tile => Number((hasDisk && open.includes(tile)) || VERTICES_OF[tile].some(k => s.corners[k]));
          result.printedAquaticTile = candidates.sort((a,b) => fits(b)-fits(a) ||
            TERRAIN[s.tiles[b].terrain].vp[0] - TERRAIN[s.tiles[a].terrain].vp[0] || a.localeCompare(b))[0] || null;
          if ((choice.tile || null) !== result.printedAquaticTile) result.preAquatic = copy(s);
        }
      }
      runStep(s, step, choice);
      return result;
    },
    validate: validateState,
    finish: standings,
    startDraw: newDrawGame,
    draw: drawFor,
    acceptDraw: validateDraw,
    seats(seed, n) { return shuffle(randomFor(seed, 0), FOOD).slice(0,n + 1); },
  })`);
}

function normalize({version, ...rest}) {
  return JSON.stringify(rest);
}

function decision({preAquatic, ...rest}) {
  return JSON.stringify(rest);
}

const dated = simulator(baseline), current = simulator(release);
const copies = [];
const checks = {
  baseline, release, startSeed: 731200, completePairs: 0, stateChecks: 0, deckPairs: 0, pairedDraws: 0,
  originalSaveResumes: 0, resumeChecks: 0, baseCardsResolved: {}, aquatic: {guidedEffects: 0, emptyPool: 0, mismatches: []},
  games: [],
};
let seed = checks.startSeed;

for (const count of [2,3,4,5]) {
  for (const extra of [null,-2,-1,0,1]) {
    for (const short of [true,false]) {
      for (const policy of ['majority','dominance','expansion']) {
        const [human, ...rivals] = dated.seats(seed++, count);
        const settings = {human, rivals, short, seed: seed - 1, extra, policy};
        const oldGame = dated.start(settings), newGame = current.start(settings);
        let resume = null;
        let steps = 0;
        const migrated = extra !== null && !short && policy === 'majority';
        const compare = (a, b, stage) => assert.equal(a, b, `seed ${settings.seed}, step ${steps}, ${stage}`);

        while (oldGame.state.phase !== 'finished') {
          assert(steps < 2600 && oldGame.state.turn <= 40, `game stalled at seed ${settings.seed}`);
          compare(normalize(newGame.state), normalize(oldGame.state), 'state');
          checks.stateChecks++;
          if (migrated && !resume && oldGame.state.paper?.pre?.length === count - 1) {
            resume = JSON.parse(JSON.stringify(oldGame));
            current.validate(resume.state);
            assert.equal(resume.state.version, '1.0.0');
            checks.originalSaveResumes++;
          }
          if (resume) {
            compare(normalize(resume.state), normalize(newGame.state), 'resumed state');
            compare(decision(current.advance(resume, settings)), decision(dated.advance(oldGame, settings)), 'resumed decision');
            checks.resumeChecks++;
          }
          const trace = current.advance(newGame, settings);
          if (!resume) compare(decision(trace), decision(dated.advance(oldGame, settings)), 'decision');
          if (extra === null && trace.step?.kind === 'effect') {
            const name = trace.step.name;
            checks.baseCardsResolved[name] = (checks.baseCardsResolved[name] || 0) + 1;
          }
          if (trace.aquaticPool !== undefined) {
            checks.aquatic.guidedEffects++;
            if (trace.aquaticPool === 0) checks.aquatic.emptyPool++;
            if (trace.preAquatic) {
              const details = {seed: settings.seed, turn: trace.preAquatic.turn, actor: trace.step.actor,
                app: trace.choice.tile || null, print: trace.printedAquaticTile};
              checks.aquatic.mismatches.push(details);
              copies.push([`aquatic-seed-${settings.seed}.json`,
                {format:'dominant-species-solo-v1',game:trace.preAquatic}]);
            }
          }
          current.validate(newGame.state);
          dated.validate(oldGame.state);
          steps++;
        }

        compare(normalize(newGame.state), normalize(oldGame.state), 'final state');
        if (resume) compare(normalize(resume.state), normalize(newGame.state), 'final resumed state');
        assert(newGame.state.usedCards.includes('Ice Age'), `no Ice Age at seed ${settings.seed}`);
        checks.completePairs++;
        checks.games.push({...settings, steps, turns: newGame.state.turn, winner: current.finish(newGame.state)[0]});
      }
    }
  }
  const [human, ...rivals] = dated.seats(seed++, count);
  for (const extra of [-2,-1,0,1]) {
    const pair = [dated.startDraw(human, rivals, extra, seed), current.startDraw(human, rivals, extra, seed)];
    for (let draw = 0; draw < 9 * rivals.length; draw++) {
      const actor = rivals[draw % rivals.length];
      assert.equal(dated.draw(pair[0], actor), current.draw(pair[1], actor));
      assert.equal(normalize(pair[0]), normalize(pair[1]));
      checks.pairedDraws++;
    }
    const imported = current.acceptDraw(JSON.parse(JSON.stringify(pair[0])));
    assert.equal(normalize(imported), normalize(pair[1]));
    checks.deckPairs++;
  }
}

fs.mkdirSync(out, {recursive:true});
for (const [name, file] of copies) fs.writeFileSync(path.join(out, name), JSON.stringify(file, null, 2) + '\n');
fs.writeFileSync(path.join(out, 'release-comparison.json'), JSON.stringify(checks, null, 2) + '\n');
const {games, ...summary} = checks;
console.log(JSON.stringify(summary, null, 2));
