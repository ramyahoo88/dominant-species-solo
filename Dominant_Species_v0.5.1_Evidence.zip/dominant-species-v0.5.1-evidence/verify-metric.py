"""Cross-check the fresh audit statistic against the released analysis helper."""
import ast
import json
import re
import subprocess
import sys
from pathlib import Path

root=Path(__file__).resolve().parent
repo=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else root.parent/'dominant-species-audit-v051'
summary=json.loads((root/'benchmarks/fresh-summary.json').read_text())
paths=[]
for mode,label in [('hard','Hard'),('app','App')]:
    data=summary['levels'][mode]
    out={'table':[],'pooled':{label:{}}}
    for n,policies in data['sizes'].items():
        row={'rivals':int(n),'rivalsAre':label,'extraPawns':0 if mode=='hard' else None}
        for policy,stats in policies.items():
            row['tuned' if policy=='v4' else policy]=stats['winPct']
        out['table'].append(row)
    for policy,stats in data['pooled'].items():
        out['pooled'][label]['tuned' if policy=='v4' else policy]={'games':stats['games'],'wins':stats['wins'],'pct':stats['winPct']}
    file=root/'benchmarks'/f'fresh-release-form-{mode}.json'
    file.write_text(json.dumps(out,indent=2)+'\n')
    paths.append(file)
result=subprocess.run([sys.executable,str(repo/'source/benchmark/balance/final_eval.py'),*map(str,paths)],check=True,text=True,capture_output=True)
(root/'logs/fresh-release-helper.txt').write_text(result.stdout)
match=re.search(r'edgeX by rivals (.*?) \| X35 ([+-][0-9.]+)',result.stdout)
assert match
observed=ast.literal_eval(match[1])
expected=summary['extraLogOdds']['hard']
for n,value in observed.items():
    assert value==round(expected['perSize'][str(n)]['point'],2)
assert abs(float(match[2])-expected['mean3to5'])<.01
print(result.stdout)
print('PASS release helper and independent exact-count calculation agree to displayed precision.')
