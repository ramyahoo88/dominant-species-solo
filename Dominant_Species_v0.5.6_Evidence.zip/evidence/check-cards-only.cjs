// Exercise the exact shipped script. The DOM shim checks markup and handlers,
// not browser layout, iframe navigation, or accessibility behavior.
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const repo = path.resolve(process.argv[2]);
const output = path.resolve(process.argv[3]);
const html = fs.readFileSync(path.join(repo, 'Dominant_Species_Solo.html'), 'utf8');
const source = html.match(/<script>([\s\S]*?)<\/script>/)[1];
const FULL_KEY = 'dominant-species-solo-v1';
const DRAW_KEY = 'dominant-species-red-queen-cards-v1';

function start(initial = new Map()) {
  const nodes = new Map();
  const listeners = new Map();
  const storage = new Map(initial);
  const blobs = [];
  function element(id) {
    if (!nodes.has(id)) {
      const classes = new Set();
      nodes.set(id, {
        listeners: new Map(), innerHTML: '', textContent: '', hidden: false,
        classList: {toggle(name, on) { if (on) classes.add(name); else classes.delete(name); }, contains: name => classes.has(name)},
        querySelectorAll: () => [], querySelector: selector => element(id + ' ' + selector),
        addEventListener(name, fn) { this.listeners.set(name, fn); },
        focus() {}, showModal() { this.open = true; }, close() { this.open = false; },
        click() {}, append() {}, remove() {},
      });
    }
    return nodes.get(id);
  }
  const document = {
    getElementById: element, body: element('body'), createElement: element,
    addEventListener(name, fn) { listeners.set(name, fn); },
  };
  const localStorage = {
    getItem: key => storage.get(key) ?? null,
    setItem: (key, value) => storage.set(key, value),
    removeItem: key => storage.delete(key),
  };
  const context = vm.createContext({
    document, localStorage, assert, Blob, FormData: class extends Map { constructor() { super(); } },
    URL: {createObjectURL(blob) { blobs.push(blob); return 'blob:audit'; }, revokeObjectURL() {}},
    setTimeout() {}, crypto: {getRandomValues(a) { a[0] = 560001; return a; }},
  });
  vm.runInContext(source, context, {filename: 'Dominant_Species_Solo.html'});
  return {
    nodes, storage, blobs, context,
    run: code => vm.runInContext(code, context),
    markup: () => element('main').innerHTML,
    change(name, value) {
      element('main').listeners.get('change')({target: {name, value, form: {dataset: {form: 'start'}}}});
    },
    submit() {
      element('main').listeners.get('submit')({preventDefault() {}, target: {dataset: {form: 'start'}}});
    },
    click(action, extra = {}) {
      listeners.get('click')({target: {closest: () => ({dataset: {do: action, ...extra}})}});
    },
    async importRaw(body) {
      context.auditFile = {size: Buffer.byteLength(body), text: async () => body};
      await vm.runInContext('importSave(auditFile)', context);
    },
  };
}

function allConfigurations() {
  let configurations = 0, draws = 0, replayDraws = 0;
  for (const human of FOOD) {
    const others = FOOD.filter(id => id !== human);
    for (let mask = 0; mask < 32; mask++) {
      const rivals = others.filter((_, i) => mask & (1 << i));
      if (rivals.length < 2) continue;
      for (const [extra] of PAPER_LEVELS) {
        const s = newDrawGame(human, rivals, extra, configurations % 2 ? 0xffffffff : configurations);
        validateDraw(s);
        const base = SETUP_BY_PLAYERS[rivals.length + 1];
        const pawns = rivalPawns(s);
        assert.equal(pawns.rival, base[0] + (extra === -2 && rivals.length === 5 ? -1 : extra));
        assert.equal(pawns.you, base[0] + Number(extra === -2 && rivals.length === 5));
        const dealt = Object.fromEntries(rivals.map(id => [id, []]));
        for (let round = 0; round < 24; round++) {
          for (const id of rivals) {
            const untouched = Object.fromEntries(rivals.filter(other => other !== id).map(other => [other, JSON.stringify(s.decks[other])]));
            const snapshot = copy(s);
            const card = drawFor(s, id);
            draws++;
            dealt[id].push(card);
            validateDraw(s);
            assert.equal(s.draws.at(-1).reshuffled, round > 0 && round % 8 === 0);
            for (const [other, before] of Object.entries(untouched)) assert.equal(JSON.stringify(s.decks[other]), before);
            if (round % 8 === 0) {
              const restored = validateDraw(copy(snapshot));
              assert.equal(drawFor(restored, id), card);
              assert.equal(JSON.stringify(restored), JSON.stringify(s));
              replayDraws++;
            }
          }
        }
        for (const id of rivals) {
          for (let cycle = 0; cycle < 3; cycle++) {
            assert.deepEqual(dealt[id].slice(cycle * 8, cycle * 8 + 8).sort(), [0,1,2,3,4,5,6,7]);
          }
        }
        configurations++;
      }
    }
  }
  return {configurations, draws, replayDraws};
}

async function main() {
  fs.mkdirSync(output, {recursive: true});
  const ui = start();
  assert.match(ui.markup(), /The Red Queen · cards only/);
  ui.change('rules', 'draw');
  ui.change('count', '5');
  ui.change('extra', '-2');
  assert.ok(!ui.markup().includes('name="length"'));
  ui.submit();
  assert.match(ui.markup(), /Each rival has 2 action pawns, you have 4/);
  assert.equal(ui.storage.has(FULL_KEY), false);
  const original = JSON.parse(ui.storage.get(DRAW_KEY)).draw;
  const actor = original.rivals[0];
  for (let i = 0; i < 8; i++) ui.click('rq-draw', {animal: actor});
  const beforeNinth = ui.storage.get(DRAW_KEY);
  ui.click('rq-draw', {animal: actor});
  const afterNinth = ui.storage.get(DRAW_KEY);
  assert.match(ui.markup(), /discards were reshuffled before this draw/);
  ui.click('undo');
  assert.equal(ui.storage.get(DRAW_KEY), beforeNinth);
  ui.click('rq-draw', {animal: actor});
  assert.equal(ui.storage.get(DRAW_KEY), afterNinth);
  ui.click('rq-draw', {animal: original.rivals[1]});
  const saved = ui.storage.get(DRAW_KEY);
  const reload = start(ui.storage);
  assert.equal(reload.run('saveContents()'), saved);
  assert.equal(reload.run('undo.length'), 0);
  reload.click('export');
  assert.equal(await reload.blobs.at(-1).text(), saved);
  assert.equal(reload.nodes.get('a').download, 'The_Red_Queen_Cards_Only.json');
  for (const doc of ['rules', 'aids']) {
    reload.click(doc);
    const frame = reload.nodes.get('modal .doc-frame');
    assert.equal(frame.srcdoc, reload.run(doc === 'rules' ? 'RQ_RULES' : 'RQ_AIDS'));
    assert.match(reload.nodes.get('modal').innerHTML, /iframe class="doc-frame" sandbox/);
    fs.writeFileSync(path.join(output, 'embedded-' + doc + '.html'), frame.srcdoc);
    reload.click('close');
    assert.equal(reload.nodes.get('modal').open, false);
  }
  const invalid = JSON.parse(saved);
  invalid.draw.decks[actor].queue[0] = 999;
  for (const body of ['{', '{}', JSON.stringify({...JSON.parse(saved), format: 'wrong'}), JSON.stringify(invalid)]) {
    await reload.importRaw(body);
    assert.equal(reload.run('saveContents()'), saved);
    assert.equal(reload.storage.get(DRAW_KEY), saved);
    assert.ok(reload.nodes.get('notice').textContent);
  }
  reload.click('new');
  reload.click('new-confirm');
  assert.equal(reload.run('game === null && drawGame === null'), true);
  assert.equal(reload.storage.size, 0);
  assert.equal(reload.run('setup.draw && setup.bots.length === 5 && setup.extra === -2'), true);
  await reload.importRaw(saved);
  assert.equal(reload.run('saveContents()'), saved);
  const fullSave = reload.run("JSON.stringify({format:SAVE_KEY,game:newGame('insects',['mammals','birds'],true,560001)})");
  await reload.importRaw(fullSave);
  assert.equal(reload.run('drawGame === null && game.human === "insects"'), true);
  assert.ok(reload.storage.has(FULL_KEY));
  assert.equal(reload.storage.has(DRAW_KEY), false);
  await reload.importRaw(saved);
  assert.equal(reload.run('game === null && drawGame.human === "amphibians"'), true);
  assert.equal(reload.storage.has(FULL_KEY), false);
  assert.equal(reload.storage.get(DRAW_KEY), saved);

  // Global tools still expose the conditional Tooth & Claw cards during cards-only play.
  reload.click('decks');
  const deckDialog = reload.nodes.get('modal').innerHTML;
  assert.ok(deckDialog.includes('Yes ·') && deckDialog.includes('No ·'));
  assert.ok(deckDialog.includes('Two or more occupied tiles have at most one matching element'));
  fs.writeFileSync(path.join(output, 'cards-only-bot-decks-dialog.html'), deckDialog);
  fs.writeFileSync(path.join(output, 'cards-only-screen.html'), reload.markup());

  // History and Undo are bounded independently. Crossing their limits must not alter decks.
  for (let i = 0; i < 245; i++) reload.click('rq-draw', {animal: actor});
  assert.equal(reload.run('drawGame.draws.length'), 200);
  assert.equal(reload.run('undo.length'), 60);
  const afterLongRun = reload.run('saveContents()');
  const at60 = reload.run('JSON.stringify(undo[0])');
  for (let i = 0; i < 60; i++) reload.click('undo');
  assert.equal(reload.run('JSON.stringify(drawGame)'), at60);
  for (let i = 0; i < 60; i++) reload.click('rq-draw', {animal: actor});
  assert.equal(reload.run('saveContents()'), afterLongRun);

  const tally = ui.run('(' + allConfigurations.toString() + ')()');
  const faces = ui.run('FOOD.flatMap(actor => DECKS[actor].map((_,i) => ({actor,index:i,html:rqCard(actor,i)})))');
  fs.writeFileSync(path.join(output, 'card-faces.json'), JSON.stringify(faces, null, 2));
  const result = {engine: tally, ui: 'PASS exact shipped handlers under DOM shim',
    checked: ['setup', '8 draws and reshuffle', 'Undo and deterministic redraw', 'reload', 'export', 'import',
      'invalid import preserves state', 'switch between full and cards-only saves', 'new game preserves settings',
      'rule and aid frame srcdoc', '200-entry history and 60-entry Undo bounds'],
    finding: 'Bot decks shows conditional Tooth & Claw cards during Red Queen cards-only play',
    limitation: 'Real browser launch failed. No claim of Chromium rendering or accessibility coverage.'};
  console.log(JSON.stringify(result, null, 2));
}
main().catch(err => { console.error(err); process.exitCode = 1; });
