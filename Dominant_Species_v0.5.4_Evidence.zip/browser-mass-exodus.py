import json,os
from pathlib import Path
from playwright.sync_api import sync_playwright
ROOT=Path(__file__).resolve().parent
REPO=Path(os.environ.get('DS_AUDIT_REPO',ROOT.parent/'dominant-species-solo'))
KEY='dominant-species-solo-v1'
with sync_playwright() as pw:
    b=pw.chromium.launch(executable_path=os.environ['DS_AUDIT_CHROMIUM'],args=['--no-sandbox','--no-zygote','--disable-gpu','--disable-dev-shm-usage'])
    ctx=b.new_context(viewport={'width':390,'height':850},offline=True)
    p=ctx.new_page();errors=[];network=[]
    p.on('pageerror',lambda e:errors.append(str(e)))
    p.on('request',lambda r:network.append(r.url) if r.url.startswith(('http:','https:')) else None)
    p.goto((REPO/'Dominant_Species_Solo.html').as_uri())
    p.locator('#import-file').set_input_files(ROOT/'saves/mass-exodus-own-everywhere.json')
    p.wait_for_function('(k)=>JSON.parse(localStorage.getItem(k))?.game?.seed===11405477',arg=KEY)
    get=lambda:p.evaluate('(k)=>JSON.parse(localStorage.getItem(k)).game',KEY)
    before=get();assert all(t['cubes']['mammals']>0 for t in before['tiles'].values())
    p.get_by_role('button',name='Show Mammals move',exact=True).click()
    preview=p.locator('.result-box').first.inner_text();assert 'Mass Exodus from D3 Tundra' in preview
    assert get()==before
    p.locator('.result-box').screenshot(path=str(ROOT/'screenshots/mass-exodus-fallback.png'))
    p.get_by_role('button',name='Applied · Continue',exact=True).click();after=get()
    assert not any(after['tiles']['D3']['cubes'].values())
    p.get_by_role('button',name='Undo',exact=True).click();assert get()==before
    assert not errors and not network
    out={'browser':b.version,'preview':preview,'allTilesOccupiedByRival':True,'beforeCubes':{t:v['cubes'] for t,v in before['tiles'].items()},'afterCubes':{t:v['cubes'] for t,v in after['tiles'].items()},'undo':True,'errors':errors,'network':network}
    b.close()
(ROOT/'browser-mass-exodus.json').write_text(json.dumps(out,indent=2)+'\n')
print('PASS: Mass Exodus app fallback reproduced, applied and undone in released HTML')
