"""Run an unchanged repository Playwright test with a local Chromium binary."""
from pathlib import Path
import os
import runpy
import sys
from playwright.sync_api import BrowserType


launch = BrowserType.launch
chromium = os.environ.get('DS_AUDIT_CHROMIUM')
if not chromium:
    local = Path('/tmp/ds-browser/chrome-headless-shell-linux64/chrome-headless-shell')
    chromium = str(local) if local.is_file() else None


def local_launch(self, *args, **kwargs):
    if chromium:
        kwargs['executable_path'] = chromium
        flags = ['--no-sandbox', '--no-zygote', '--disable-gpu', '--disable-dev-shm-usage']
        kwargs['args'] = list(dict.fromkeys((kwargs.get('args') or []) + flags))
    return launch(self, *args, **kwargs)


BrowserType.launch = local_launch
sys.argv = sys.argv[1:]
runpy.run_path(sys.argv[0], run_name='__main__')
