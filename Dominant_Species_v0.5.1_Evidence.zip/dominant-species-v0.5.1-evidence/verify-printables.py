"""Compare both columns of the released card PDF to their deck data."""
import hashlib
import json
import re
import runpy
import subprocess
import sys
from pathlib import Path
import fitz

root = Path(__file__).resolve().parent
repo = Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else root.parent/'dominant-species-audit-v051'
paper = repo/'paper'
cards = fitz.open(paper/'Paper_Rivals_Cards.pdf')
rulebook = fitz.open(paper/'Paper_Rivals_Rulebook.pdf')
layout = ['mammals','reptiles','birds','amphibians','arachnids','insects']
js = """const fs=require('node:fs'),vm=require('node:vm');
 const out=vm.runInNewContext(fs.readFileSync(process.argv[1],'utf8')+';DECKS');
 console.log(JSON.stringify(out));"""
decks = json.loads(subprocess.check_output(['node','-e',js,str(repo/'source/src/decks.js')]))
checked = []
for index,animal in enumerate(layout):
    page = cards[index]
    assert animal.title() in page.get_textbox(fitz.Rect(0,0,612,43))
    for slot,card in enumerate(decks[animal]):
        x = 28.5 + slot % 2 * 252
        y = 45 + slot // 2 * 172.8
        lines = [t.strip() for t in page.get_textbox(fitz.Rect(x,y,x+252,y+172.8)).splitlines() if t.strip()]
        expected = [animal.upper(),str(slot+1),card['title']] + [
            f'{i}. {row.title()}' for i,row in enumerate(card['no']['rows'],1)
        ]
        assert lines == expected + ['Paper Rivals · try in order'], (slot,lines,expected)
        checked.append({'page':index+1,'animal':animal,'card':slot+1,'title':card['title'],'actions':card['no']['rows']})

assert len(checked) == 48
assert len(cards) == 6 and 'Generated from source/src/decks.js for app v0.5.1.' in cards[5].get_text()
ruletext = '\n'.join(page.get_text('text') for page in rulebook)
assert 'Full display.' in ruletext and 'Barren Earth.' in ruletext
assert 'Stalls.' in ruletext
# Deck titles should appear in the deck table and again in the appendix.
for c in checked:
    assert ruletext.count(c['title']) == 2, c
assert '--paper=0 --bots 3 --seed 200000 --repeats 2' in ' '.join(ruletext.split())

report = {
    'rulebookPages':len(rulebook), 'cardSheetPages':len(cards), 'cardsChecked':checked,
    'productionNoteOnLastCardSheet':True,
    'pdfSha256':{x.name:hashlib.sha256(x.read_bytes()).hexdigest() for x in paper.glob('*.pdf')},
}
if '--rebuild' in sys.argv:
    out = root/'print-rebuild'
    producer = runpy.run_path(str(repo/'source/paper/printables.py'))
    run = producer['main']
    run.__globals__['OUT'] = out
    sys.argv = ['printables.py']
    run()
    report['regeneratedTextMatches'] = {
        filename: (out/filename).read_bytes() == (paper/filename).read_bytes()
        for filename in ('Paper_Rivals_Rulebook.md','Paper_Rivals_Rulebook.html','Paper_Rivals_Cards.html')
    }
    assert all(report['regeneratedTextMatches'].values())
(root/'print-observations.json').write_text(json.dumps(report,indent=2)+'\n')
print(f"PASS {len(rulebook)} rulebook pages, {len(checked)} card identities and ordered faces in both columns")
