const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const repo = path.resolve(process.argv[2] ?? path.join(__dirname,'../../dominant-species-solo'));
const {load,PLAYER_REFERENCE} = require(path.join(repo,'source/benchmark/load.cjs'));
const sim = load('worktree',['game','nn/driver']);
const player = load(PLAYER_REFERENCE,['player']);
const strategy = {place:player.get('playerPlacement'),choose:player.get('playerChoice')};
const old = JSON.parse(fs.readFileSync(path.join(__dirname,'../saves/published-stall-200074.json'))).game;

sim.run(`
  Object.assign(PAPER,{place:true,all:true});
  const archived = (${sim.get('nnContinue').toString().replace('stepCount < 1800','stepCount < 12000').replace('s.turn > 30','s.turn > 120')});
`);
const reports = [];
for (const [seed,human,short,policy,extra,expected] of [
  [200074,'birds',true,'expansion',-1,6],
  [3880523955,'insects',false,'majority',-2,6],
  [3722144011,'birds',true,'majority',-2,21],
]) {
  const setup = {seed,human,short,policy,rivals:[...sim.get('FOOD')].filter(animal => animal !== human)};
  sim.run('PAPER.extraAP='+extra);
  const game = sim.get('playBenchmark')(setup,strategy);
  assert.equal(game.stalled,undefined);
  // Counts may change with the v0.5.3 Easy pawn scale; termination is the audit invariant.
  reports.push({seed,human,short,policy,extra,turns:game.turns,winner:game.winner});
}
sim.get('validateState')(old);
const resumed = sim.get('archived')(old,{cards:[],stacks:[[],[],[]]},old.seed,old.human,strategy,'expansion');
assert.equal(old.phase,'finished');
assert(old.usedCards.includes('Ice Age'));
const output = {fromStart:reports,archive:{seed:old.seed,fromTurn:31,toTurn:resumed.turns,iceAge:true}};
fs.writeFileSync(path.join(__dirname,'recovery.json'),JSON.stringify(output,null,2)+'\n');
console.log(JSON.stringify(output,null,2));
