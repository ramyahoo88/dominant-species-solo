// Concrete residual print ambiguities. These preserve the released chooser.
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
const repo=path.resolve(process.argv[2]||'../dominant-species-solo');
const rt=require(path.join(repo,'source/benchmark/load.cjs')).load('worktree');
Object.assign(rt.get('globalThis'),{assert});
const result=rt.run(`(() => {
  const observations=[], saves={};
  const base=()=>newGame('birds',['mammals','arachnids'],false,1053099,{extra:0});
  function effect(s,name) {
    s.turn=3;s.phase='execution';s.cursor=EXECUTION.length;
    s.usedCards.push(name);s.pending.push({kind:'effect',actor:'mammals',name,tile:'D3'});
    return s;
  }
  function test(name,s,verify) {
    validateState(s); const step=nextStep(s);const choice=botAction(s,step);verify(choice);
    const after=copy(s);runStep(after,step,copy(choice));validateState(after);
    saves[name]={format:SAVE_KEY,game:s};observations.push({name,step,choice});
  }
  // Both displayed elements are usable. The printed row does not say which one.
  const w=base();w.animals.mammals.added=['sun'];w.stacks.forEach(st=>st.face='forest');
  w.boxes.wanderlust=['sun','meat'];w.phase='execution';w.cursor=EXECUTION.indexOf('wanderlust-0');
  w.pawns['wanderlust-0']={actor:'mammals',card:null,focus:null};
  test('wanderlust-element-tie',w,c=>{assert.equal(c.pick,0);assert.equal(w.boxes.wanderlust[c.pick],'sun');});
  // Neither top-scoring bag element is the Mammals' printed Meat.
  const m=effect(base(),'Metamorphosis');
  for(const t of terrainIds(m)) for(const id of m.ids) removeCube(m,t,id,m.tiles[t].cubes[id],'pool');
  addCube(m,'C3','mammals',1);m.corners={};m.corners[VERTICES_OF.C3[0]]='sun';m.corners[VERTICES_OF.C3[1]]='water';
  m.animals.mammals.added=['grass'];
  test('metamorphosis-bag-tie',m,c=>{assert.equal(c.out,'grass');assert.equal(c.type,'sun');assert.equal(pCornersNear(m,'mammals','sun'),pCornersNear(m,'mammals','water'));});
  // Two duplicate types: the app picks the one whose second occurrence is first.
  const i=base();i.animals.mammals.added=['water','sun','sun','water'];
  i.phase='execution';i.cursor=EXECUTION.length;i.pending.push({kind:'immigrant',actor:'mammals'});
  test('immigrants-duplicate-tie',i,c=>{assert.equal(c.mode,'element');assert.equal(c.type,'sun');});
  // Aquatic shares Habitat's bag fallback in code, but print only states printed type.
  const a=effect(base(),'Aquatic');a.animals.mammals.added=['water','sun'];a.corners={};
  for(const row of ['adaptation','abundance','wanderlust','regression','depletion'])a.boxes[row]=Array(4).fill('meat');
  a.corners[VERTICES_OF.E4[0]]='water';a.pending[0].tile='E4';
  test('aquatic-element-fallback',a,c=>{assert.equal(bagCount(a,'meat'),0);assert.equal(c.type,'water');});
  // Equal lowest VP opponents: the app preserves the one lower in the food chain.
  const c=effect(base(),'Catastrophe');c.corners={};
  for(const t of terrainIds(c))for(const id of c.ids)removeCube(c,t,id,c.tiles[t].cubes[id],'pool');
  addCube(c,'C3','birds',1);addCube(c,'C3','arachnids',1);addCube(c,'E4','mammals',1);
  c.corners[VERTICES_OF.E4[0]]='meat';c.pending[0].tile='E4';c.animals.birds.vp=10;c.animals.arachnids.vp=10;
  test('catastrophe-survivor-tie',c,x=>{assert.equal(x.tile,'C3');assert.equal(x.keep,'arachnids');});
  return {observations,saves};
})()`);
for(const [name,save] of Object.entries(result.saves))fs.writeFileSync(path.join(__dirname,'saves',name+'.json'),JSON.stringify(save)+'\n');
fs.writeFileSync(path.join(__dirname,'remaining-ties.json'),JSON.stringify(result.observations,null,2)+'\n');
console.log(JSON.stringify(result.observations,null,2));
