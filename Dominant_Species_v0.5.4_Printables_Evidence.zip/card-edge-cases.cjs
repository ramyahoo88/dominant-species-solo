const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
const repo=path.resolve(process.argv[2]||'../dominant-species-solo');
const {load}=require(path.join(repo,'source/benchmark/load.cjs'));
const r=load('worktree');r.get('globalThis').assert=assert;
const results=r.run(`(()=>{
 const s=newGame('mammals',['birds','insects'],false,11505401,{extra:0});
 for(const t of terrainIds(s))for(const a of s.ids)removeCube(s,t,a,s.tiles[t].cubes[a],'pool');
 s.tiles.E2={terrain:'sea',cubes:Object.fromEntries(s.ids.map(a=>[a,0]))};s.stacks[0].left--;
 for(const [t,a,n] of [['D2','birds',1],['D2','mammals',1],['E2','birds',1],['E2','mammals',3],['C4','birds',1]])addCube(s,t,a,n);
 s.animals.birds.dead=s.animals.birds.pool-1;s.animals.birds.pool=1;
 s.turn=7;s.phase='execution';s.cursor=EXECUTION.indexOf('domination-0');
 s.pawns['domination-0']={actor:'birds',card:null,focus:null};s.market=['Aquatic',null,null,null,null];
 validateState(s);assert.equal(cone(s,'C4'),'birds');
 runStep(s,nextStep(s),{tile:'C4'});runStep(s,nextStep(s),botAction(s,nextStep(s)));validateState(s);
 const step=nextStep(s),choice=botAction(s,step);assert.equal(choice.tile,'D2');assert.equal(choice.n,1);
 const candidates=['D2','E2'].map(t=>{const before=pRank(s,t,'birds');const ranks={};for(const n of [1,4]){s.tiles[t].cubes.birds+=n;ranks[n]=pRank(s,t,'birds');s.tiles[t].cubes.birds-=n;}return {tile:t,terrain:s.tiles[t].terrain,value:pFirstVP(s,t),before,ranks};});
 const save={format:SAVE_KEY,game:copy(s)};
 const after=copy(s);runStep(after,step,choice);validateState(after);
 return {aquatic:{save,step,choice,candidates,printedFourSpeciesChoice:'E2',actualOneSpeciesChoice:'D2'}};
})()`);
for(const [name,item]of Object.entries(results)){fs.writeFileSync(path.join(__dirname,'saves',name+'.json'),JSON.stringify(item.save)+'\n');delete item.save;}
fs.writeFileSync(path.join(__dirname,'card-edge-cases.json'),JSON.stringify(results,null,2)+'\n');console.log(JSON.stringify(results,null,2));
