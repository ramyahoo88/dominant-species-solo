"""Exercise Empty Earth through the shipped app's import and action controls."""
import json
import os
from pathlib import Path
from playwright.sync_api import expect, sync_playwright

ROOT = Path(__file__).resolve().parent
REPO = Path(os.environ.get('DS_AUDIT_REPO', ROOT.parent/'dominant-species-audit-v051')).resolve()
KEY = 'dominant-species-solo-v1'


def button(page, name):
    return page.get_by_role('button', name=name, exact=True)


def saved(page):
    return page.evaluate('(key)=>JSON.parse(localStorage.getItem(key))?.game', KEY)


def imported(page, name, legacy_level=None):
    file = ROOT/'saves'/f'{name}.json'
    expected = json.loads(file.read_text())['game']
    expected['version'] = '0.5.1'
    if legacy_level:
        expected['paper']['level'] = legacy_level
    page.locator('#import-file').set_input_files(file)
    page.wait_for_function('''([key,want])=>{
      const stable=x=>JSON.stringify(x,(_,v)=>v&&typeof v==='object'&&!Array.isArray(v)
        ?Object.fromEntries(Object.keys(v).sort().map(k=>[k,v[k]])):v);
      return stable(JSON.parse(localStorage.getItem(key))?.game)===stable(want);
    }''', arg=[KEY,expected])
    return saved(page)


def export(page, name):
    button(page,'Game menu').click()
    with page.expect_download() as pending:
        button(page,'Export save').click()
    target=ROOT/'saves'/f'{name}.json'
    pending.value.save_as(target)
    if page.locator('#modal').is_visible():
        button(page,'Close').click()
    return json.loads(target.read_text())['game']


def execute(page, name, legacy=False):
    before=imported(page,name,'Easy' if legacy else None)
    button(page,'How to play').click()
    help_text=page.locator('#modal').inner_text()
    assert 'saved games included' in help_text and 'any empty corner' in help_text
    if legacy:
        assert 'keeps these rules from then' in help_text
    button(page,'Close').click()
    button(page,'Show Mammals move').click()
    preview=page.locator('.result-box').first.inner_text()
    assert 'Empty Earth' in preview
    assert saved(page)==before
    page.reload()
    assert saved(page)==before
    button(page,'Show Mammals move').click()
    assert page.locator('.result-box').first.inner_text()==preview
    button(page,'Applied · Continue').click()
    after=saved(page)
    added=set(after['corners'])-set(before['corners'])
    assert len(added)==1
    corner=added.pop()
    assert after['corners'][corner]=='grub'
    assert after['boxes']['abundance'].count('grub')==before['boxes']['abundance'].count('grub')-1
    assert 'Empty Earth' in after['log'][-1]['body']
    button(page,'Undo').click()
    assert saved(page)==before
    button(page,'Show Mammals move').click()
    button(page,'Applied · Continue').click()
    assert saved(page)==after
    assert export(page,name+'-after')==after
    page.reload()
    assert saved(page)==after
    assert imported(page,name+'-after')==after
    if legacy:
        assert not after['paper'].get('planFirst')
        assert after['paper']['extra']==before['paper']['extra']
    if name=='v050-empty-abundance':
        page.set_viewport_size({'width':1300,'height':1050})
        page.locator('#earth-panel').screenshot(path=str(ROOT/'print-review'/'empty-earth-applied.png'))
        page.set_viewport_size({'width':390,'height':850})
    return {'fixture':name,'corner':corner,'preview':preview,'ruleFlags':after['paper'],
            'previewReloadExact':True,'undoRedoExact':True,'exportImportExact':True}


with sync_playwright() as pw:
    browser=pw.chromium.launch(executable_path=os.environ['DS_AUDIT_CHROMIUM'],
        args=['--no-sandbox','--no-zygote','--single-process','--disable-gpu','--disable-dev-shm-usage'])
    page=browser.new_context(viewport={'width':390,'height':850},offline=True).new_page()
    errors,network=[],[]
    page.on('pageerror',lambda e:errors.append(str(e)))
    page.on('request',lambda r:network.append(r.url) if r.url.startswith(('http:','https:')) else None)
    page.goto((REPO/'Dominant_Species_Solo.html').as_uri())
    archived=imported(page,'published-stall-200074')
    assert archived['phase']=='supply' and archived['turn']==31
    assert not archived['corners']
    assert sum(sum(tile['cubes'].values()) for tile in archived['tiles'].values())==0
    page.reload()
    assert saved(page)==archived
    draws=json.loads((ROOT/'saves/turn31-draws.json').read_text())
    for row in ('adaptation','abundance','wanderlust'):
        for element in draws[row]:
            page.locator(f'[data-do="add-disk"][data-row="{row}"][data-element="{element}"]').click()
    button(page,'Begin Planning').click()
    start=saved(page)
    expected=json.loads((ROOT/'saves/v050-empty-planning.json').read_text())['game']
    expected['version']='0.5.1'
    assert start==expected
    button(page,'Draw for Mammals').click()
    expect(page.locator('.result-box').first).to_contain_text('Barren Earth')
    expect(page.locator('.result-box').first).to_contain_text('Abundance')
    assert saved(page)==start
    button(page,'Pawn placed · Continue').click()
    halfway=saved(page)
    assert halfway['pawns']['abundance-0']['actor']=='mammals'
    assert 'mammals' not in halfway['paper']['pre']
    assert export(page,'v051-empty-mid-opening')==halfway
    page.reload()
    assert saved(page)==halfway
    assert imported(page,'v051-empty-mid-opening')==halfway
    records=[execute(page,'v050-empty-abundance')]
    for old in ('v041-empty-execution','v039-empty-execution'):
        records.append(execute(page,old,True))
    assert not errors and not network
    report={'archivedTurn31ImportedAndSupplied':True,'openingPriority':'Barren Earth / Abundance','midOpeningSaveExact':True,
            'execution':records,'browser':browser.version,'errors':errors,'network':network}
    browser.close()
(ROOT/'browser-empty-earth.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
