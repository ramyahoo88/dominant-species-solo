from pathlib import Path
import json, re, hashlib, importlib.util, subprocess, shutil, zipfile
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, PageBreak
from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.enums import TA_LEFT
from xml.sax.saxutils import escape
ROOT=Path(__file__).resolve().parent
REPO=ROOT.parent/'dominant-species-solo'
OUT=ROOT.parent/'deliverables';OUT.mkdir(exist_ok=True)
script=REPO/'source/paper/verify-printables.py'
spec=importlib.util.spec_from_file_location('verifier',script);v=importlib.util.module_from_spec(spec);spec.loader.exec_module(v)
body=v.Document((REPO/'paper/Paper_Rivals_Player_Aids.html').read_text()).body
pages=list(body.all(cls='page'))
# An explicit review record for every substantive aid paragraph, table row,
# and leaf list item; the six step boxes on sheet 1 are recorded separately.
refs={1:['paperPlacement','paperLegal','paperSlotScore','paperBarren','paperEmptyEarth','pLeader','match','cone'],
2:['paperPawn','paperSpeciation','paperWanderlust','paperMigration','paperCompetition','paperHitScore','botAction'],
3:['paperClaim','paperCardIdle','paperEffect','pBy'],
4:['newGame','pRank','pGainsRank','pOrderOpps','paperLoss','paperImmigrant','paperExtinction','moveGroups']}
review=[]
for i,page in enumerate(pages,1):
 for node in page.all():
  if node.tag not in {'p','tr','li'}:continue
  if node.tag=='li' and any(node.all('li')):continue
  text=re.sub(r'\s+',' ',node.text()).strip()
  if not text:continue
  finding=i==3 and text.startswith('Aquatic')
  review.append({'id':f'S{i}-{len([r for r in review if r["sheet"]==i])+1:02}', 'sheet':i,'text':text,
    'rulebookSection':{1:'Terms; Planning',2:'Execution; Other decisions (arrival)',3:'Dominance Cards',4:'Setup; Terms; Other decisions; Planning'}.get(i,'Rival decks; Planning; Terms; Other decisions'),
    'appReferences':refs.get(i,['DECKS','ANIMALS','PAPER_CARD_ORDER','paperPlacement','match','cone','botAction']),
    'result':'P3: fixed four-species comparison needs pool qualification' if finding else 'Reviewed: equivalent within normal game rules and the shared tie defaults'})
 if i==1:
  for node in page.all(cls='step'):
   text=re.sub(r'\s+',' ',node.text()).strip()
   review.append({'id':f'S1-STEP-{text[0]}','sheet':1,'text':text,'rulebookSection':'Planning','appReferences':['paperPlacement','paperLegal'],'result':'Reviewed: equivalent'})
(ROOT/'aid-line-review.json').write_text(json.dumps(review,indent=2,ensure_ascii=False)+'\n')
checks=json.loads((ROOT/'print-observations.json').read_text())
provenance={'commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=REPO,text=True).strip(),
 'auditDateLocal':'2026-11-15 America/Chicago','appUnchangedFrom':'158c9d8',
 'files':{str(p.relative_to(REPO)):hashlib.sha256(p.read_bytes()).hexdigest() for p in [REPO/'Dominant_Species_Solo.html',REPO/'source/paper/RULES.md',REPO/'source/paper/AIDS.html',REPO/'source/paper/printables.py',REPO/'source/paper/paper.js',*sorted((REPO/'paper').glob('*'))]},
 'newVerifierSha256':hashlib.sha256(script.read_bytes()).hexdigest(),
 'appByteIdenticalRebuild':True,'repositoryTests':{'pass':49,'fail':0},'aidReviewUnits':len(review),
 'browserRebuild':'Blocked before launch by environment socket restriction; not claimed as passed'}
(ROOT/'provenance.json').write_text(json.dumps(provenance,indent=2)+'\n')
shutil.copyfile(script,ROOT/'verify-printables.py')
# Source patch is directly applicable from the repository root.
r=subprocess.run(['git','diff','--no-index','--','/dev/null','source/paper/verify-printables.py'],cwd=REPO,text=True,capture_output=True)
assert r.returncode==1
(ROOT/'verify-printables.patch').write_text(r.stdout)
readme='''# Dominant Species v0.5.4 printables audit

Audited commit: e7a9726c9be7a77cc79cebedaab0b5701d04fee7.
App SHA-256: 4ed8110d6d15be58759fab88ec26e6611dc784812c83aecb03a77f8de44afadf.

Verdict: pass with one low-priority Aquatic wording clarification (P3).
The aids agree with the rulebook; the Aquatic wording is inherited from it.
With fewer than four species in the gene pool, compare the ranks using the
number actually available. The app already does this. No app change is needed.
Mass Exodus and the clarified Competition +6 pass. All 49 repository tests pass.

## Contents

- verify-printables.py: adapted verifier; intended repository location is
  source/paper/verify-printables.py. The patch adds exactly this file.
- print-observations.json: 96 cut-out card faces, 48 aid deck rows, all ten aid
  sheets, complete PDF/HTML character inventory and ordered text blocks,
  per-table coverage, generated setup values/element/food-chain data and
  priority lists. HTML and Markdown regenerate byte for byte.
- aid-line-review.json: explicit manual review units for all ten sheets, with
  rulebook sections, app functions and disposition. This is a review record,
  not a claim that prose equivalence was proved automatically.
- card-edge-cases.cjs/json and saves/aquatic.json: inventory-valid, constructed
  Aquatic small-pool case, reached through Domination and card claim. D2 is
  correct with the one available Bird; a literal four-species comparison
  instead selects E2. This is not a seed-based frequency estimate.
- competition-check.cjs/json: dominant last species, non-dominant last species,
  and dominance lost without removing the victim's last species.
- verifier-negative-controls.py/json: four deliberately broken publications
  rejected, including reversed priority wording with unchanged character counts.
- provenance.json: pinned versions, source and artifact hashes.
- logs: repository test output, verification output and the browser limitation.
- make-report.py: PDF report and evidence metadata generator.

## Reproduce

From the repository root, after applying the patch:

    python3 source/paper/verify-printables.py . --output-dir /tmp/ds-print-check --rebuild
    node --test source/rules.test.cjs

The verifier needs PyMuPDF. Rebuilding HTML/Markdown also needs the existing
printables producer's markdown dependency and Node. It reads the current
version and deck data rather than hard-coding v0.5.4. It locates the first
appendix card page instead of assuming that the appendix is a table.

For optional browser PDF rebuilding (requires a runnable Chromium):

    DS_AUDIT_CHROMIUM=/path/to/chromium python3 source/paper/verify-printables.py . --output-dir /tmp/ds-print-check --rebuild-pdfs

For the focused checks, replace /path/to/repo with the checkout path:

    node card-edge-cases.cjs /path/to/repo
    node competition-check.cjs /path/to/repo

The negative-control script expects this evidence directory beside a checkout
named dominant-species-solo. Its temporary changed PDFs are not retained.

## Verification limits

Current shipped PDFs were rendered with PyMuPDF and visually inspected.
The rulebook contains nine rules pages and six cut-out card pages; the aids
contain ten sheets. Appendix and standalone cards agree in content and cut
geometry. They are not pixel-identical: inherited line-height shifts the
card title/actions slightly inside the same borders. No clipping was found.

Chromium cannot start in this environment because socket creation is denied.
A fresh browser UI run and regenerated-PDF pixel comparison were therefore
not completed. The failed optional command is retained as evidence; it is
not a failed application test. The app does rebuild byte for byte.
No new balance simulations were run, because the app is unchanged.

## Builder coverage observation (T1)

The existing check_aids searches for row labels across the complete aid HTML.
Deleting the Execution Migration row still passes because Planning also has
a Migration row. The adapted verifier checks these tables separately and
checks all of their rendered text. The current published aids contain every
required row; this observation concerns the guard, not missing current text.

No game rules, generated printables or app files were changed by this audit.
Only the verification script was added locally; nothing was pushed.
'''
(ROOT/'README.md').write_text(readme)
styles=getSampleStyleSheet()
styles.add(ParagraphStyle(name='Title2',fontName='Helvetica-Bold',fontSize=22,leading=26,textColor=colors.HexColor('#244734'),spaceAfter=12))
styles.add(ParagraphStyle(name='Deck',fontName='Helvetica',fontSize=11,leading=16,textColor=colors.HexColor('#4e5a54'),spaceAfter=12))
styles.add(ParagraphStyle(name='Body2',fontName='Helvetica',fontSize=10,leading=14,spaceAfter=8))
styles.add(ParagraphStyle(name='Cell2',fontName='Helvetica',fontSize=8.8,leading=11.8))
styles.add(ParagraphStyle(name='Head2',fontName='Helvetica-Bold',fontSize=13,leading=17,textColor=colors.HexColor('#244734'),spaceBefore=12,spaceAfter=8))
story=[]
def p(text,style='Body2'):return Paragraph(text,styles[style])
def add(text,style='Body2'):story.append(p(text,style))
def table(rows,widths=None):
 data=[[p(escape(str(x)),'Cell2') for x in row] for row in rows]
 t=Table(data,colWidths=widths or [140,382],repeatRows=1,hAlign='LEFT')
 t.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),colors.HexColor('#e5ede5')),('VALIGN',(0,0),(-1,-1),'TOP'),('GRID',(0,0),(-1,-1),.4,colors.HexColor('#a5b4a5')),('LEFTPADDING',(0,0),(-1,-1),7),('RIGHTPADDING',(0,0),(-1,-1),7),('TOPPADDING',(0,0),(-1,-1),6),('BOTTOMPADDING',(0,0),(-1,-1),6)]))
 story.append(t)
def page(title):story.append(PageBreak());add(title,'Title2')
add('Dominant Species<br/>Printables audit','Title2')
add('v0.5.4 / commit e7a9726 / 15 November 2026','Deck')
add('<b>Pass, with one minor Aquatic wording clarification recommended.</b> The ten aid sheets agree with the rulebook. The new Mass Exodus fallback and clarified Competition +6 agree with the app. No new app defect or printing defect was found.')
add('The remaining wording gap is inherited from the rulebook: Aquatic says to compare placements using four species, even when fewer remain in the gene pool. The app correctly uses the available number. The prepared save demonstrates a different tile choice.')
table([['Check','Result'],['Release identity','e7a9726c9be7a77cc79cebedaab0b5701d04fee7; app build remains 4ed8110d...'],['App and repository tests','App rebuild is byte-identical; no app-source changes from 158c9d8; 49/49 tests pass.'],['Rulebook and cut-out cards','15 pages: nine rules pages, then six card pages. All 48 appendix faces and all 48 standalone faces match the No-face deck data.'],['Player aids','Ten sheets: four references and six rivals. All 48 rival deck rows, setup counts, elements, food-chain order and priority lists checked.'],['Publication fidelity','All PDF text accounted for against the corresponding HTML, with ordered blocks checked; all four generated HTML/Markdown files rebuild byte for byte.'],['Visual review','Rendered and inspected all publication pages, using full-size views and contact sheets. No clipped rows, missing text or overlapping cards found.']])
add('Scope','Head2')
add('Started with AUDIT_RESPONSE_v0.5.4.md and the printables changelog entry. Read the aid template, generator, paper rules, deck/data sources and relevant app decisions line by line. The evidence includes an explicit review record for '+str(len(review))+' substantive aid blocks. This was a printables/parity audit, not a new balance measurement.')
page('P3 / Aquatic: compare available species')
add('Low priority / inherited wording / no app change needed','Deck')
add('<b>Locations:</b> aid sheet 3, Aquatic; rulebook page 5, Aquatic; source/paper/AIDS.html and source/paper/RULES.md. App: paperEffect, Aquatic branch, uses <font face="Courier">n = Math.min(4, me.pool)</font>.')
add('The printed instruction compares where four species make the rival first. With only one species available, the app evaluates the rank after adding one. Both documents should state that limit in the comparison, rather than only relying on the normal component limit when placing cubes.')
table([['Candidate','Before','After +1','After +4'],['D2 Wetland (8 VP)','Birds rank 2','Birds rank 1','Birds rank 1'],['E2 Sea (9 VP)','Birds rank 2','Birds rank 2','Birds rank 1']],[192,110,110,110])
add('The constructed, inventory-valid save has one Bird left in its gene pool. It legally scores C4, claims Aquatic, and reaches the effect. The app selects D2 and adds one Bird. A literal four-species comparison selects E2, since both candidates then make Birds first and Sea wins the value tie. This demonstrates the ambiguity; it does not measure its frequency.')
add('Suggested wording in both documents','Head2')
add('<b>Use the number of species it can add from its gene pool (up to 4) for every rank comparison.</b> Then refer to "those species" instead of "4 species" in the target-selection sentence. Keep the remaining element, corner and tie priorities unchanged.')
add('T1 / Existing builder guard is weaker than its description','Head2')
add('The current check_aids function searches for each row label anywhere in the complete aids HTML. Removing the Execution Migration row still passes because the Planning table contains the same label. The published aids do contain the row. The adapted verifier now checks the Planning, Execution and Dominance Card tables separately and checks their complete rendered text.')
add('Four deliberate faults were rejected: a missing appendix page, a changed source card name, a removed PDF word, and a reversed priority sequence with identical character counts. This supplements the successful checks on the actual release.')
page('Sheets 1 and 2 / detailed coverage')
add('Planning, execution and the shared tie rules','Deck')
table([['Aid content','App comparison / outcome'],['Planning opening; draw/discard; six steps','enterSupply, drawCard, paperPlacement. Initial rival round, repeat/weak filters, caps and fallback order agree.'],['Targets: all 12 action rows','paperLegal. Migration uses an actual permitted move; Barren/Empty Earth and Domination target conditions agree.'],['Best space; full display; count/leader terms','paperSlotScore, currentPlanner, pLeader, match, cone. Types ignored for rival matches; species then food chain in new-game rival ties.'],['Initiative / Adaptation / Regression','paperPawn and paperLoss. No-card relocation, printed-element preference and Regression tie order agree.'],['Abundance / Wasteland / Depletion','paperPawn and pDepletionCorners. Element choice, corner priorities, Empty Earth and opponent/leader cone counts agree.'],['Glaciation / Speciation','paperGlaciationTile and paperSpeciation. Opposing/own species priority, matched tile count, summed values and pool-limited placement agree.'],['Wanderlust and arriving species','paperWanderlust and botAction arrival. Spot, stack, leftmost used element, corner priority and rank-safe arrivals agree.'],['Migration: all six aid bullets','paperMigration. Rescue, no-rank-loss origin, matched destination, fresh tile, one direction per tile and all tie priorities agree.'],['Competition and Arachnids score','paperCompetition and paperHitScore. Terrain coverage, VP-order/board-order ties and all score terms agree.'],['Domination','paperPawn. Dominated/card-available priority, safe tiles, own VP and fallback agree.'],['General ties; first-place values','pBy/pPlaceCmp and TERRAIN. Row-specific exceptions take precedence; remaining tile and corner ties agree.']])
add('Competition +6: focused checks','Head2')
add('On Savannah (value 7), removing a dominant opponent\'s last species scores 23.5; removing a non-dominant opponent\'s last species scores 10.5. When removing one of two Mammals ends their dominance but leaves a Mammal there, the score is 7: no +6 is awarded. The rulebook, sheet 2 and Arachnids sheet all state this correctly.')
page('Sheet 3 / Dominance Card coverage')
table([['Card or instruction','Result'],['Taking a card; skips; all-skipped fallback','All 26 priorities agree with PAPER_CARD_ORDER. Pawn cap, Ice Age, and the five new card skips agree with paperClaim/paperCardIdle.'],['No-choice cards; element order','The 12 no-choice names and six-element tie order agree with the app.'],['Aquatic','All element/corner/candidate priorities agree; P3 qualifies the available species used for rank comparisons.'],['Biomass / Predator','Opponent in VP order, and own-only Biomass fallback, agree.'],['Blight','Damage, own-species penalty and tile/kept-disk ties agree, reading damage as species newly left without a match.'],['Catastrophe','Weighted removals, own survivor, lowest-VP/lower-food-chain survivor and adjacent victims agree.'],['Evolution','At most two opponents, VP order, matched tiles, rank/value scoring and +3 dominance agree.'],['Fecundity / Fertile','Matched/value order and pool limit; Fertile counts all species and breaks ties by board order.'],['Habitat','Printed element, earliest added element, element order and all corner fallbacks agree.'],['Hibernation / Ice Sheet','Matched tile priorities and Glaciation choice agree. Hibernation uses the returned amount for rank gain.'],['Instinct','No-card Planning steps, unresolved-space priority and next-turn reservation/final-turn restriction agree.'],['Mass Exodus','Revised occupied/adjacent source selection, own-species avoidance, opposing count and all source/destination ties agree.'],['Metamorphosis','Discard/usefulness order, earliest-added tie, printed-type preference and element order agree.']])
add('Mass Exodus closure','Head2')
add('The replacement now covers the previously omitted case where the rival occupies every tile. The new repository test checks both the constructed fallback and the prior audit save (D3: one Mammal to D2; three Insects to D4). It passes in the 49-test run. The aid preserves every priority in the replacement sentence.')
add('Review boundary','Head2')
add('The shared normal-game rules still supply card effects and legality; the aids are condensed references. I did not classify unreachable defensive code paths as tabletop omissions: for example, a rival that has just claimed Hibernation necessarily matched its scoring tile.')
page('Sheet 4, rival sheets and verifier')
table([['Area','Outcome'],['Setup and difficulty','All four player-count rows and four levels agree with app data and current offsets. Five-rival Easy is 2 pawns each and 4 for the human.'],['Terms and turn sequence','VP order, ranking below scoring places, entering the ranking, board order and cone updates agree.'],['Other decisions','Arachnids, Insects, Mammals, element losses, Immigrants and protected cubes agree. Arrival after Wanderlust is correctly moved to sheet 2.'],['Six rival sheets','Each has eight correct No-face card rows; printed element/affinity and food-chain relations agree. Powers and repeated Planning/element/tie instructions agree.'],['New verifier','Finds the card appendix dynamically; validates both columns of all card pages; checks all ten aid PDFs, ordered text blocks, per-table coverage, deck rows and generated data.'],['Rebuild','Rulebook Markdown plus rulebook/cards/aids HTML regenerate byte for byte. The app also rebuilds byte for byte.']])
add('Layout and reproducibility limits','Head2')
add('The appendix and standalone cards have identical text, order and 3.5-by-2.4-inch design geometry. They are not pixel-identical: inherited rulebook line-height moves card titles/actions slightly within the same borders. This is cosmetic and causes no clipping.')
add('Chromium could not start because this execution environment denies socket creation. A fresh browser UI run and regenerated-PDF comparison were therefore not completed. Current PDFs were rendered directly and inspected; complete text fidelity and source regeneration passed. The optional PDF-rebuild mode is included for a normal Chromium environment.')
add('Files and handoff','Head2')
add('The evidence ZIP contains verify-printables.py and an apply-ready patch, the full aid review ledger, verification output, focused tests, the Aquatic save, provenance hashes and reproduction commands. The intended script location is source/paper/verify-printables.py.')
add('<b>Changes made:</b> added the adapted verifier locally. No rules, printables or app files were edited; nothing was pushed. P3 can be resolved by the small text clarification in both source documents, followed by regenerating the printables.')
add('This audit does not replace the earlier gameplay/balance audits, and makes no new human-win-rate claim.')

def footer(canvas,doc):
 canvas.saveState();canvas.setStrokeColor(colors.HexColor('#a5b4a5'));canvas.line(45,36,567,36)
 canvas.setFont('Helvetica',8);canvas.setFillColor(colors.HexColor('#4e5a54'));canvas.drawString(45,24,'Dominant Species Solo / e7a9726 / printables audit');canvas.drawRightString(567,24,str(doc.page));canvas.restoreState()
file=OUT/'Dominant_Species_v0.5.4_Printables_Audit.pdf'
SimpleDocTemplate(str(file),pagesize=(612,792),rightMargin=45,leftMargin=45,topMargin=40,bottomMargin=48,title='Dominant Species v0.5.4 Printables Audit',author='ChatGPT').build(story,onFirstPage=footer,onLaterPages=footer)
print('Report:',file)
print('Aid review units:',len(review))
