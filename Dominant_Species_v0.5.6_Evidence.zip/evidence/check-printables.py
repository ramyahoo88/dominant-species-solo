"""Report exact shipped PDF drift, then verify other content and geometry.

The unchanged release verifier must fail on this release. Card checks use
temporary HTML expectations matching the two observed PDF phrases. Prose
failures are recorded and allow inspection to continue. This never changes
the release failure into a pass or modifies the pinned checkout.
"""
from pathlib import Path
import json
import runpy
import shutil
import sys

repo = Path(sys.argv[1]).resolve()
output = Path(sys.argv[2]).resolve()
output.mkdir(parents=True, exist_ok=True)
audit_repo = output / 'observed-pdf-wording'
for folder in ['paper', 'source/paper', 'source/src']:
    (audit_repo / folder).mkdir(parents=True, exist_ok=True)
for file in (repo / 'paper').iterdir():
    if file.suffix in ['.html', '.pdf', '.md']:
        shutil.copy2(file, audit_repo / 'paper' / file.name)
for name in ['data.js', 'decks.js']:
    shutil.copy2(repo / 'source/src' / name, audit_repo / 'source/src' / name)
for name in ['RULES.md', 'AIDS.html', 'paper.js', 'ladder.json']:
    shutil.copy2(repo / 'source/paper' / name, audit_repo / 'source/paper' / name)

phrases = {
    'a rescue, or 1 of 2+ species (no rank lost) to a new matched tile':
        'a rescue, or a spare species (no rank lost) to a new matched tile',
    'a box element it uses; empty corner on its tile (exceptions: aid 1)':
        'a box element it uses; empty corner on its tile (Empty Earth: any)',
}
counts = {}
for name in ['Cards', 'Rulebook']:
    file = audit_repo / f'paper/The_Red_Queen_{name}.html'
    text = file.read_text()
    counts[name] = {before: text.count(before) for before in phrases}
    for before, after in phrases.items():
        assert text.count(before) > 0
        text = text.replace(before, after)
    file.write_text(text)

verifier = runpy.run_path(str(repo / 'source/paper/verify-printables.py'))
original_fidelity = verifier['text_fidelity']
prose_failures = []
def collect_fidelity(node, pdf_text, label, book=False):
    try:
        return original_fidelity(node, pdf_text, label, book)
    except AssertionError as error:
        actual = verifier['normal'](pdf_text)
        missing_blocks = []
        for block in node.all():
            if block.tag not in ['p', 'li', 'tr']:
                continue
            if block.tag == 'li' and any(block.all('li')):
                continue
            if verifier['normal'](block.text()) not in actual:
                missing_blocks.append(block.text())
        record = {'label': label, 'error': str(error), 'missingOrChangedBlocks': missing_blocks}
        prose_failures.append(record)
        return record
verifier['verify'].__globals__['text_fidelity'] = collect_fidelity
report = verifier['verify'](audit_repo, output / 'remaining-print-checks')
report['releaseVerdict'] = 'FAIL exact PDF text fidelity. Card reminders and rule/aid paragraphs differ from the shipped source.'
report['allowedDifferencesForRemainingChecks'] = phrases
report['differenceCounts'] = counts
report['proseFailures'] = prose_failures

# Rebuild source outputs in the scratch copy and require byte identity.
producer = runpy.run_path(str(repo / 'source/paper/printables.py'))['main']
producer.__globals__['SRC'] = audit_repo / 'source'
producer.__globals__['OUT'] = audit_repo / 'paper'
sys.argv = ['printables.py']
producer()
files = ['paper/The_Red_Queen_Rulebook.md', 'paper/The_Red_Queen_Rulebook.html',
         'paper/The_Red_Queen_Cards.html', 'paper/The_Red_Queen_Player_Aids.html', 'source/paper/rq_embed.js']
report['generatedSourcesMatch'] = {name: (repo / name).read_bytes() == (audit_repo / name).read_bytes() for name in files}
assert all(report['generatedSourcesMatch'].values()), report['generatedSourcesMatch']

# Compare every in-app card face with the corresponding generated printable HTML.
faces = json.loads((output.parents[1] / 'evidence/cards-only/card-faces.json').read_text())
document = verifier['Document']((repo / 'paper/The_Red_Queen_Cards.html').read_text())
fronts = list(document.body.all('div', 'front'))
assert len(faces) == len(fronts) == 48
for face, printed in zip(faces, fronts):
    shown = verifier['Document']('<body>' + face['html'] + '</body>').body
    for card_cls, app_cls in [('who','rq-who'),('meta','rq-meta'),('num','rq-num'),('name','rq-name'),('foot','rq-foot')]:
        assert verifier['normal'](verifier['child_text'](printed,card_cls)) == verifier['normal'](verifier['child_text'](shown,app_cls))
    for app_row, print_row in zip(shown.all('li'), printed.all('li')):
        assert verifier['normal'](app_row.text()) == verifier['normal'](print_row.text())
        assert app_row.attrs.get('class') == print_row.attrs.get('class')
report['inAppFacesMatchPrintableHTML'] = 48
(output / 'printable-review.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({'releaseVerdict': report['releaseVerdict'], 'differences': counts,
                 'proseFailures': prose_failures,
                 'cardGeometryAndIdentities': 'PASS with recorded card wording differences',
                 'inAppFacesMatchPrintableHTML': 48,
                 'generatedSourcesMatch': report['generatedSourcesMatch']}, indent=2))
raise SystemExit(1)  # The exact shipped PDFs fail publication fidelity.
