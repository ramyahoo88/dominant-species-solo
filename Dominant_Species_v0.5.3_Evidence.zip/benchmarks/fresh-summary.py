"""Summarize exact win counts and matched-stratum uncertainty on fresh seeds."""
import json
import math
from pathlib import Path
from random import Random
from statistics import mean, stdev
import sys

ROOT=Path(__file__).resolve().parent
RAW=json.loads((ROOT/'fresh-results.json').read_text())
PARTIAL='--partial' in sys.argv
if not PARTIAL:
    assert RAW['done']==RAW['setups'] and RAW['errors']==0
data=[r for r in RAW['rows'] if r]
FIXED=('dominance','majority','expansion')
VERSIONS=('v3','v4')
MODES=('hard',)
N_BOOT=3000

if not PARTIAL:
    assert len(data) == 1440 and RAW['games'] == 14400
    for n in range(2,6):
        rows = [r for r in data if len(r['setup']['rivals']) == n]
        assert len(rows)==360 and sum(r['setup']['short'] for r in rows)==180
        assert {r['setup']['seed'] for r in rows} == set(range(RAW['seedBlock']+1000*n,RAW['seedBlock']+1000*n+360))
        assert all(set(r['cells']) == {'app','hard'} for r in rows)


def subset(mode,n):
    return [r for r in data if len(r['setup']['rivals'])==n and mode in r['cells']]


def rate(rows,mode,profile):
    return mean(r['cells'][mode][profile]['win'] for r in rows)


def metrics(rows,mode,profile):
    records=[r['cells'][mode][profile] for r in rows]
    wins=sum(g['win'] for g in records)
    rounds=sum(g['metrics']['rounds'] for g in records)
    n=len(records)
    return dict(games=n,wins=wins,winPct=100*wins/n,
                meanTurns=mean(g['turns'] for g in records),
                turnRange=[min(g['turns'] for g in records), max(g['turns'] for g in records)],
                meanMargin=mean(g['humanMargin'] for g in records),
                ties=sum(g['winningMargin']==0 for g in records),
                stalled=sum(g['stalled'] for g in records),
                firstOnTrack=100*sum(g['metrics']['firstOnTrack'] for g in records)/rounds,
                firstPlacement=100*sum(g['metrics']['firstPlacement'] for g in records)/rounds,
                dom1PerGame=mean(g['metrics']['humanDom1'] for g in records),
                humanClaimsPerGame=mean(g['metrics']['humanClaims'] for g in records),
                rivalClaimsPerGame=mean(g['metrics']['rivalClaims'] for g in records))


def logit(p):
    p=min(.995,max(.005,p))                 # Same bounds as the release analysis.
    return math.log(p/(1-p))


def edge_value(samples):
    n=len(samples)
    sums=[sum(s[i] for s in samples)/n for i in range(len(FIXED)+len(VERSIONS))]
    best=max(sums[:len(FIXED)])
    v3,v4=sums[-2:]
    return (logit(v3)-logit(best),logit(v4)-logit(best))


def contrast(paper,app):
    return edge_value(paper)[1]-max(edge_value(app))


def make_pairs(rows,mode):
    names=[*FIXED,*VERSIONS]
    return ([tuple(r['cells'][mode][p]['win'] for p in names) for r in rows],
            [tuple(r['cells']['app'][p]['win'] for p in names) for r in rows])


def bootstrap(groups,seed):
    rng=Random(seed)
    n_draws=300 if PARTIAL else N_BOOT
    per_size=[[] for _ in groups]
    mean_gap=[]
    for _ in range(n_draws):
        current=[]
        for i,(paper,app) in enumerate(groups):
            ids=rng.choices(range(len(paper)),k=len(paper))
            score=contrast([paper[j] for j in ids],[app[j] for j in ids])
            per_size[i].append(score)
            current.append(score)
        mean_gap.append(mean(current))
    def ci(xs):
        xs.sort()
        return [xs[int(len(xs)*.025)],xs[int(len(xs)*.975)]]
    return [ci(x) for x in per_size],ci(mean_gap)


def paired_pp(items):
    center=100*mean(items)
    if len(items)<2:
        return {'n':len(items),'pp':center,'approximate95':None}
    radius=100*1.96*stdev(items)/math.sqrt(len(items))
    return {'n':len(items),'pp':center,'approximate95':[center-radius,center+radius]}


game_stats={}
for mode,settings in RAW['modes'].items():
    cases=[r for r in data if mode in r['cells']]
    game_stats[mode]={
        'pooled':{p:metrics(cases,mode,p) for p in settings['profiles']},
        'sizes':{n:{p:metrics(subset(mode,n),mode,p) for p in settings['profiles']}
                 for n in range(2,6) if subset(mode,n)},
    }

gaps={}
gains={}
for i,mode in enumerate(MODES):
    sizes=[n for n in range(2,6) if subset(mode,n)]
    if not {3,4,5}<=set(sizes):
        continue
    groups={n:make_pairs(subset(mode,n),mode) for n in sizes}
    by_size,ci35=bootstrap([groups[n] for n in (3,4,5)],51000+i)
    intervals = dict(zip((3,4,5),by_size))
    if 2 in groups:
        intervals[2]=bootstrap([groups[2]],51050+i)[0][0]
    estimates={n:contrast(*pair) for n,pair in groups.items()}
    gaps[mode]={
        'mean3to5':mean(estimates[n] for n in (3,4,5)),
        'approximateBootstrap95':ci35,
        'perSize':{n:{'point':estimates[n],'approximateBootstrap95':interval}
                  for n,interval in sorted(intervals.items())},
    }
    rows=[r for r in data if mode in r['cells']]
    def v_gain(r,name):
        cell=r['cells'][name]
        return int(cell['v4']['win'])-int(cell['v3']['win'])
    gains[mode]={'paper':paired_pp([v_gain(r,mode) for r in rows]),
                 'appOnSameSetups':paired_pp([v_gain(r,'app') for r in rows]),
                 'paperMinusApp':paired_pp([v_gain(r,mode)-v_gain(r,'app') for r in rows])}

hard_app={}
for lo in (2,3):
    cases=[r for r in data if len(r['setup']['rivals'])>=lo and 'hard' in r['cells']]
    def win(r,mode,profile):
        return int(r['cells'][mode][profile]['win'])
    hard_app[f'{lo}to5']={
        p:paired_pp([win(r,'hard',p)-win(r,'app',p) for r in cases]) for p in [*FIXED,*VERSIONS]
    }
    hard_app[f'{lo}to5']['v4GapOverDominance'] = paired_pp(
        [(win(r,'hard','v4')-win(r,'hard','dominance'))-(win(r,'app','v4')-win(r,'app','dominance'))
          for r in cases])

out={k:RAW[k] for k in ('commit','seedBlock','done','games','errors','stalls')}
out.update({'levels':game_stats,'extraLogOdds':gaps,'hardApp':hard_app,'retuneGains':gains,'bootstrapN':300 if PARTIAL else N_BOOT})
dest='fresh-partial.json' if PARTIAL else 'fresh-summary.json'
(ROOT/dest).write_text(json.dumps(out,indent=2)+'\n')
print(f"{out['done']} setups, {out['games']} games, {out['errors']} errors, {out['stalls']} stalls")
for mode,row in game_stats.items():
    print(mode, ' '.join(f"{p} {stats['wins']}/{stats['games']} ({stats['winPct']:.2f}%)" for p,stats in row['pooled'].items()))
for mode,vals in gaps.items():
    print(mode,'mean log-odds excess 3-5:',round(vals['mean3to5'],3),
          '95%:',[round(x,3) for x in vals['approximateBootstrap95']],
          'by size:',{k:round(v['point'],3) for k,v in vals['perSize'].items()})
