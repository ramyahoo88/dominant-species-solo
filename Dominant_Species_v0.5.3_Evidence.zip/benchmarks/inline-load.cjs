const assert = require('node:assert/strict');
const {execFileSync} = require('node:child_process');
const {readFileSync} = require('node:fs');
const {join} = require('node:path');

// Same sources and adapter as benchmark/load.cjs, in a function scope so V8
// can optimize hot calls without accessing a separate VM's global object.
function inlineLoad(repo, ref, extra, append) {
  const read = path => ref === 'worktree'
    ? readFileSync(join(repo, path), 'utf8')
    : execFileSync('git', ['-C', repo, 'show', `${ref}:${path}`], {encoding: 'utf8'});
  const modules = ['data', 'decks', 'engine', 'bot', 'effects', 'ui'];
  const paths = [];
  for (const name of modules) {
    paths.push(`source/src/${name}.js`);
    if (name === 'effects' && read('source/build.py').includes('../paper/paper')) {
      paths.push('source/paper/paper.js');
    }
  }
  const benchmark = ['legality', ...extra].map(name =>
    readFileSync(join(repo, `source/benchmark/${name}.js`), 'utf8'));
  const adapter = readFileSync(join(repo, 'source/benchmark/load.cjs'), 'utf8')
    .match(/\bruntime\.run\(`([\s\S]*?)`\);/);
  assert(adapter, 'The repository benchmark adapter could not be located');
  const code = [...paths.map(read), ...benchmark, extra.includes('player') ? adapter[1] : '', append];
  return new Function('document', code.join('\n\n'))({getElementById: () => ({})});
}

module.exports = {inlineLoad};
