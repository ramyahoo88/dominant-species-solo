const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const root = __dirname;
const repo = path.resolve(process.argv[2] || path.join(root, '../dominant-species-audit-v051'));
const {load} = require(path.join(repo, 'source/benchmark/load.cjs'));
const rt = load('worktree', ['game']);
const copy = value => JSON.parse(JSON.stringify(value));
const get = name => rt.get(name);
const step = {kind:'pawn', row:'abundance', index:0, key:'abundance-0', actor:'mammals'};
const save = (name, game) => fs.writeFileSync(path.join(root, 'saves', name+'.json'),
  JSON.stringify({format:'dominant-species-solo-v1', game}, null, 2)+'\n');

function emptyPosition(ref='worktree') {
  const runtime = ref==='worktree' ? rt : load(ref, ['game']);
  const s = runtime.get('newGame')('birds', ['mammals','insects'], true, 7, {extra:-1});
  s.turn = 5;
  for (const tile of Object.values(s.tiles)) for (const id of s.ids) {
    s.animals[id].dead += tile.cubes[id];
    tile.cubes[id] = 0;
  }
  s.corners = {};
  s.boxes.abundance = ['grub','water',null,null];
  s.phase = 'execution';
  s.cursor = runtime.get('EXECUTION').indexOf('abundance-0');
  s.pawns = {'abundance-0':{actor:'mammals',card:null,focus:null}};
  runtime.get('validateState')(copy(s));
  return s;
}

const s = emptyPosition();
assert(get('paperEmptyEarth')(s));
assert(get('paperLegal')(s,'mammals','abundance',0));
assert.equal(get('paperPlacement')(s,'insects',0).slot, 'abundance-1');
const initial = get('paperPawn')(s, step);
assert.equal(initial.pick, 0);
assert(initial.corner && get('activeCorners')(s).includes(initial.corner));
const placed = copy(s);
get('runStep')(placed, step, initial);
get('validateState')(placed);
assert.equal(placed.corners[initial.corner], 'grub');
assert.equal(placed.boxes.abundance[0], null);

const typePreference = copy(s);
typePreference.animals.mammals.added = ['water'];
assert.equal(get('paperPawn')(typePreference,step).pick, 1);

const occupiedCorner = copy(s);
occupiedCorner.corners[initial.corner] = 'seed';
assert.notEqual(get('paperPawn')(occupiedCorner,step).corner,initial.corner);
const noDisk = copy(s);
noDisk.boxes.abundance = [];
assert(!get('paperLegal')(noDisk,'mammals','abundance',0));
assert(get('paperPawn')(noDisk,step).pass);

const noCorner = copy(s);
const types = Array.from(get('ELEMENT_IDS'));
get('activeCorners')(s).forEach((key,i) => noCorner.corners[key]=types[i%types.length]);
get('validateState')(noCorner);
assert(!get('paperLegal')(noCorner,'mammals','abundance',0));
assert(get('paperPawn')(noCorner,step).pass);

const survivors = [];
for (const actor of s.ids) {
  const alive = copy(s);
  alive.tiles.D3.cubes[actor] = 1;
  alive.animals[actor].dead--;
  get('validateState')(alive);
  assert(!get('paperEmptyEarth')(alive));
  assert.equal(get('paperLegal')(alive,'mammals','abundance',0), actor==='mammals');
  assert.equal(Boolean(get('paperPawn')(alive,step).pass), actor!=='mammals');
  survivors.push(actor);
}

const changedAtExecution = copy(s);
changedAtExecution.tiles.D3.cubes.insects = 1;
changedAtExecution.animals.insects.dead--;
assert(get('paperPawn')(changedAtExecution,step).pass);
changedAtExecution.tiles.D3.cubes.insects = 0;
changedAtExecution.animals.insects.dead++;
assert(get('paperPawn')(changedAtExecution,step).corner);

const legacy=[];
for (const [ref,label,filename] of [['d84e7e9','Easy','v041-empty-execution'],['4ac6bd8','Easy','v039-empty-execution']]) {
  const old = emptyPosition(ref);
  // v0.3.9's ordinary Easy level was zero extra pawns.
  if (ref==='4ac6bd8') {
    old.paper.extra=0;
    for (const id of old.rivals) old.animals[id].ap++;
  }
  save(filename,old);
  const migrated = get('validateState')(copy(old));
  assert.equal(migrated.paper.level,label);
  assert(!migrated.paper.planFirst);
  assert.equal(Boolean(migrated.paper.rivalTie),ref==='d84e7e9');
  assert(get('paperLegal')(migrated,'mammals','abundance',0));
  assert(get('paperPawn')(migrated,step).corner);
  legacy.push({savedVersion:old.version,level:migrated.paper.level,extra:migrated.paper.extra,
    choice:copy(get('paperPawn')(migrated,step)),planFirst:!!migrated.paper.planFirst,rivalTie:!!migrated.paper.rivalTie});
}

const archived = JSON.parse(fs.readFileSync(path.join(root,'saves/published-stall-200074.json'),'utf8')).game;
const exact = get('validateState')(copy(archived));
const physical = get('makeSupplies')(exact,exact.seed);
physical.cards=[];
physical.stacks=[[],[],[]];
const draws = get('nextSupply')(exact,physical,exact.seed);
fs.writeFileSync(path.join(root,'saves/turn31-draws.json'),JSON.stringify(draws,null,2)+'\n');
get('enterSupply')(exact,draws);
save('v050-empty-planning', {...exact,version:'0.5.0'});
while (exact.phase==='planning') {
  if (get('currentPlanner')(exact).actor===exact.human) {
    get('place')(exact, get('ALL_SLOTS').find(k=>!exact.pawns[k]));
  } else get('botPlacement')(exact);
}
while (get('nextStep')(exact)?.key!=='abundance-0') {
  const st=get('nextStep')(exact);
  assert(st.actor!==exact.human,'only rival actions precede this Abundance');
  get('runStep')(exact,st,get('botAction')(exact,st));
}
save('v050-empty-abundance', {...exact,version:'0.5.0'});
const action = copy(get('botAction')(exact,get('nextStep')(exact)));
const [ax,ay] = action.corner.split(',').map(Number);
const northwest = get('activeCorners')(exact).filter(k=>!exact.corners[k]).filter(key=>{
  const [x,y]=key.split(',').map(Number);
  return x<ax && y<ay;
});
const northWestExample='-10,-4';
assert(northwest.includes(northWestExample));
const mismatch={actual:action,strictlyAboveAndLeft:Array.from(northwest),
  example:{corner:northWestExample,tiles:copy(get('CORNER_TILES')[northWestExample]),
    cornerOnA1:get('cornerIndex')('A1',northWestExample)}};
const report={checks:['empty eligibility','Barren Earth priority','disk consumption','preferred element','occupied corner skip',
  'empty box','all corners occupied','human or rival survivor disables exception','Execution rechecks current board'],
  survivorAnimals:Array.from(survivors),legacy,cornerMismatch:mismatch};
fs.writeFileSync(path.join(root,'empty-earth.json'),JSON.stringify(report,null,2)+'\n');
console.log(JSON.stringify(report,null,2));
if (process.argv.includes('--assert-top-left')) {
  assert.equal(northwest.length,0,'Printed top-left choice must have no empty corner strictly above and left of it');
}
