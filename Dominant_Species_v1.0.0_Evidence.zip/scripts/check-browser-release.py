"""Export saves from v0.5.7 and continue in v1.0.0 in offline Chromium."""
import argparse
import json
from pathlib import Path

from playwright.sync_api import expect, sync_playwright


FULL_KEY = 'dominant-species-solo-v1'
DRAW_KEY = 'dominant-species-red-queen-cards-v1'


def storage(page, key):
    return page.evaluate('(key) => JSON.parse(localStorage.getItem(key))', key)


def export_save(page):
    page.locator('#menu').click()
    with page.expect_download() as handled:
        page.locator('.modal-body [data-do=export]').click()
    return handled.value.suggested_filename, Path(handled.value.path()).read_bytes()


def open_save(page, exported):
    name, data = exported
    page.locator('#import-file').set_input_files({
        'name': name, 'mimeType': 'application/json', 'buffer': data,
    })


def compare_without_version(older, newer):
    assert older['version'] == '0.5.7'
    assert newer['version'] == '1.0.0'
    assert {**older, 'version': newer['version']} == newer


def launch_page(browser, html, failures):
    context = browser.new_context(viewport={'width': 390, 'height': 850}, offline=True,
                                  accept_downloads=True, is_mobile=True, has_touch=True)
    page = context.new_page()
    page.on('pageerror', lambda err: failures.append(str(err)))
    page.on('request', lambda req: failures.append(req.url) if req.url.startswith(('http:', 'https:')) else None)
    page.goto(html.resolve().as_uri())
    return context, page


def choose_mode(page, selection, count=5, level='-2'):
    page.locator(f'input[name=count][value="{count}"]').check()
    page.locator(f'input[name=rules][value="{selection}"]').check()
    page.locator(f'input[name=extra][value="{level}"]').check()
    page.locator('form[data-form=start] button[type=submit]').click()


def enter_first_supply(page):
    for row in ['Adaptation', 'Abundance', 'Wanderlust']:
        for el in ['Water', 'Seed', 'Grass', 'Meat']:
            page.get_by_role('button', name=f'Add {el} to {row}', exact=True).click()
    for i, tile in enumerate(['sea', 'wetland', 'forest']):
        page.locator(f'[name=stack-{i}]').select_option(tile)
    for i, card in enumerate(['Aquatic', 'Biodiversity', 'Biomass', 'Blight', 'Catastrophe']):
        page.locator(f'[name=card-{i}]').select_option(card)
    page.get_by_role('button', name='Begin Planning', exact=True).click()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('old_html', type=Path)
    parser.add_argument('new_html', type=Path)
    parser.add_argument('fixtures', type=Path)
    parser.add_argument('chromium')
    args = parser.parse_args()
    issues = []
    with sync_playwright() as pw:
        browser = pw.chromium.launch(executable_path=args.chromium, args=['--no-sandbox'])
        deck_context, deck = launch_page(browser, args.old_html, issues)
        choose_mode(deck, 'draw')
        rival = storage(deck, DRAW_KEY)['draw']['rivals'][0]
        draw = deck.locator(f'[data-do=rq-draw][data-animal="{rival}"]')
        for _ in range(8):
            draw.click()
        old_deck = export_save(deck)
        assert old_deck[0] == 'The_Red_Queen_Cards_Only.json'
        deck.locator('[data-do=close]').click()
        draw.click()
        expected_draw = storage(deck, DRAW_KEY)['draw']
        assert expected_draw['draws'][-1]['reshuffled']

        guided_context, guided = launch_page(browser, args.old_html, issues)
        choose_mode(guided, 'paper', level='-1')
        enter_first_supply(guided)
        guided.locator('[data-do=draw]').click()
        guided.locator('[data-do=next]').click()
        old_guided = export_save(guided)
        guided.locator('[data-do=close]').click()
        assert len(json.loads(old_guided[1])['game']['paper']['pre']) == 4
        guided.locator('[data-do=draw]').click()
        guided.locator('[data-do=next]').click()
        expected_guided = storage(guided, FULL_KEY)['game']

        release_context, release = launch_page(browser, args.new_html, issues)
        open_save(release, old_deck)
        expect(release.locator('.rq-top .eyebrow')).to_contain_text('deck only')
        release.locator(f'[data-do=rq-draw][data-animal="{rival}"]').click()
        compare_without_version(expected_draw, storage(release, DRAW_KEY)['draw'])
        expect(release.locator('.rq-note')).to_contain_text('reshuffled')
        assert storage(release, FULL_KEY) is None

        open_save(release, old_guided)
        expect(release.locator('#turn-focus')).to_have_text('Draw a rival card')
        assert storage(release, DRAW_KEY) is None
        release.locator('[data-do=draw]').click()
        expect(release.locator('.current-card .eyebrow')).to_contain_text(' · card ')
        release.locator('[data-do=next]').click()
        compare_without_version(expected_guided, storage(release, FULL_KEY)['game'])
        print('PASS v0.5.7 files exported via UI, imported into v1.0.0, then played to the same reshuffle and Planning placement')

        for seed, place in [(731260, 'B5 Sea'), (731290, 'D5 Wetland')]:
            fixture = args.fixtures / f'aquatic-seed-{seed}.json'
            open_save(release, (fixture.name, fixture.read_bytes()))
            expect(release.locator('#turn-focus')).to_contain_text('Aquatic')
            release.locator('[data-do=preview]').click()
            expect(release.locator('.result-box').first).to_contain_text(f'Aquatic at {place}')
            release.locator('[data-do=apply]').click()
            result = storage(release, FULL_KEY)['game']
            previous = json.loads(fixture.read_bytes())['game']
            new_corners = {k: v for k, v in result['corners'].items() if k not in previous['corners']}
            assert len(new_corners) == 1
            assert result['tiles'] == previous['tiles']
            print(f'REPRODUCED Aquatic seed {seed}: app applies {place}, changes disk {new_corners}, adds zero cubes')

        assert not issues, issues
        for context in (deck_context, guided_context, release_context):
            context.close()
        browser.close()


if __name__ == '__main__':
    main()
