# Dominant Species Solo v0.5.4 re-audit

Reviewed `ramyahoo88/dominant-species-solo` at `158c9d848e3722863d9dbce391eb1bd5ca75d624`, 15 November 2026. Started with `AUDIT_RESPONSE_v0.5.3.md` and the v0.5.4 `CHANGELOG.md` entry. No production source files were changed. The accompanying PDF gives the verdict, finding, proposed wording, and fresh Hard X35.

The root HTML and separately generated `source/dist/Dominant_Species_Solo.html` are both 472,594 bytes, SHA-256:

```
4ed8110d6d15be58759fab88ec26e6611dc784812c83aecb03a77f8de44afadf
```

## Finding

**P2, low, pre-existing printed omission: Mass Exodus.** `source/paper/RULES.md:124` (printed PDF p. 6) directs the rival to the tile without its species holding the most opposing species. It does not give a fallback when the rival occupies every tile. `source/paper/paper.js:505-518` filters to occupied tiles with a neighbor, then prefers one without the actor's species, then most opposing species, first-place value and board order. The preference is not an eligibility restriction.

In `saves/mass-exodus-own-everywhere.json`, Mammals occupy all seven tiles and Insects have three cubes at D3. The fixture is generated through a legal Domination score and card claim. The app chooses D3: Mammals move one to D2; Insects move three to D4. The literal printed target set is empty. The same choice occurs in v0.5.3. `browser-mass-exodus.json` confirms preview, apply and undo in the shipped HTML, with zero page errors or HTTP(S) requests.

Suggested replacement for the first sentence, preserving behavior:

> Among occupied tiles with an adjacent tile on Earth, prefer one without its own species; then choose the one holding the most opposing species. Break ties by higher first-place value, then board order.

Keep the existing destination instructions. This is a print clarification, not a balance change.

## Requested checks

- **A1 passes:** actual v0.5.3 scaled Easy and legacy v0.5.2 saves show the right turn-1 instructions and counts in Chromium. The full setup matrix still agrees: 96 engine cases and 16 browser table-size/level cases.
- **P1 passes:** all five printed priorities match the archived chooser examples and their browser imports: Wanderlust, Metamorphosis, Immigrants, Aquatic, Catastrophe.
- **Migration passes:** an independent translation of the printed first-move restrictions checked 300 boards and 1,050 rival decisions. 781 permitted, 269 blocked; zero differences and zero preview mutations. Birds' two-tile reach is included. Last-resort placement and later board changes remain legitimate reasons for a Migration pawn to do nothing.
- **Species ties pass:** 1,500 cases check match priority, species priority, food chain, ties including the human, absent animals and zero matches. Browser fixtures verify the resulting card recipient: Insects in a new game, Mammals in a pre-v0.5.4 save. The benchmark player's adapter also includes `speciesTie`.
- **Card skips pass:** both sides of the five predicates; Amphibians' third printed element versus removable added elements; physical empty bag versus one disk returned; all-skipped fallback in priority order; Niche Biomes evaluated after scoring. These five predicates are not an exhaustive detector for every no-effect card.
- **Empty Earth passes:** totally empty and human-only states enable the exception; any surviving rival disables it globally. New and legacy browser saves use the first empty corner in board order. The repository regression reproduces seed 3880436785's stall with the prior Empty Earth condition and verifies recovery under the expanded condition.
- **Old saves pass:** genuine saves from v0.3.6, v0.3.9, v0.4.1, v0.5.0, v0.5.1, v0.5.2 and v0.5.3 preserve counts and saved flags on load, export/import and reload. Each receives the new Migration, card-skip and Empty Earth procedures. Only new games receive `speciesTie`. Browser Help identifies the old tie rule.
- **Printed level table passes:** only pawn adjustments, including the five-rival Easy exception. The requested descriptive difficulty language is absent from that table.
- **Release checks:** 48/48 repository tests, the benchmark self-test, the original Extinction saves, exact build hash, identical regenerated Markdown and print HTML, all 48 PDF card faces versus deck data. The entire 12-page rulebook PDF matches its HTML after removing five verified repeated continuation headers; the 12 pages were visually reviewed.

## Reproduce the checks

Use a full-history checkout, with Node.js 24 and Python 3.12. Set `REPO` to its absolute path. Run from this extracted evidence directory.

```sh
git -C "$REPO" checkout --detach 158c9d848e3722863d9dbce391eb1bd5ca75d624
python3 "$REPO/source/build.py"
sha256sum "$REPO/Dominant_Species_Solo.html" "$REPO/source/dist/Dominant_Species_Solo.html"
node --test "$REPO/source/rules.test.cjs"
node "$REPO/source/benchmark.cjs" --selftest
node focused.cjs "$REPO"
node remaining-ties.cjs "$REPO"
node check-new-element-wording.cjs "$REPO"
node rule-parity.cjs "$REPO"
node mass-exodus-wording.cjs "$REPO"
python3 verify-printables.py "$REPO" --rebuild
```

With Python Playwright and Chromium:

```sh
export DS_AUDIT_CHROMIUM=/absolute/path/to/chrome-headless-shell
export DS_AUDIT_REPO="$REPO"
python3 run-browser.py "$REPO/source/browser_setup_text_test.py" "$REPO/Dominant_Species_Solo.html"
python3 browser-focused.py
python3 browser-remaining-ties.py
python3 browser-rule-parity.py
python3 browser-mass-exodus.py
```

Successful runs used Chromium 131.0.6778.204, offline contexts and 390-pixel viewports. The wrapper removes the environment's need to locate a browser automatically. Do not use `--single-process` when running the setup test's multiple browser contexts. Audit browser scripts wait for asynchronous file import before taking their state snapshot. Report generation additionally needs ReportLab; print verification needs PyMuPDF and Python-Markdown.

## Fresh Hard X35 protocol

**Result:** X35 = **-0.434876**, 95% matched-setup percentile-bootstrap interval **[-0.727736, -0.102353]**. The average and its interval are below the +0.20 target. All 14,400 games completed with zero errors and zero turn-cap stalls. By rival count, X is -0.531403 (three), -0.520299 (four), -0.252926 (five); the two-rival control is -0.719166. These are averages and estimates, not a claim that every individual table size's interval clears the threshold.

The previous audit's frozen protocol, on new seeds. 360 matched setups per table size (two, three, four and five rivals), 1,440 setups and 14,400 games total. Every setup runs five policies (Domination, majority, expansion, tuned v3, tuned v4) at Paper Hard and App. Human animals, rival combinations and deck length are balanced; each size has 180 full and 180 short games. Weights were not retuned.

Seed ranges: 1142000-1142359, 1143000-1143359, 1144000-1144359, 1145000-1145359. These are distinct from the previous audit and the repository's recorded study seed blocks.

```sh
DS_AUDIT_SEED_BLOCK=1140000 DS_AUDIT_INLINE=1 node benchmarks/fresh.cjs "$REPO" 6 360
python3 benchmarks/fresh-summary.py
python3 benchmarks/verify-metric.py "$REPO"
DS_AUDIT_SEED_BLOCK=1140000 node benchmarks/fresh.cjs "$REPO" 4 6 loader-vm-parity.json
python3 verify-loader-parity.py
python3 make-report.py
```

`benchmarks/fresh-summary.json` contains the exact result and confidence interval. `benchmarks/fresh-results.json` retains every setup, outcome, winning margin, human margin, length and instrumented count. Capped or erroneous outcomes are recorded rather than silently excluded. Every step uses the repository's state validator, with its ordinary 30-turn cap.

For each rival count, X is v4's Hard log-odds advantage over the best of the three fixed policies, minus the better v3/v4 App log-odds advantage over the best fixed App policy. X35 is the equally weighted mean of X at three, four and five rivals. Two rivals are separately reported. Probabilities are clamped to [0.005, 0.995], as in the release helper. The 3,000-draw percentile bootstrap resamples complete paired setups within each table-size stratum and reselects comparators on every draw. `verify-metric.py` checks agreement with `final_eval.py` to displayed precision.

The inline loader packages the same source and pinned-player adapter in a function scope so V8 can optimize calls. The standard VM loader independently repeats 24 matched setups (240 games). All per-game outcomes, margins, turn/step counts and instrumentation counters must match. The player reference is the repository's pinned v0.2.0 helper commit, with the existing legal-rules adapter; the separately measured pb5 player is outside this frozen protocol.

This is an audit of the specified changes and selected regressions, not proof that every base-game rule or possible position is correct. No physical tabletop test was performed. Scripted win rates do not predict a person's win rate or establish enjoyment and administration cost.

## Evidence index

- `rule-parity.json`: independently enumerated rule checks and actual historical save migration results.
- `focused-results.json`, `browser-focused.json`: setup matrix, original Extinction saves, and legacy Easy counts.
- `remaining-ties.json`, `browser-remaining-ties.json`, `new-element-wording.json`: P1 chooser decisions.
- `browser-rule-parity.json`: new/old card recipient, Empty Earth, seven historical export/import/reload checks.
- `mass-exodus-wording.json`, `browser-mass-exodus.json`: the printed fallback omission and v0.5.3 comparison.
- `print-observations.json`, `print-qa/`: print regeneration, full text/deck parity and visual-review contact sheets.
- `saves/`, `original-saves/`: loadable positions, including unchanged original Extinction evidence.
- `benchmarks/`: frozen scripts, raw outcomes and full statistical summary.
- `logs/`: successful check output; `release-verification.json` records source and build hashes.

Verify archive contents with `sha256sum -c SHA256SUMS.txt`.
