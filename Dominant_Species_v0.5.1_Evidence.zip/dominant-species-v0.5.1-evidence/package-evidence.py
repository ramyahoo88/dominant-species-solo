"""Package the completed report and reproducible audit evidence."""
import hashlib
import json
import shutil
import zipfile
from pathlib import Path

root=Path(__file__).resolve().parent
assert json.loads((root/'validation.json').read_text())['passed']
pdf=root.parent/'Dominant_Species_v0.5.1_Reaudit.pdf'
assert pdf.is_file()
omit={'delivery.json','publication.json','library-save.json'}
files=[p for p in root.glob('*') if p.is_file() and p.name not in omit and p.suffix in ('.cjs','.py','.json','.md')]
for folder in ('benchmarks','logs','saves'):
    files.extend(p for p in (root/folder).glob('*') if p.is_file() and p.suffix in ('.cjs','.py','.json','.txt','.out'))
# Include the final report; omit browser captures, binaries, helpers and temporary PDFs.
entries={str(p.relative_to(root)):p.read_bytes() for p in sorted(files)}
entries[pdf.name]=pdf.read_bytes()
manifest=''.join(f'{hashlib.sha256(data).hexdigest()}  {name}\n' for name,data in sorted(entries.items()))
(root/'SHA256SUMS.txt').write_text(manifest)
entries['SHA256SUMS.txt']=manifest.encode()
out=root.parent/'Dominant_Species_v0.5.1_Evidence.zip'
with zipfile.ZipFile(out,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for name,data in sorted(entries.items()):
        info=zipfile.ZipInfo('dominant-species-v0.5.1-evidence/'+name,date_time=(2026,11,15,0,0,0))
        info.compress_type=zipfile.ZIP_DEFLATED
        info.external_attr=0o100644<<16
        z.writestr(info,data,compress_type=zipfile.ZIP_DEFLATED,compresslevel=9)
with zipfile.ZipFile(out) as z:
    assert z.testzip() is None
    for name,data in entries.items():
        assert z.read('dominant-species-v0.5.1-evidence/'+name)==data
result={p.name:{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in (pdf,out)}
(root/'delivery.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
