const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const {Worker, isMainThread, workerData, parentPort} = require('node:worker_threads');

const FIXED = ['dominance','majority','expansion'];
const POLICIES = [...FIXED,'v3','v4'];
// Frozen audit sample. Each count uses 360 matched setups and five player policies.
const MODES = {
  app: {paper:false, extraPawns:null, setups:360, profiles:POLICIES},
  hard: {paper:true, extraPawns:0, setups:360, profiles:POLICIES},
};
const REPS = {2:6,3:6,4:12,5:60};
const SEED_BLOCK = 910000;

function combinations(values, count) {
  if (!count) return [[]];
  return values.flatMap((value,i)=>combinations(values.slice(i+1),count-1).map(tail=>[value,...tail]));
}

function scenarios(animals) {
  const out = [];
  for (const [size,times] of Object.entries(REPS)) {
    let index = 0;
    for (let rep=0;rep<times;rep++) {
      for (const human of animals) {
        for (const rivals of combinations(animals.filter(a=>a!==human),Number(size))) {
          const seed = SEED_BLOCK + 1000 * Number(size) + index;
          out.push({human,rivals,seed,short:(seed+rep)%2===0,index});
          index++;
        }
      }
    }
    assert.equal(index,360);
  }
  return out;
}

function instrument(rt) {
  rt.run(`
    let audit;
    let mostRecentSupplyState;
    const auditReset = () => audit = {rounds:0, firstOnTrack:0, firstPlacement:0,
      humanDom1:0, humanDomPawns:0, humanClaims:0, rivalClaims:0, notTaken:0};
    const realSupply = enterSupply;
    enterSupply = (s, values) => {
      realSupply(s,values);
      mostRecentSupplyState = s;
      audit.rounds++;
      audit.firstOnTrack += Number(s.initiative[0] === s.human);
      if (s.phase === 'planning') audit.firstPlacement += Number(currentPlanner(s)?.actor === s.human);
    };
    const realStep = runStep;
    runStep = (s, step, c) => {
      if (step.kind === 'pawn' && step.row === 'domination' && step.actor === s.human) {
        audit.humanDomPawns++;
        audit.humanDom1 += Number(step.key === 'domination-0');
      }
      if (step.kind === 'claim') {
        if (c.card) {
          audit.humanClaims += Number(step.actor === s.human);
          audit.rivalClaims += Number(step.actor !== s.human);
        } else audit.notTaken++;
      }
      return realStep(s,step,c);
    };
    const auditRead = () => audit;
    const auditState = () => copy(mostRecentSupplyState);
  `);
  return {play:rt.get('playBenchmark'),reset:rt.get('auditReset'),read:rt.get('auditRead'),state:rt.get('auditState')};
}

function worker() {
  const {repo, jobs, caps} = workerData;
  const {load,PLAYER_REFERENCE} = require(path.join(repo,'source/benchmark/load.cjs'));
  const player = load(PLAYER_REFERENCE,['player','tuned']);
  const weights = Object.fromEntries(['v3','v4'].map(v=>[v,JSON.parse(
    fs.readFileSync(path.join(repo,`source/benchmark/tuned_weights_${v}.json`),'utf8')).best]));
  const choose = {place:player.get('playerPlacement'),choose:player.get('playerChoice')};
  const setTuned = player.get('setTuned');
  const modes = Object.fromEntries(Object.entries(MODES).map(([name,{paper,extraPawns,noPlanFirst}])=>{
    const rt = load('worktree',['game']);
    rt.run(`Object.assign(PAPER,{place:${paper},all:${paper},extraAP:${extraPawns ?? 0},noPlanFirst:${Boolean(noPlanFirst)}})`);
    return [name,instrument(rt)];
  }));
  for (const {i,setup} of jobs) {
    const cells = {};
    for (const [mode,cfg] of Object.entries(MODES)) {
      if (setup.index >= Math.min(cfg.setups,caps)) continue;
      const sim = modes[mode];
      const results = {};
      for (const profile of cfg.profiles) {
        sim.reset();
        if (weights[profile]) setTuned(weights[profile]);
        const policy = weights[profile] ? 'tuned' : profile;
        try {
          const g = sim.play({...setup,policy},choose);
          const {winner, winningMargin, humanMargin, turns, steps, openingSupply, stalled} = g;
          results[profile] = {winner,win:winner===g.human,winningMargin,humanMargin,turns,steps,openingSupply,
            stalled:!!stalled,metrics:sim.read()};
          if (stalled) results[profile].stateAtCap = sim.state();
        } catch(error) {
          results[profile] = {error:String(error.stack)};
        }
      }
      cells[mode]=results;
    }
    const completed = Object.values(cells).flatMap(Object.values).filter(g=>!g.error);
    assert(completed.every(g=>g.openingSupply===completed[0].openingSupply),'opening deals must match');
    for (const g of completed) delete g.openingSupply;
    parentPort.postMessage({i,setup,cells,openingSupply:completed[0]?.openingSupply});
  }
}

async function main() {
  const repo = path.resolve(process.argv[2] || path.join(__dirname,'../../dominant-species-audit-v051'));
  const {load,resolveVersion,PLAYER_REFERENCE} = require(path.join(repo,'source/benchmark/load.cjs'));
  const commit = resolveVersion('HEAD');
  const caps = Number(process.argv[4] || 360);
  const threads = Number(process.argv[3] || 8);
  const file = path.join(__dirname,process.argv[5] || 'fresh-results.json');
  const deals = scenarios([...load(commit).get('FOOD')]).filter(s=>s.index<caps);
  const buckets = Array.from({length:threads},()=>[]);
  deals.forEach((setup,i)=>buckets[i%threads].push({setup,i}));
  const rows = new Array(deals.length);
  let games = 0, done = 0, errors = 0, stalls = 0;
  const persist = () => {
    const tmp = file+'.tmp';
    fs.writeFileSync(tmp,JSON.stringify({commit,reference:PLAYER_REFERENCE,seedBlock:SEED_BLOCK,modes:MODES,
      setups:deals.length,done,games,errors,stalls,rows}));
    fs.renameSync(tmp,file);
  };
  await Promise.all(buckets.map(jobs=>new Promise((resolve,reject)=>{
    const w = new Worker(__filename,{workerData:{repo,jobs,caps}});
    w.on('message',row=>{
      rows[row.i]=row;
      for (const outcome of Object.values(row.cells).flatMap(Object.values)) {
        games++;
        errors += Number(Boolean(outcome.error));
        stalls += Number(Boolean(outcome.stalled));
      }
      if (++done%20===0) {
        persist();
        console.error(`${done}/${deals.length} matched setups, ${games} games, ${errors} errors, ${stalls} stalls`);
      }
    });
    w.once('error',reject);
    w.once('exit',code=>code===0?resolve():reject(Error('Worker stopped with code '+code)));
  })));
  assert.equal(done,deals.length);
  persist();
  console.log(`${done} matched setups, ${games} games, ${errors} errors, ${stalls} stalls`);
}

if (isMainThread) main().catch(e=>{console.error(e);process.exitCode=1;});
else worker();
