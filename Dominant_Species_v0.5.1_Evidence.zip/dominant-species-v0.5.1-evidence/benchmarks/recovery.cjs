const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const root = __dirname;
const repo = path.resolve(process.argv[2] || path.join(root,'../../dominant-species-audit-v051'));
const {load,PLAYER_REFERENCE} = require(path.join(repo,'source/benchmark/load.cjs'));
const rt = load('worktree',['game','nn/driver']);
const player = load(PLAYER_REFERENCE,['player']);
const strategy = {place:player.get('playerPlacement'),choose:player.get('playerChoice')};
const copy=x=>JSON.parse(JSON.stringify(x));
const rows=[];
for (const [seed,human,extra,policy,lengths] of [
  [200074,'birds',-1,'expansion',[true]],
  [3880523955,'insects',-2,'majority',[true,false]],
  [3722144011,'birds',-2,'majority',[true,false]],
]) {
  for(const short of lengths) {
    const setup={seed,human,rivals:Array.from(rt.get('FOOD')).filter(a=>a!==human),policy,short};
    rt.run('Object.assign(PAPER,{place:true,all:true,extraAP:'+extra+'})');
    const results={};
    for(const noEmpty of [true,false]) {
      rt.run('PAPER.noEmptyEarth='+noEmpty+';globalThis.BENCH_TURN_CAP=120;');
      const game=rt.get('playBenchmark')(setup,strategy);
      results[noEmpty?'v050':'v051']={turns:game.turns,winner:game.winner,margin:game.humanMargin,stalled:!!game.stalled};
    }
    rows.push({setup,extra,...results});
  }
}
assert.equal(rows[0].v051.turns,9);
assert(rows[0].v050.stalled);
const original=JSON.parse(fs.readFileSync(path.join(root,'../saves/published-stall-200074.json'),'utf8')).game;
const continued=copy(original);
rt.get('validateState')(continued);
rt.run('PAPER.noEmptyEarth=false');
const fromFunction=rt.get('nnContinue').toString();
const extended=fromFunction.replace('stepCount < 1800','stepCount < 12000').replace('s.turn > 30','s.turn > 120');
assert.notEqual(extended,fromFunction);
rt.run('const continueAudit=('+extended+')');
const rest={cards:[],stacks:[[],[],[]]};
const outcome=rt.get('continueAudit')(continued,rest,continued.seed,continued.human,strategy,'expansion');
assert.equal(outcome.turns,37);
assert(continued.usedCards.includes('Ice Age') && continued.phase==='finished');
const result={fromStart:rows,fromArchivedTurn31:{...outcome,iceAge:true}};
fs.writeFileSync(path.join(root,'recovery.json'),JSON.stringify(result,null,2)+'\n');
console.log(JSON.stringify(result,null,2));
