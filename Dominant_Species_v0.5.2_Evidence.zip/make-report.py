"""Build the four-page re-audit report from the verified evidence."""
import json
import os
from pathlib import Path
from xml.sax.saxutils import escape

from reportlab.lib import colors
from reportlab.lib.enums import TA_LEFT
from reportlab.lib.pagesizes import letter
from reportlab.lib.styles import ParagraphStyle
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import PageBreak, Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle

ROOT = Path(__file__).resolve().parent
OUT = Path(os.environ.get('DS_AUDIT_REPORT_OUTPUT', ROOT.parent / 'Dominant_Species_v0.5.2_Reaudit.pdf'))
URL = 'https://github.com/ramyahoo88/dominant-species-solo/blob/db81d8dc2881f035eca02f373d3da5be24d074de/'
DARK = colors.HexColor('#172D2B')
INK = colors.HexColor('#202624')
MUTED = colors.HexColor('#435A56')
HAIR = colors.HexColor('#CED8D2')
PALE = colors.HexColor('#EFF3EF')
CREAM = colors.HexColor('#F5F2E8')
FONTS = Path('/usr/share/fonts/truetype/dejavu')

for label, font in [('Audit', 'DejaVuSans'), ('Audit-Bold', 'DejaVuSans-Bold'), ('Audit-Mono', 'DejaVuSansMono')]:
    pdfmetrics.registerFont(TTFont(label, str(FONTS / (font + '.ttf'))))
pdfmetrics.registerFontFamily('Audit', normal='Audit', bold='Audit-Bold', italic='Audit', boldItalic='Audit-Bold')


def style(name, size, leading, *, font='Audit', color=INK, after=0, before=0):
    return ParagraphStyle(name, fontName=font, fontSize=size, leading=leading,
                          textColor=color, spaceAfter=after, spaceBefore=before, alignment=TA_LEFT)


TITLE = style('Title', 32, 37, font='Audit-Bold', color=DARK, after=7)
SUBTITLE = style('Subtitle', 18, 23, color=MUTED, after=8)
PAGE = style('Page', 24, 29, font='Audit-Bold', color=DARK, after=13)
HEAD = style('Heading', 13, 17, font='Audit-Bold', color=DARK, after=5, before=9)
TEXT = style('Body', 9.35, 14.2, after=8)
SMALL = style('Small', 8, 11.9, color=MUTED, after=6)
CELL = style('Cell', 8.1, 11.6)
HEADER = style('Cell header', 8, 11, font='Audit-Bold', color=colors.white)
CODE = style('Hash', 8.15, 13, font='Audit-Mono', color=DARK, after=5)
BRIEF = style('Brief', 10.8, 16.2, color=DARK)
story = []


def para(text, pstyle=TEXT):
    return Paragraph(text, pstyle)


def p(text, pstyle=TEXT):
    story.append(para(text, pstyle))


def link(label, path, line=None):
    href = URL + path + (f'#L{line}' if line else '')
    return external(label, href)


def external(label, href):
    return f'<link href="{escape(href)}" color="#21645D">{escape(label)}</link>'


def table(headers, rows, widths):
    data = [[para(h, HEADER) for h in headers]] + [[para(str(x), CELL) for x in row] for row in rows]
    component = Table(data, colWidths=widths, hAlign='LEFT', repeatRows=1)
    component.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), DARK),
        ('ROWBACKGROUNDS', (0, 1), (-1, -1), [colors.white, PALE]),
        ('LINEBELOW', (0, -1), (-1, -1), .5, HAIR),
        ('TOPPADDING', (0, 0), (-1, -1), 6),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 7),
        ('LEFTPADDING', (0, 0), (-1, -1), 8),
        ('RIGHTPADDING', (0, 0), (-1, -1), 8),
        ('VALIGN', (0, 0), (-1, -1), 'TOP'),
    ]))
    story.extend([component, Spacer(1, 10)])


def note(text):
    component = Table([[para(text, BRIEF)]], colWidths=[502], hAlign='LEFT')
    component.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, -1), CREAM),
        ('LEFTPADDING', (0, 0), (-1, -1), 13),
        ('RIGHTPADDING', (0, 0), (-1, -1), 13),
        ('TOPPADDING', (0, 0), (-1, -1), 10),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 10),
    ]))
    story.extend([component, Spacer(1, 9)])


def footer(canvas, doc):
    canvas.setTitle('Dominant Species Solo v0.5.2 Re-audit')
    canvas.setAuthor('Independent release audit')
    canvas.setStrokeColor(HAIR)
    canvas.line(55, 43, 557, 43)
    canvas.setFillColor(MUTED)
    canvas.setFont('Audit', 8)
    canvas.drawString(55, 29, 'Dominant Species Solo  /  v0.5.2')
    canvas.drawRightString(557, 29, f'{doc.page}')


def j(name):
    return json.loads((ROOT / name).read_text())


balance = j(os.environ.get('DS_AUDIT_REPORT_INPUT', 'benchmarks/fresh-summary.json'))
recovery = j('benchmarks/recovery.json')
natural = j('benchmarks/extinction-search.json')['found']
bio = balance['extraLogOdds']['hard']
point = bio['mean3to5']
lo, hi = bio['approximateBootstrap95']
x35 = f'{point:+.2f}'
ci = f'{lo:+.2f} to {hi:+.2f}'
target = 'met' if point <= .20 else 'exceeded'
certainty = 'The interval stays below the target.' if hi <= .20 else 'The interval includes values above the target.'
pdf_hash = '62b145b0a14e5f3a5920abb8dc408769471607e6664cfd1e7c14afe3b1f51f1d'
paper_rules = 'source/paper/RULES.md'
engine = 'source/paper/paper.js'

p('Dominant Species Solo', TITLE)
p('v0.5.2 re-audit', SUBTITLE)
p('Commit db81d8d  /  15 November 2026', SMALL)
note('<b>Pass for continued playtesting.</b> The corner-order fix works in the released app. '
     'Exact paper/app parity still requires a Mammals Extinction fix and a few printed tie priorities.')

p('Mammals’ Extinction save', HEAD)
p('The Paper rulebook tells Mammals to save on the endangered tile with the highest first-place value. '
  'The general tie rule then selects the leftmost of equal tiles. Paper mode delegates Extinction to the '
  'App rival, which keeps the first equal-valued tile in placement order. '
  f'{link("Other decisions, printed p. 6", paper_rules,136)} · {link("Paper dispatch",engine,544)} · '
  f'{link("App selection", "source/src/bot.js",615)}')
p(f'<b>Seed {natural["setup"]["seed"]}, turn {natural["difference"]["turn"]}.</b> Reptiles versus five Paper Hard rivals, '
  'full deck, majority policy. Import <font name="Audit-Mono">mammals-extinction-played.json</font> and press '
  '<b>Show Mammals move</b>. C2 and B2 are both sea tiles with endangered Mammals. The app saves at C2, '
  'which was placed earlier. B2 is farther left. Mammals scored 110 VP in the released game and 105 VP in a '
  'matched replay with the proposed tie-break. Arachnids won both games.')
p('<b>Survival VP reproduction.</b> Import <font name="Audit-Mono">mammals-extinction-tie.json</font>. '
  'C3 and D3 are both tundra. At D3 one of two Mammals is protected by Hibernation. The app saves the other '
  'at D3 and scores 1 Survival VP. Saving the endangered C3 cube leaves Mammals on both tiles and scores 3 VP. '
  f'{external("GMT Living Rules, pp. 18 and 20", "https://www.gmtgames.com/living_rules/DS3_Rulebook-web_FINAL.pdf")}')
p('<b>Smallest fix.</b> Choose the Paper Mammals survivor with <font name="Audit-Mono">pBy(extinctionOptions(s, actor), t =&gt; pFirstVP(s, t))</font>. '
  'Return that tile as <font name="Audit-Mono">saved</font>. An in-memory trial picks C3 and B2 in the two fixtures and '
  'awards 3 Survival VP in the first. Add both assertions to the Paper tests.')

p('Hard on fresh seeds', HEAD)
p(f'X35 measured <b>{x35}</b> (95% matched-setup interval {ci}) and {target} the +0.20 target in this sample. '
  f'{certainty} Full results are on page 4.')
p('The shipped HTML and both builds contain 468,080 identical bytes.', SMALL)
p(pdf_hash, CODE)
story.append(PageBreak())

p('Board order in the Paper rules', PAGE)
p('The shipped app now compares corner coordinates numerically, left to right and then top to bottom. '
  'On the archived Empty Earth save, Mammals place Grub at A1 corner 4 (−11,−3). The same order held '
  'after reload, undo and export/import. The Migration and Blight fixtures also confirm that '
  'an earlier tile placement or corner listing loses to the correct board position. '
  f'{link("Comparator and fallback",engine,114)}')
note('<b>Suggested Terms wording</b><br/>Break any remaining tie between tiles already on Earth by higher first-place '
     'value, then board order, unless the rule gives a different priority. For corners and empty hexes, use board order '
     'after the priorities listed for that choice. Board order means furthest left, then highest.')

table(['Rule or decision', 'Priority to state in print'], [
    ('Abundance and Habitat', 'After counting touched tiles the rival occupies, compare the highest first-place value '
     'of any touching tile. A tile counts for value even when the rival has no species there. Then use board order. '
     'The Empty Earth and Habitat fallbacks go straight to board order. ' + link('Source',engine,143)),
    ('Depletion', 'After the two cone counts tie, use board order. The test’s C3 west corner beats a disk touching '
     'the higher-value D2 Wetland because both cone counts are zero. ' + link('Source',engine,189)),
    ('Speciation', 'After the number of matched tiles, add their first-place values and take the larger sum, then '
     'use board order. Tested disks each touched three matched tiles, with the same highest value of 8, and the '
     'right-hand sum 16 beat the left-hand sum 15. Allocate cubes by tile value, then board order. ' + link('Source',engine,226)),
    ('Wanderlust', 'After total adjacent tiles, prefer the spot touching more of the rival’s tiles. The test’s C2 '
     'wins over B3 by two owned neighbors to one. Then use board order. Break equal stack values to the left, '
     'and equal corner counts by corner board order. ' + link('Source',engine,242)),
    ('Aquatic and Blight', 'Aquatic takes the first vacant corner of the selected tile in board order. After a Blight '
     'score tie, compare tile value, tile board order, then the kept disk’s corner. ' + link('Aquatic',engine,367) + ' · ' + link('Blight',engine,394)),
    ('Migration', 'After fullest origin, use destination board order, then origin board order. In the C2 test the '
     'equal rescue from C3 is made before the one from D2. ' + link('Source',engine,262)),
], [142, 360])
p('Leaving the first-place descriptions in the affected rows makes each decision executable from the board and '
  'preserves the app choices used in the balance runs. '
  f'{link("Terms and action tables",paper_rules,20)}', SMALL)
story.append(PageBreak())

p('Other printed ties', PAGE)
p('The global high-value rule also conflicts with three tile choices. The fixtures reproduce each one through '
  'the shipped HTML. These rows can state the app’s existing choices directly.')
table(['Decision and reproduction', 'Printed reading, observed result and smallest wording fix'], [
    ('Mass Exodus<br/>Birds are on D3 and all neighboring tiles have zero matches.', 'The general rule points to D2 '
     'Wetland (8). The app sends Birds to D4 Mountain (3). For an opponent, specify least matches, then lower '
     'first-place value, then board order. For the acting rival, equal matches favor higher first-place value. '
     + link('Rulebook p. 5',paper_rules,124) + ' · ' + link('Source',engine,491)),
    ('Arachnids’ free Competition<br/>D4 Mountain and E5 Forest each score 7.5 against Mammals.', 'A tile-value tie-break '
     'points to E5. The app removes a Mammal from D4. State that equal Competition scores use opponent VP order, '
     'then board order. ' + link('Rulebook p. 6',paper_rules,132) + ' · ' + link('Source',engine,305)),
    ('Fertile<br/>One Mammal on C3 Jungle and one on D2 Wetland.', 'The general rule points to D2 (8). The app selects C3 '
     '(6). Both score 1 VP in this position. Specify board order for equal total species. '
     + link('Rulebook p. 5',paper_rules,119) + ' · ' + link('Source',engine,444)),
], [176, 326])

p('Release and play checks', HEAD)
recovered = ', '.join(str(r['turns']) for r in recovery['fromStart'])
p(f'<b>Recovery.</b> The three known stall seeds reach Ice Age on turns {recovered}. The turn-31 save for '
  f'200074 reaches Ice Age on turn {recovery["archive"]["toTurn"]}. Older Paper imports also retain their level '
  'and Planning flags under the applicable save rules.')
p('<b>Released browser build.</b> Four full-deck Paper Hard games reached scoring at 390 pixels, one per rival count. '
  'Undo, redo, reload and export/import passed, with zero page errors or HTTP(S) requests. '
  'The 41 source rule tests, tuner self-test and targeted legacy and tie fixtures passed their stated assertions.')
p('<b>Print and repository HTML.</b> All text in the 11-page rulebook matches after normalizing whitespace and ordered '
  'list markers. Both columns of the six card sheets were checked, covering all 48 numbered action faces. '
  'The separate Claude mirror was unavailable for verification. '
  f'{link("Released print files","paper/")}')
p('<b>Testing text.</b> Use “7,200 ladder games” in the historical stall note. That count includes 5,760 games '
  f'against Paper rivals and 1,440 against App rivals. {link("Paper rivals summary","PAPER_RIVALS.md",23)}', SMALL)
p('<b>Ladder spot check.</b> The released three-rival row reproduces 50/360 wins at Hard and 54/360 against '
  'App rivals on seed block 200000, with zero stalls.')
p('<b>Reproduction.</b> The evidence archive has the small JSON saves, the runnable assertions, browser previews, '
  'fresh-seed results per game, the metric calculation and the release commands.')
story.append(PageBreak())

p('Hard on fresh seeds', PAGE)
p(f'{balance["done"]:,} matched setups ({balance["games"]:,} games), with 360 setups for each rival count. Five fixed '
  'or previously tuned player policies played each setup at Paper Hard (+0 pawns) and against App rivals. '
  'Animal combinations and full/short decks were balanced. Opening supply matched across all ten games '
  'per setup. Weights stayed frozen.')
headers = ['Rivals', 'Domination', 'Majority', 'Expansion', 'Tuned v3', 'Tuned v4']
policies = ['dominance','majority','expansion','v3','v4']
win_rows = []
for n in range(2,6):
    win_rows.append([n] + [' / '.join(str(balance['levels'][mode]['sizes'][str(n)][policy]['wins'])
                                      for mode in ('hard','app')) for policy in policies])
table(headers, win_rows, [49, 97, 89, 94, 86, 87])
p('Win counts are Paper Hard / App, each out of 360 games. Tied VP scores use the normal food-chain '
  'tiebreaker for wins. Seed ranges 952000-952359, 953000-953359, 954000-954359 and 955000-955359.', SMALL)

xrows = []
for k, values in bio['perSize'].items():
    a, b = values['approximateBootstrap95']
    xrows.append([k, f'{values["point"]:+.2f}', f'{a:+.2f} to {b:+.2f}'])
xrows.append(['3-5 average', x35, ci])
table(['Rivals', 'Excess log-odds', '95% interval'], xrows, [125, 141, 236])
p('For each rival count, subtract the larger of v3 and v4’s advantages against App rivals from tuned v4’s '
  'advantage at Hard. Each advantage is measured against the best fixed policy in that mode. X35 averages the resulting values across '
  'three, four and five rivals. Intervals resample matched setups within each count (3,000 draws). '
  f'{link("Release analysis helper","source/benchmark/balance/final_eval.py")}')
events = balance['levels']
hard = events['hard']['pooled']['v4']
app = events['app']['pooled']['v4']
v4diff = balance['hardApp']['3to5']['v4']
v4lo, v4hi = v4diff['approximate95']
p(f'<b>Game outcomes.</b> V4 won {hard["winPct"]:.1f}% at Hard and {app["winPct"]:.1f}% against App rivals across two '
  f'to five rivals. At three to five rivals its paired Hard minus App win-rate difference was {v4diff["pp"]:+.1f} points '
  f'(approximate 95% interval {v4lo:+.1f} to {v4hi:+.1f}). The run reported {balance["errors"]} errors and '
  f'{balance["stalls"]} stalls at the 30-turn cap.')
p('<b>Rival-favored cone ties.</b> I would keep the current Hard rule. Claude’s pb5 follow-up reports '
  'Hard at +0.06 and −0.09 under its best-against-best metric. In Claude’s separate matched trial of '
  'rival-favored ties, Hard v4 wins fell from 43.6% to 41.1% and one five-rival game hit the 30-turn cap. '
  f'{external("pb5 follow-up","https://github.com/ramyahoo88/dominant-species-solo/blob/a85c4b1/HARD_BALANCE_LOG.md#L438")} · '
  f'{external("Cone-tie trial","https://github.com/ramyahoo88/dominant-species-solo/blob/8f012b0/HARD_BALANCE_LOG.md#L447")}', SMALL)

document = SimpleDocTemplate(str(OUT), pagesize=letter, leftMargin=49, rightMargin=49,
                             topMargin=50, bottomMargin=58)
document.build(story, onFirstPage=footer, onLaterPages=footer)
print(OUT)
