# Dominant Species Solo v0.5.2 re-audit

Release commit `db81d8dc2881f035eca02f373d3da5be24d074de`. Use a full-history checkout of [ramyahoo88/dominant-species-solo](https://github.com/ramyahoo88/dominant-species-solo). The independent report accompanies this archive.

## Build and rules

Run the following from the extracted evidence directory with `REPO` pointing at the checkout. Node 24 and Python 3.12 were used. Print verification uses PyMuPDF and Python-Markdown. Browser tests use Playwright and Chromium, with `DS_AUDIT_CHROMIUM` pointing at the browser executable.

```sh
git -C "$REPO" checkout --detach db81d8dc2881f035eca02f373d3da5be24d074de
python3 "$REPO/source/build.py"
python3 "$REPO/source/build.py" --output rebuilt.html
cmp "$REPO/Dominant_Species_Solo.html" rebuilt.html
cmp "$REPO/source/dist/Dominant_Species_Solo.html" rebuilt.html
sha256sum rebuilt.html
node --test "$REPO/source/rules.test.cjs"
node "$REPO/source/benchmark.cjs" --selftest
node board-order.cjs "$REPO"
node check-extinction-fix.cjs "$REPO"
python3 verify-printables.py "$REPO" --rebuild
```

All three HTML files contain 468,080 bytes and have SHA-256 `62b145b0a14e5f3a5920abb8dc408769471607e6664cfd1e7c14afe3b1f51f1d`. The repository rulebook Markdown and both HTML files rebuild identically. The repository rulebook HTML and 11-page PDF contain identical text after normalizing whitespace and printed ordered-list markers. All 48 card faces in the six-page card PDF match the released decks by animal, number, title and actions in order. The separate Claude mirror could not be verified. GMT’s [third-printing Living Rules](https://www.gmtgames.com/living_rules/DS3_Rulebook-web_FINAL.pdf) support the underlying actions and Survival scoring. The Paper rules govern which legal options the rivals choose.

## Tie positions

`board-order.cjs` builds 17 engine-validated positions with seed 520081, exercises the normal action or effect dispatch and validates the applied state. `board-order.json` records the main comparisons. The position files are small controlled test states. The played Extinction position below comes from a whole seeded game.

| Save in `saves/` | Reproduction |
| --- | --- |
| `mammals-extinction-played.json` | Reptiles, five Paper Hard rivals, full deck, majority policy, seed 960021, turn 5. C2 and B2 are seas. The app keeps Mammals at C2, whereas the Paper rule selects B2. |
| `mammals-extinction-tie.json` | C3 and D3 are tundra. D3 has one Hibernation-protected Mammal and one endangered Mammal. C3 has one endangered Mammal. The app saves at D3 and awards 1 VP. C3 is first in board order and keeping the cube there would award 3 VP. |
| `abundance-value.json` and `habitat-value.json` | C3 is the only tile with Mammals. The selected corner touches unoccupied D2 Wetland and beats C3's left tip by adjacent tile value. |
| `depletion-tie.json` | The two cone counts tie at zero. The C3 west corner wins in board order, while the other disk touches the higher-value Wetland. |
| `speciation-sum.json` | Each Seed disk touches three matched tiles. Both highest values are 8. Choose the right disk (sum 16), ahead of the left disk (sum 15). |
| `wanderlust-site-tie.json` | B3, C2 and E2 all border two tiles. C2 is the only spot bordering two Mammal tiles and the app chooses it before board order. |
| `migration-equal-origins.json` | C3 and D2 have one rescue each to C2. The app moves from C3 first. The old-order switch restores the D2-first sequence. |
| `mass-exodus-destination.json` | Birds leave D3. All destinations have zero matches. The app selects D4 Mountain (3 VP terrain), with the printed general rule pointing to D2 Wetland (8). |
| `arachnids-free-competition-tie.json` | D4 Mountain and E5 Forest both score 7.5 against Mammals. The app removes the D4 cube by board order, with the printed general rule pointing to E5. |
| `fertile-tie.json` | C3 and D2 each hold one Mammal. The app selects C3 by board order and the printed general rule points to D2. Both award 1 VP. |

In the shipped app, choose **Game menu**, **Import save**, and the fixture JSON. Select **Show Mammals move** (or **Show Arachnids move**) and then **Applied · Continue**. The browser check uses the shipped HTML at a 390-pixel viewport and completes these same actions. The in-memory Extinction proposal selects C3 and B2 in the two Mammals fixtures and retains the App rival's D3 choice. The Empty Earth run also verifies A1 corner 4 in the original save and C3 corner 4 in v0.4.1 and v0.3.9 fixtures. The CLI recovery for the archived turn-31 position has a diagnostic 120-turn cap. The ordinary fresh run retains 30 turns.

```sh
node benchmarks/extinction-search.cjs "$REPO"
node benchmarks/recovery.cjs "$REPO"
DS_AUDIT_REPO="$REPO" python3 browser-board-order.py
DS_AUDIT_REPO="$REPO" python3 browser-empty-earth.py
python3 run-browser.py "$REPO/source/browser_test.py"
python3 run-browser.py "$REPO/source/browser_restart_test.py" "$REPO/Dominant_Species_Solo.html"
python3 run-browser.py "$REPO/source/browser_migration_test.py" "$REPO/Dominant_Species_Solo.html"
python3 run-browser.py "$REPO/source/browser_game_test.py" paper=0 full 2 3 4 5
```

## Fresh Hard versus App sample

```sh
node benchmarks/fresh.cjs "$REPO" 8
python3 benchmarks/fresh-summary.py
python3 benchmarks/verify-metric.py "$REPO"
```

The original three-rival Hard ladder cell was also replayed independently. Seed 200000 and two repeats give 50/360 Hard wins and 54/360 App wins, with zero stalls.

```sh
node "$REPO/source/benchmark.cjs" --base db81d8d --candidate db81d8d --paper 0 --bots 3 --seed 200000 --repeats 2
```

The frozen sample has 360 setups at each count. The blocks are 952000–952359, 953000–953359, 954000–954359 and 955000–955359. Each setup uses the same animal mix, deck length and opening supply in both modes. It runs Domination, majority, expansion and the released tuned v3 and v4 weights at Hard and against App rivals. The run asserts equal opening physical supplies across all ten games per setup. Later decisions can change what is drawn. Every setup balances across animal combinations within count and each count has 180 full and 180 short games.

The ordinary repository loader and engine are used in the recorded run. The optional inline loader in the scripts executes the same sources and was used for the short Extinction search. Each benchmark step validates the game state. The fresh run retains the 30-turn benchmark cap and records any capped results or errors. Count wins using the game’s food-chain tiebreaker for top VP ties. The raw JSON has individual outcomes with turns and scoring margins.

For each count, calculate the log-odds difference between v4 and the best fixed policy at Paper Hard. Subtract the better App log-odds advantage of v3 and v4 over App’s best fixed policy. The logit input is bounded to [0.005, 0.995], as in the release helper. X35 is the equally weighted mean across counts 3, 4 and 5. The paired bootstrap resamples complete setups within each count 3,000 times, recomputing the strongest fixed and tuned/App comparators on every resample. The calculations use exact win counts and are checked against the released reporting helper at displayed precision. These are scripted-policy results. A human tabletop difficulty check remains open.

While the audit ran, `a85c4b1` added Claude's [pb5 evaluation](https://github.com/ramyahoo88/dominant-species-solo/blob/a85c4b1/HARD_BALANCE_LOG.md#L438) and `8f012b0` added its [rival-favored cone tie trial](https://github.com/ramyahoo88/dominant-species-solo/blob/8f012b0/HARD_BALANCE_LOG.md#L447). These are log updates. The independent v3/v4 sample uses the requested release commit.

Verify the archive with `sha256sum -c SHA256SUMS.txt`.
