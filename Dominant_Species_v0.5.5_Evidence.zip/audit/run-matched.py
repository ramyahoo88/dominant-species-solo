"""Compare v0.5.5 directly to v0.5.4 with both rival systems and three player policies."""
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import argparse
import subprocess
import tempfile

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("repo", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--mode", choices=("tooth", "queen"))
    parser.add_argument("--one-repeat", action="store_true")
    parser.add_argument("--bots", type=int, choices=(2, 3, 4, 5), action="append")
    parser.add_argument("--one-assignment", action="store_true")
    args = parser.parse_args()
    args.repo = args.repo.resolve()
    args.output = args.output.resolve()
    args.output.mkdir(parents=True, exist_ok=True)
    cases = [(mode, bots, 1 if args.one_repeat else repeats) for mode in ("tooth", "queen")
             for bots, repeats in ((2, 2), (3, 2), (4, 4), (5, 20))
             if (not args.mode or args.mode == mode) and (not args.bots or bots in args.bots)]
    def run(case):
        mode, bots, repeats = case
        prefix = args.output / f"match-{mode}-{bots}"
        cmd = ["node", str(driver), "--base", "4f32abb", "--candidate", "4874b18",
               "--seed", "1265000", "--bots", str(bots), "--repeats", str(repeats),
               "--detail", "--workers", "1"]
        if mode == "queen":
            cmd += ["--paper", "1"]  # Expert on the v0.5.5 ladder
        if args.one_assignment:
            rivals = ["reptiles", "birds", "amphibians", "arachnids", "insects"][:bots]
            cmd += ["--human", "mammals", "--rivals", ",".join(rivals)]
        with prefix.with_suffix(".json").open("w") as out, prefix.with_suffix(".log").open("w") as err:
            subprocess.run(cmd, cwd=args.repo, stdout=out, stderr=err, check=True)
        print(f"Completed {mode} with {bots} rivals", flush=True)
    stock = (args.repo / "source/benchmark.cjs").read_text()
    # The stock --paper flag changes only the candidate. Apply it to each
    # revision so both play The Red Queen at the same difficulty.
    guard = "i === 1 && workerData.paper !== null"
    assert stock.count(guard) == 1
    with tempfile.NamedTemporaryFile(mode="w", suffix=".cjs", prefix=".audit-matched-",
                                     dir=args.repo / "source") as patched:
        patched.write(stock.replace(guard, "workerData.paper !== null"))
        patched.flush()
        driver = Path(patched.name)
        with ThreadPoolExecutor(max_workers=4) as pool:
            list(pool.map(run, cases))

if __name__ == "__main__":
    main()
