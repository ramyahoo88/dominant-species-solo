import json
from pathlib import Path
root=Path(__file__).resolve().parent
a=json.loads((root/'benchmarks/fresh-results.json').read_text())
b=json.loads((root/'benchmarks/loader-vm-parity.json').read_text())
assert a['done']==1440 and b['done']==24
main={x['setup']['seed']:x for x in a['rows']}
for x in b['rows']:
    y=main[x['setup']['seed']]
    assert x['setup']==y['setup']
    assert x['cells']==y['cells'],x['setup']
out={'setups':24,'games':240,'allFieldsEqual':True,'mainCommit':a['commit'],'parityCommit':b['commit']}
(root/'loader-parity-verification.json').write_text(json.dumps(out,indent=2)+'\n')
print('PASS: 24 setups / 240 games match the standard VM loader exactly')
