"""Prove the updated verifier rejects broken duplex PDFs."""
from pathlib import Path
import argparse
import shutil
import subprocess
import sys
import tempfile

import fitz


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("repo", type=Path)
    parser.add_argument("verifier", type=Path)
    args = parser.parse_args()
    with tempfile.TemporaryDirectory() as directory:
        work = Path(directory)
        shutil.copytree(args.repo / "source", work / "source")
        shutil.copytree(args.repo / "paper", work / "paper")
        cards = work / "paper/The_Red_Queen_Cards.pdf"
        book = work / "paper/The_Red_Queen_Rulebook.pdf"

        def expect_failure(path, operation, expected):
            original = path.read_bytes()
            with fitz.open(stream=original) as doc:
                broken = operation(doc) or doc
                broken.save(path)
                if broken is not doc:
                    broken.close()
            result = subprocess.run(
                [sys.executable, str(args.verifier), str(work), "--output-dir", str(work / "results")],
                capture_output=True, text=True,
            )
            assert result.returncode != 0 and expected in result.stderr, result.stderr
            print(result.stderr.strip().splitlines()[-1])
            path.write_bytes(original)

        def wrong_back(doc):
            order = list(range(len(doc)))
            order[1], order[3] = order[3], order[1]
            doc.select(order)

        def erase_power(doc):
            page = doc[1]
            area = page.search_for("Saves one endangered species at Extinction.")[0]
            page.add_redact_annot(area, fill=False, cross_out=False)
            page.apply_redactions(images=0, graphics=0)

        def shift_back(doc):
            shifted = fitz.open()
            shifted.insert_pdf(doc, from_page=0, to_page=0)
            page = shifted.new_page(width=612, height=792)
            page.show_pdf_page(fitz.Rect(2, 0, 614, 792), doc, 1)
            shifted.insert_pdf(doc, from_page=2, to_page=len(doc) - 1)
            return shifted

        def wrong_parity(doc):
            doc.new_page(pno=0, width=612, height=792)

        expect_failure(cards, wrong_back, "unexpected page 2")
        expect_failure(cards, erase_power, "text missing or changed")
        expect_failure(cards, shift_back, "long-edge duplex misalignment")
        expect_failure(book, wrong_parity, "must be an odd-numbered page")


if __name__ == "__main__":
    main()
