"""Run an existing Playwright test against the system Chromium binary."""
import os
import runpy
import sys

from playwright.sync_api import BrowserType


launch = BrowserType.launch


def launch_system(self, **kwargs):
    kwargs["executable_path"] = kwargs.get("executable_path") or os.environ.get(
        "DS_AUDIT_CHROMIUM", "/usr/lib/chromium/chromium"
    )
    return launch(self, **kwargs)


BrowserType.launch = launch_system
sys.argv = sys.argv[1:]
runpy.run_path(sys.argv[0], run_name="__main__")
