const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
const root=path.resolve(process.argv[2]||'dominant-species-solo'),out=path.resolve(process.argv[3]||'audit/evidence');
const {load}=require(path.join(root,'source/benchmark/load.cjs'));const r=load('worktree'),get=n=>r.get(n),copy=o=>JSON.parse(JSON.stringify(o));
const stable=o=>JSON.stringify(o,(k,v)=>v&&typeof v==='object'&&!Array.isArray(v)?Object.fromEntries(Object.entries(v).sort(([a],[b])=>a.localeCompare(b))):v);
let rng=16112026;const rand=n=>{rng=(Math.imul(rng,1664525)+1013904223)>>>0;return rng%n};
const stats={seed:16112026,positions:0,effectChoices:0,pawnChoices:0,saveRoundTrips:0,errors:[],coverage:{}};
for(let iteration=0;iteration<160;iteration++)for(const paper of [false,true]){
 const ids=[...get('FOOD')];const human=ids.splice(rand(6),1)[0],rivals=ids.slice(0,2+rand(4));
 const s=get('newGame')(human,rivals,false,(iteration+111620300)>>>0,paper?{extra:[-2,-1,0,1][rand(4)]}:null);
 const added=rand(9);for(let j=0;j<added;j++){const front=get('frontTiles')(s);const t=front[rand(front.length)];s.tiles[t]={terrain:get('LARGE_TERRAIN')[rand(7)],cubes:Object.fromEntries(s.ids.map(id=>[id,0]))};s.stacks.find(st=>st.left).left--;}
 s.corners={};for(const k of get('activeCorners')(s))if(rand(3)!==0){const el=get('ELEMENT_IDS')[rand(6)];if(get('bagCount')(s,el)>0)s.corners[k]=el;}
 for(const id of s.ids){const a=s.animals[id];a.added=[];for(let j=0,n=rand(7-get('ANIMALS')[id].affinity);j<n;j++){const els=get('ELEMENT_IDS').filter(el=>get('bagCount')(s,el)>0);if(els.length)a.added.push(els[rand(els.length)]);}
 a.vp=rand(100);a.ap=Math.min(10,a.ap+rand(3));a.dead=rand(9);let total=get('SETUP_BY_PLAYERS')[s.ids.length][1]-1-a.dead;
 for(const t of Object.values(s.tiles)){const n=Math.min(total,rand(5));t.cubes[id]=n;total-=n;}a.pool=total;
 }
 s.turn=2+rand(14);s.phase='execution';s.cursor=0;
 for(const row of get('elementRows'))s.boxes[row]=Array.from({length:4},()=>{const els=get('ELEMENT_IDS').filter(e=>get('bagCount')(s,e)>0);return els.length?els[rand(els.length)]:null;});
 // Allocate boxes sequentially to preserve the twenty-disk inventory.
 for(const row of get('elementRows'))s.boxes[row]=[];
 for(const row of get('elementRows'))for(let j=0;j<4;j++){const els=get('ELEMENT_IDS').filter(e=>get('bagCount')(s,e)>0);if(els.length)s.boxes[row].push(els[rand(els.length)]);}
 get('validateState')(s);get('validateState')(copy(s));stats.saveRoundTrips++;stats.positions++;if(stats.positions%40===0)console.error('Positions '+stats.positions);
 const actor=rivals[rand(rivals.length)];
 for(const card of get('DOMINANCE')){
  const base=copy(s);base.usedCards=[card];base.market=[];base.market=Array(5).fill(null);
  const tile=get('terrainIds')(base).find(t=>base.tiles[t].cubes[actor])||'D3';
  base.pending=[{kind:'effect',actor,tile,name:card,focus:'majority'}];
  try{get('validateState')(base);const before=stable(base),step=get('nextStep')(base),choice=get('botAction')(base,step);
   assert.equal(stable(base),before,'Chooser changes state values');
   const replay=get('botAction')(copy(base),step);assert.deepEqual(copy(choice),copy(replay),'Repeated choice differs');
   get('runStep')(base,step,copy(choice));get('validateState')(base);stats.effectChoices++;stats.coverage[(paper?'paper:':'app:')+card]=(stats.coverage[(paper?'paper:':'app:')+card]||0)+1;
  }catch(e){const name=`generated-failure-${stats.errors.length}`;fs.writeFileSync(path.join(out,name+'.json'),JSON.stringify({format:get('SAVE_KEY'),game:s},null,2));stats.errors.push({iteration,paper,actor,card,message:e.message,fixture:name});}
 }
 for(const row of get('ROWS'))for(let index=0;index<row.slots.length;index++){
  if(row.id==='glaciation'&&index>0)continue;
  const base=copy(s),key=row.slots[index];base.pawns={[key]:{actor,card:null,focus:'majority'}};base.cursor=get('EXECUTION').indexOf(key);
  const step={kind:'pawn',actor,row:row.id,index,key,position:base.cursor,focus:'majority',card:null};
  try{const before=stable(base),choice=get('botAction')(base,step);assert.equal(stable(base),before,'Pawn chooser changes state values');get('runStep')(base,step,copy(choice));get('validateState')(base);stats.pawnChoices++;}
  catch(e){stats.errors.push({iteration,paper,actor,row:row.id,index,message:e.message});}
 }
}
fs.writeFileSync(path.join(out,'generated-positions.json'),JSON.stringify(stats,null,2));console.log(JSON.stringify(stats));if(stats.errors.length)process.exitCode=1;
