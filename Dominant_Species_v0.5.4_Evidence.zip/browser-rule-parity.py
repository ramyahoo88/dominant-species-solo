"""Exercise saved rule flags, the resulting card recipient, and Empty Earth through the release UI."""
import json, os
from pathlib import Path
from playwright.sync_api import sync_playwright
ROOT=Path(__file__).resolve().parent
REPO=Path(os.environ.get('DS_AUDIT_REPO',ROOT.parent/'dominant-species-solo'))
KEY='dominant-species-solo-v1'
def saved(p): return p.evaluate('(k)=>JSON.parse(localStorage.getItem(k)).game',KEY)
def button(p,name): return p.get_by_role('button',name=name,exact=True)
with sync_playwright() as pw:
    b=pw.chromium.launch(executable_path=os.environ['DS_AUDIT_CHROMIUM'],args=['--no-sandbox','--no-zygote','--disable-gpu','--disable-dev-shm-usage'])
    ctx=b.new_context(viewport={'width':390,'height':850},offline=True,accept_downloads=True)
    p=ctx.new_page(); errors=[]; network=[]; records=[]
    p.on('pageerror',lambda e:errors.append(str(e)))
    p.on('request',lambda r:network.append(r.url) if r.url.startswith(('http:','https:')) else None)
    p.goto((REPO/'Dominant_Species_Solo.html').as_uri())
    def imported(name):
        original=json.loads((ROOT/'saves'/f'{name}.json').read_text())['game']
        # Clear the preceding fixture so an async import cannot be mistaken for it.
        p.evaluate('localStorage.clear()');p.reload()
        p.locator('#import-file').set_input_files(ROOT/'saves'/f'{name}.json')
        p.wait_for_function('(k)=>!!JSON.parse(localStorage.getItem(k))?.game',arg=KEY)
        g=saved(p);assert g['version']=='0.5.4'
        for flag in ('rivalTie','planFirst','speciesTie','scaledEasy'):
            assert g.get('paper',{}).get(flag)==original.get('paper',{}).get(flag),(name,flag)
        return g
    for legacy in (False,True):
        name='species-tie-'+('legacy' if legacy else 'new');before=imported(name)
        p.locator('[data-do=help]').click()
        help_text=p.get_by_role('dialog').inner_text()
        assert ('This saved game' in help_text)==legacy
        if legacy: assert 'keeps its rival tie rule from then' in help_text and 'food chain is dominant' in help_text
        p.keyboard.press('Escape')
        button(p,'Show Mammals move').click();preview=p.locator('.result-box').first.inner_text()
        assert saved(p)==before
        button(p,'Applied · Continue').click();after=saved(p)
        expected='mammals' if legacy else 'insects'
        assert after['pending'][0]['kind']=='claim' and after['pending'][0]['actor']==expected,(name,after['pending'])
        button(p,'Undo').click();assert saved(p)==before
        button(p,'Show Mammals move').click();button(p,'Applied · Continue').click();assert saved(p)==after
        p.reload();assert saved(p)==after
        records.append({'name':name,'preview':preview,'cardRecipient':expected,'undoReplayReload':True,'help':help_text})
    for legacy in (False,True):
        name='empty-earth-'+('legacy' if legacy else 'new');before=imported(name)
        button(p,'Show Birds move').click();preview=p.locator('.result-box').first.inner_text()
        assert 'Empty Earth: no rival species are on Earth' in preview
        assert saved(p)==before
        button(p,'Applied · Continue').click();after=saved(p)
        assert len(before['corners'])==0 and len(after['corners'])==1
        assert sum(t['cubes']['mammals'] for t in after['tiles'].values())==1
        button(p,'Undo').click();assert saved(p)==before
        button(p,'Show Birds move').click();button(p,'Applied · Continue').click();assert saved(p)==after
        p.reload();assert saved(p)==after
        records.append({'name':name,'preview':preview,'placed':after['corners'],'undoReplayReload':True})
    for f in sorted((ROOT/'saves').glob('legacy-0*.json')):
        g=imported(f.stem);p.reload();assert saved(p)==g
        button(p,'Game menu').click()
        with p.expect_download() as d:button(p,'Export save').click()
        data=Path(d.value.path()).read_bytes();p.keyboard.press('Escape')
        p.evaluate('localStorage.clear()');p.reload()
        p.locator('#import-file').set_input_files({'name':'roundtrip.json','mimeType':'application/json','buffer':data})
        p.wait_for_function('(k)=>!!JSON.parse(localStorage.getItem(k))?.game',arg=KEY)
        assert saved(p)==g
        records.append({'name':f.stem,'rules':g['paper'],'exportImportReload':True})
    assert not errors and not network,(errors,network)
    output={'browser':b.version,'records':records,'errors':errors,'network':network};b.close()
(ROOT/'browser-rule-parity.json').write_text(json.dumps(output,indent=2)+'\n')
print(f'PASS {len(records)} saved-rule and action checks, zero page errors and network requests')
