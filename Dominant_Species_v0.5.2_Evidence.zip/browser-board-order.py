"""Import the controlled positions into the released HTML and apply rival moves."""
import json
import os
from pathlib import Path
from playwright.sync_api import sync_playwright

ROOT = Path(__file__).resolve().parent
REPO = Path(os.environ.get('DS_AUDIT_REPO', ROOT.parent / 'dominant-species-solo'))
KEY = 'dominant-species-solo-v1'
CASES = {
    'abundance-value': ('Mammals', 'corner 6 on C3', 'meat'),
    'depletion-tie': ('Mammals', 'corner 4 on C3', None),
    'speciation-sum': ('Mammals', 'corner 2 on D2', None),
    'wanderlust-site-tie': ('Mammals', 'at C2', None),
    'migration-equal-origins': ('Mammals', 'C3 Jungle to C2 Forest', None),
    'fertile-tie': ('Mammals', 'C3 Jungle', None),
    'mass-exodus-destination': ('Mammals', 'D3 Tundra to D4 Mountain', None),
    'arachnids-free-competition-tie': ('Arachnids', 'D4 Mountain', None),
    'mammals-extinction-tie': ('Mammals', 'save one cube at D3 Tundra', None),
    'mammals-extinction-played': ('Mammals', 'save one cube at C2 Sea', None),
}


def saved(page):
    return page.evaluate('(key) => JSON.parse(localStorage.getItem(key))?.game', KEY)


def button(page, title):
    return page.get_by_role('button', name=title, exact=True)


with sync_playwright() as playwright:
    browser = playwright.chromium.launch(
        executable_path=os.environ.get('DS_AUDIT_CHROMIUM'),
        args=['--no-sandbox', '--no-zygote', '--single-process', '--disable-gpu', '--disable-dev-shm-usage'],
    )
    page = browser.new_context(viewport={'width':390,'height':850}, offline=True).new_page()
    errors, network, records = [], [], []
    page.on('pageerror', lambda error: errors.append(str(error)))
    page.on('request', lambda req: network.append(req.url) if req.url.startswith(('http:', 'https:')) else None)
    page.goto((REPO / 'Dominant_Species_Solo.html').resolve().as_uri())
    for fixture, (animal, expected, disk) in CASES.items():
        path = ROOT / 'saves' / f'{fixture}.json'
        before = json.loads(path.read_text())['game']
        page.locator('#import-file').set_input_files(path)
        page.wait_for_function('([key, g]) => JSON.stringify(JSON.parse(localStorage.getItem(key))?.game) === JSON.stringify(g)',
                               arg=[KEY, before])
        button(page, f'Show {animal} move').click()
        preview = page.locator('.result-box').first.inner_text()
        assert expected in preview, (fixture, expected, preview)
        assert saved(page) == before
        button(page, 'Applied · Continue').click()
        after = saved(page)
        assert before != after
        if disk is not None:
            assert after['corners']['-2,-2'] == disk
        if fixture == 'mammals-extinction-tie':
            assert after['animals']['mammals']['vp'] == 1
            assert after['tiles']['C3']['cubes']['mammals'] == 0
            assert after['tiles']['D3']['cubes']['mammals'] == 2
            page.reload()
            assert saved(page) == after
        if fixture == 'mammals-extinction-played':
            assert after['tiles']['C2']['cubes']['mammals'] == 1
            assert after['tiles']['B2']['cubes']['mammals'] == 0
        records.append({'fixture':fixture,'preview':preview,'applied':True})
    assert not errors and not network, (errors, network)
    evidence = {'browser':browser.version,'records':records,'errors':errors,'network':network}
    browser.close()

(ROOT / 'browser-board-order.json').write_text(json.dumps(evidence,indent=2) + '\n')
print(f"PASS {len(records)} imported positions, including the Mammals' Survival result")
