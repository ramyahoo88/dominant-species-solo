"""Generate the release re-audit from the verified observations."""
from pathlib import Path
from html import escape
import json
from reportlab.lib.colors import HexColor
from reportlab.lib import pagesizes
from reportlab.lib.styles import ParagraphStyle
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import PageBreak, Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle


ROOT = Path(__file__).resolve().parent
OUT = ROOT.parent / 'Dominant_Species_v0.5.1_Reaudit.pdf'
COMMIT = 'dec3a3bec5ed3fbe0ede969c00d1a8b51ac4f596'
GITHUB = 'https://github.com/ramyahoo88/dominant-species-solo'
RULES = 'https://www.gmtgames.com/living_rules/DS3_Rulebook-web_FINAL.pdf'
TEAL = HexColor('#183e40')
DARK = HexColor('#23383b')
MUTED = HexColor('#52666a')
RUST = HexColor('#a0442f')
LINE = HexColor('#d3dfdb')
PALE = HexColor('#eef4f0')
SHA = 'c90c42b66127d25f39cdedee493e1321e3ada0360f995358e40094392cd9b492'
fonts = Path('/usr/share/fonts/truetype/liberation')
for key, family in [('DS','Regular'),('DS-Bold','Bold'),('DS-Italic','Italic'),('DS-BoldItalic','BoldItalic')]:
    pdfmetrics.registerFont(TTFont(key,str(fonts/f'LiberationSans-{family}.ttf')))
pdfmetrics.registerFontFamily('DS',normal='DS',bold='DS-Bold',italic='DS-Italic',boldItalic='DS-BoldItalic')

styles = {
    'cover':ParagraphStyle('cover',fontName='DS-Bold',fontSize=29,leading=33,textColor=TEAL,spaceAfter=16),
    'heading':ParagraphStyle('heading',fontName='DS-Bold',fontSize=19,leading=24,textColor=TEAL,spaceAfter=12),
    'sub':ParagraphStyle('sub',fontName='DS-Bold',fontSize=12,leading=16,textColor=TEAL,spaceBefore=8,spaceAfter=6),
    'body':ParagraphStyle('body',fontName='DS',fontSize=10.4,leading=14.4,textColor=DARK,spaceAfter=8),
    'small':ParagraphStyle('small',fontName='DS',fontSize=8.9,leading=12,textColor=MUTED,spaceAfter=7),
    'tag':ParagraphStyle('tag',fontName='DS-Bold',fontSize=10,leading=14,textColor=RUST,spaceAfter=8),
    'cell':ParagraphStyle('cell',fontName='DS',fontSize=9.5,leading=12.4,textColor=DARK),
}
story = []


def p(s, style='body'):
    story.append(Paragraph(s,styles[style]))


def page(title):
    story.append(PageBreak())
    p(title,'heading')


def sub(title):
    p(title,'sub')


def table(rows, widths):
    values = [[Paragraph(escape(str(value)),styles['cell']) for value in row] for row in rows]
    t = Table(values,colWidths=widths,hAlign='LEFT',repeatRows=1)
    t.setStyle(TableStyle([
        ('BACKGROUND',(0,0),(-1,0),PALE),('LINEBELOW',(0,0),(-1,0),.8,TEAL),
        ('LINEBELOW',(0,1),(-1,-1),.45,LINE),('VALIGN',(0,0),(-1,-1),'TOP'),
        ('TOPPADDING',(0,0),(-1,-1),5),('BOTTOMPADDING',(0,0),(-1,-1),5),
        ('LEFTPADDING',(0,0),(-1,-1),7),('RIGHTPADDING',(0,0),(-1,-1),7),
    ]))
    story.extend((t,Spacer(1,9)))


def link(url,label):
    return f'<link href="{url}" color="#235f73">{escape(label)}</link>'


def source(file, line=None):
    end = f'#L{line}' if line else ''
    label = f'{file}:{line}' if line else file
    return link(f'{GITHUB}/blob/{COMMIT}/{file}{end}',label)


def point(bold, words):
    p(f'<b>{bold}</b> {words}')


def finding(title, level, impact, repro, expected, actual, sources, fix):
    sub(title)
    p(level,'tag')
    point('Player impact.',impact)
    point('Reproduce.',repro)
    point('Expected.',expected)
    point('Observed.',actual)
    point('Smallest fix.',fix)
    p(sources,'small')


def read(name):
    return json.loads((ROOT/name).read_text())

raw=read('benchmarks/fresh-summary.json')
ladder=read('benchmarks/published-summary.json')
browser=read('browser-empty-earth.json')
printing=read('print-observations.json')
recovery=read('benchmarks/recovery.json')
prototype=read('top-left-prototype.json')
assert raw['commit']==ladder['commit']==COMMIT
assert raw['done']==1440 and raw['games']==14400 and raw['errors']==0
assert ladder['games']==7200 and ladder['oldGames']==5760
assert browser['archivedTurn31ImportedAndSupplied'] and browser['midOpeningSaveExact']
assert not browser['errors'] and not browser['network']
assert printing['rulebookPages']==11 and len(printing['cardsChecked'])==48
assert recovery['fromArchivedTurn31']['turns']==37 and recovery['fromArchivedTurn31']['iceAge']
assert prototype['continuedFromTurn31']['turns']==33
cells=['easy','standard','hard','expert','app']
names={'easy':'Easy -2','standard':'Standard -1','hard':'Hard 0','expert':'Expert +1','app':'App'}
bad=[(r['rivals'],k) for r in ladder['table'] for k in cells if not r[k]['agrees']]
changed=ladder['changes']
winner_changes=[r for r in changed if r['before']['winner']!=r['after']['winner']]
assert len(changed)==6 and len(winner_changes)==1 and not bad
gap=raw['extraLogOdds']['hard']
center=gap['mean3to5']
interval=gap['approximateBootstrap95']
policies=('dominance','majority','expansion','v3','v4')
labels={'dominance':'Card-chaser','majority':'Majority','expansion':'Expansion','v3':'Tuned v3','v4':'Tuned v4'}

def pct(stats):
    return f'{stats["winPct"]:.1f}%'

def bounds(xs,digits=2):
    return f'{xs[0]:+.{digits}f} to {xs[1]:+.{digits}f}'

def paired(v):
    return f'{v["pp"]:+.1f} points ({bounds(v["approximate95"],1)})'


p('Dominant Species Solo<br/>v0.5.1 re-audit','cover')
p('15 November 2026 · Shipped app and Paper Rivals','small')
p('EMPTY EARTH RECOVERY PASSES · ONE CORNER-ORDER MISMATCH','tag')
p('The new exception restores the known stalled games, including the archived older save. Both benchmark-reporting fixes work. One confirmed discrepancy remains between the printed instruction and the app: Empty Earth selects the first stored corner rather than the printed top-left corner.')
p(f'{link(GITHUB+"/commit/"+COMMIT,"Reviewed commit dec3a3b")}<br/>{COMMIT}','small')
table([
    ['Check','Independent result'],
    ['Release build','Tracked shipment, default source/dist output and separate audit output are byte-identical, each 466,737 bytes. Requested SHA-256 matches.'],
    ['Rules and shipped controls','40 rules tests and the 24-game tuner self-test pass. Offline mobile-width controls, legacy restart cases, custom Empty Earth imports and full-deck Expert games with four and five rivals pass.'],
    ['Known recovery','The three reported seeds reach Ice Age on turns 9, 10 and 18. The archived turn-31 position finishes on turn 37 with shipped v0.5.1 rules.'],
    ['Full ladder',f'7,200 release games plus 5,760 actual v0.5.0 Paper games. {20-len(bad)}/20 printed cells reproduce. {len(changed)} Paper traces differ and {len(winner_changes)} winner changes.'],
    ['Fresh Hard/App balance',f'14,400 games on 1,440 matched setups, five policies. Hard X35 = {center:+.3f}; approximate 95% interval {bounds(interval,3)}.'],
    ['Printables','All 11 rendered rulebook pages and both columns of all six card sheets inspected. All 48 numbered Paper faces match source. Markdown and both HTML print sources rebuild identically.'],
],[136,380])
p(f'<b>Shipped and rebuilt SHA-256</b><br/>{SHA}','small')
point('Release verdict.','Pass for continued playtesting. Resolve E1 before claiming exact agreement between printed rules and app decisions. Balance estimates and coverage limits are set out on pages 5–6.')
p(f'{source("AUDIT_RESPONSE_v0.5.0.md")} · {source("HANDOFF.md")} · {source("source/paper/ladder.json")}','small')

page('E1 · “Top-left first” is not storage order')
p('CONFIRMED · MODERATE PAPER / APP PARITY DEFECT','tag')
point('Player impact.','Players following the printed rule can seed a different tile from the app. That changes later Speciation, survival and scoring. The recovery exception still works; this finding concerns which recovery move it makes.')
point('Expected rule.','The Execution Abundance row on rulebook page 4 explicitly prefers the top-left empty corner when Earth has no species. The Planning step and target row allow any vacant Earth corner. A corner strictly above and left of the selected one must remain a better top-left candidate.')
point('Smallest supplied setup.','Import <b>saves/v050-empty-abundance.json</b> from the evidence bundle. It is the Abundance step derived from seed 200074’s archived turn-31 position: Birds against five rivals, Paper Standard, no species or disks on Earth. Mammals have the first Abundance pawn. The box is Grass, Grub, Sun, Sun.')
point('Exact steps.','Open the shipped HTML, use Game menu → Import save, select the fixture, then click <b>Show Mammals move</b>. Read the preview and click <b>Applied · Continue</b>. Reload or Undo and repeat to confirm the same result.')
table([
    ['Corner','Result in this position'],
    ['A1 corner 1, coordinate -7,-3','App selects it. Shared by A1 Jungle, B1 Tundra and B2 Tundra.'],
    ['A1 corner 5, coordinate -10,-4','Vacant and strictly above and left of the app choice. Touches A1 Jungle.'],
    ['A1 corner 6, coordinate -8,-4','Also vacant, above and left of the app choice.'],
],[192,324])
point('Cause.','Abundance selects <b>empty[0]</b>. activeCorners inherits insertion order from tiles and their clockwise corners, beginning at the right tip. The regression test equates activeCorners(s)[0] with top-left, so it does not test the printed geometry independently.')
p(f'{source("source/paper/RULES.md",86)} · {source("source/paper/paper.js",158)} · {source("source/paper/paper.js",162)} · {source("source/src/engine.js",11)} · {source("source/src/data.js",76)} · {source("source/rules.test.cjs",639)} · {source("source/paper/paper.js",439)}','small')
point('Smallest proposed fix.','Specify a visible convention, such as “uppermost empty corner, then leftmost,” and sort numeric coordinates by y then x before choosing. Reuse it for Habitat’s equivalent fallback. Keep the current occupied-tile priorities. Add an expanded-map test with a vacant corner strictly above and left of the previous choice.')
point('Tested proposal.','The scratch sort chooses C1 corner 5 (-4,-6), skips it when occupied, and finishes the archived game on turn 33. It changes no release files. This convention needs matching printed wording; it is a proposal, not a claim that the existing phrase uniquely specifies y-before-x.')
p('<b>Runnable failure</b> · node empty-earth.cjs /path/to/repo --assert-top-left<br/><b>Prototype check</b> · node top-left-prototype.cjs /path/to/repo','small')

page('Recovery, boundaries and legacy saves')
p('The original GMT third-printing Living Rules, page 11, permit Abundance on any vacant Earth corner, including a perimeter corner. The Paper occupied-tile restriction is a bot selection rule. Empty Earth relaxes that restriction when there are no species of any animal on Earth. The printed step and both Abundance rows correctly describe that condition.')
p(f'{link(RULES+"#page=11","GMT Living Rules p. 11")} · {source("source/paper/RULES.md",49)} · {source("source/paper/RULES.md",67)} · {source("source/paper/RULES.md",86)} · {source("source/paper/paper.js",43)}','small')
table([
    ['Exact benchmark setup','v0.5.0 behavior','v0.5.1 behavior'],
    ['200074 · Birds, five rivals, Standard -1, expansion, short','Still stalled at turn 121','Ice Age on turn 9'],
    ['3880523955 · Insects, five rivals, Easy -2, majority, full','Still stalled at turn 121','Ice Age on turn 10'],
    ['3722144011 · Birds, five rivals, Easy -2, majority, short','Recovers naturally; ends turn 31','Ice Age on turn 18'],
    ['Original archived 200074 position, turn 31','Previously established empty-board loop','Ice Age on turn 37'],
],[268,124,124])
p('The old/new seed checks use the diagnostic 120-turn cap. Ladder and fresh balance runs keep the release’s ordinary 30-turn cap. “Finished” requires Ice Age; a capped score is kept separate from a completed game. The two complementary deck lengths for the latter seeds were also checked and are recorded in recovery.json.','small')
sub('Through the shipped controls')
p('Imported the original v0.5.0 turn-31 save, reloaded it, entered its recorded physical draw and began Planning. Mammals previewed Barren Earth / Abundance. Saving after the first opening placement preserved the remaining rival list exactly. Execution preview, applied disk and consumed box position agree. Undo/redo and export/import reproduce the same state.')
table([
    ['Imported save','Preserved behavior while Empty Earth works'],
    ['v0.5.0 archived game and derived execution fixture','Standard -1, rival tie-break and rivals-first Planning remain active.'],
    ['Constructed v0.4.1 Easy empty position','Easy -1, normal Planning, rival tie-break retained.'],
    ['Constructed v0.3.9 Easy empty position','Easy 0, normal Planning, old undominated rival ties retained.'],
],[208,308])
point('Boundaries tested.','Empty box and no vacant corner forfeit. Occupied corners are skipped. A single surviving human or rival cube disables the exception. Execution checks the current board again, so a cube disappearing or appearing after Planning changes eligibility correctly. Element preference remains “leftmost used, else leftmost.”')
point('Scope of recovery.','This is deliberately not a proof of eventual completion for every legal board. Empty gene pools, later Extinction, or a surviving cube without usable disks can prevent immediate repopulation. The release response already acknowledges that limitation. No new permanent-stall claim is made from those untested possibilities.')
p(f'{source("source/src/controls.js",173)} · {source("source/paper/paper.js",18)} · {source("source/paper/paper.js",155)} · evidence browser-empty-earth.json and benchmarks/recovery.json','small')

page('Ladder, benchmark fixes and printables')
p('The replay compares every Paper game against the actual v0.5.0 engine. It hashes the returned decisions and outcome, retaining both results and the first changed event for every difference. All three fixed policies use the release’s seed block 200000 and 360 games per cell.')
rows=[['Rivals','Easy -2','Standard -1','Hard 0','Expert +1','App']]
for r in ladder['table']:
    rows.append([r['rivals']]+[f'{r[k]["observed"]}% ({r[k]["wins"]})' for k in cells])
table(rows,[58,91,100,88,91,88])
p('Each entry gives the rounded human win rate and exact wins out of 360. Lower rates mean tougher rivals. All 20 printed percentages reproduce. Easy through Expert becomes harder in every pooled fixed-policy row.','small')
point('Six changed games.','The claim reproduces game by game. Six of 5,760 Paper traces differ. Only seed 200018, Reptiles against three Standard rivals with expansion, changes winner. Standard at three rivals rises from 113 to 114 wins, rounding from 31% to 32%. Other Paper cells retain their win counts. The replay finds zero current stalls and the one previously reported old stall.')
p('For that old stalled game, the harness’s reported winner is its leader at the cap, not the result of a completed game. Its recovered v0.5.1 counterpart reaches Ice Age.','small')
sub('B1 and B2 are closed')
table([
    ['Reproduction','Observed'],
    ['--bots 3,3','Rejects repeated rival count; no games reported.'],
    ['--modes=m2,-2 and --modes=app,app','Rejects duplicate canonical modes; no games reported.'],
    ['--bots 3 --modes=m2 --per-cell 2','Still labels Easy, offset -2, and returns 1 win in 2 games.'],
    ['Only three-rival rows in final_eval.py','Reports +0.29 for that size and X35 n/a, naming missing 4/5 rows.'],
    ['Complete prior sample; duplicate rows','Complete old/new helper output is byte-identical. Duplicate Paper or App rows fail explicitly.'],
],[248,268])
p(f'{source("source/benchmark/tune.cjs",37)} · {source("source/benchmark/tune.cjs",412)} · {source("source/benchmark/balance/final_eval.py",15)} · {source("source/benchmark/balance/final_eval.py",40)}','small')
sub('Printed materials')
p('Read all 11 shipped rulebook pages, including both action-table columns, the full Testing section and the appendix. Read both columns on all six card sheets. All 48 identities, titles and three-action sequences match the reverse faces in decks.js. The duplicate rulebook tables also agree. The Fallback item stays together and the last card sheet retains its production note.')
p('The level offsets are Easy -2, Standard -1, Hard 0 and Expert +1. The wording now limits the +0.20 claim to the average over three, four and five rivals in its named sample, and cites the prior independent +0.19 estimate. “Rarely contest” correctly replaces “never contest.” No additional clipping, missing columns or card-text discrepancies were found.')
p(f'{source("paper/Paper_Rivals_Rulebook.pdf")} · {source("paper/Paper_Rivals_Cards.pdf")} · {source("source/paper/ladder.json")} · evidence print-observations.json','small')

page('Fresh Hard versus App measurement')
p('Five frozen player policies each played 1,440 matched setups against Hard 0 and App. There are 360 setups per rival count, balanced across animal combinations and short/full decks. Seeds are 912000–912359 through 915000–915359. Opening draws match across policies and modes; later draws can diverge as decisions change. No weights were trained on these seeds.')
rows=[['Player strategy','Hard wins / 1,440','App wins / 1,440','Hard − App, pp']]
for name in policies:
    h=raw['levels']['hard']['pooled'][name]
    a=raw['levels']['app']['pooled'][name]
    rows.append([labels[name],f'{h["wins"]} ({pct(h)})',f'{a["wins"]} ({pct(a)})',f'{h["winPct"]-a["winPct"]:+.1f}'])
table(rows,[141,137,137,101])
p('Wins include final VP ties resolved by food chain, as the game does. Exact wins, margins, ties, turns and strategy measurements are retained in fresh-results.json and fresh-summary.json. Each policy has 360 games per size and mode.','small')
rows=[['Rivals','Hard card-chaser','App card-chaser','Hard v4','App v4','Excess log-odds']]
for n in range(2,6):
    h=raw['levels']['hard']['sizes'][str(n)]
    a=raw['levels']['app']['sizes'][str(n)]
    rows.append([n,pct(h['dominance']),pct(a['dominance']),pct(h['v4']),pct(a['v4']),f'{gap["perSize"][str(n)]["point"]:+.3f}'])
table(rows,[42,102,102,83,83,104])
point('How the +0.20 target is measured.','For each rival count, compute v4’s log-odds edge over the strongest fixed strategy on Hard. Subtract the stronger App edge of v3 or v4 over App’s strongest fixed strategy. X35 is the mean of that contrast over three, four and five rivals. It is a log-odds contrast, not a 20-percentage-point advantage.')
point('Fresh estimate.',f'<b>Hard X35 is {center:+.3f}</b>, with an approximate 95% matched-bootstrap interval of <b>{bounds(interval,3)}</b>. The prior independent v0.5.0 estimate was +0.186. This run has three times as many setups per size.')
if center<=.2:
    p('The point estimate is within the stated +0.20 target in this fresh sample. '+
      ('The interval crosses the target, so it does not establish that Hard is reliably below the limit.' if interval[1]>.2 else 'The interval also falls below the target for this tested setup and policy mix.'))
else:
    p('The point estimate is above the stated +0.20 target in this fresh sample. '+
      ('The interval spans the target, so the data do not establish a clear breach across the tested setup mix.' if interval[0]<=.2 else 'The interval is also above the target for this tested setup and policy mix.'))
p('Intervals resample whole matched setups within rival count 3,000 times, reselecting the best fixed and App comparator each time. They describe variation over these tested setups. They cannot establish optimal play or predict a human’s win rate. The complete planned sample was retained, without stopping when a preferred result appeared.','small')
p(f'{source("HARD_BALANCE_LOG.md",89)} · {source("HARD_BALANCE_LOG.md",297)} · {source("source/benchmark/balance/final_eval.py",34)} · evidence benchmarks/fresh-summary.py','small')

page('Strategy, limits and release verdict')
h=raw['levels']['hard']['pooled']; a=raw['levels']['app']['pooled']
point('What the tuned player does.',f'On Hard, v4 is first on the Initiative track in {h["v4"]["firstOnTrack"]:.1f}% of turns, versus {h["dominance"]["firstOnTrack"]:.1f}% for the fixed card-chaser. It makes the turn’s very first placement in {h["v4"]["firstPlacement"]:.1f}% of turns because the rival opening still acts ahead of ordinary Planning. It resolves Domination space 1 {h["v4"]["dom1PerGame"]:.2f} times per game and claims {h["v4"]["humanClaimsPerGame"]:.2f} cards, versus {h["dominance"]["dom1PerGame"]:.2f} and {h["dominance"]["humanClaimsPerGame"]:.2f} for the card-chaser.')
point('v4 compared with v3.',f'The matched gain is {paired(raw["retuneGains"]["hard"]["paper"])} on Hard and {paired(raw["retuneGains"]["hard"]["appOnSameSetups"])} on App. Parentheses give approximate 95% intervals in percentage points. This evaluates existing frozen strategies; it does not search for a new best response to Empty Earth.')
point('Hard’s absolute difficulty.',f'Across all four table sizes, v4’s Hard-minus-App win-rate difference is {paired(raw["hardApp"]["2to5"]["v4"])}. Read that alongside the per-size results. A similar pooled rate does not mean every table size or player strategy has equal difficulty.')
point('Crashes and endings.',f'The fresh run records {raw["errors"]} errors and {raw["stalls"]} turn-cap outcomes in 14,400 games. The released ladder records {ladder["stalls"]} turn-cap outcomes in 7,200 games. Two complete full-deck Expert browser games reached final scoring with four and five rivals, and no page errors or network requests.')
sub('What to fix first')
p('<b>1.</b> Resolve E1 with one explicit corner order shared by code and print, and replace the regression’s storage-order assumption with a board-coordinate expectation. Apply the same convention to Habitat’s identical fallback. Recheck the three recovery seeds and rerun affected balance measurements after changing targets.')
p('<b>2.</b> Keep the benchmark uniqueness checks and missing-size protection. Keep exact win counts and per-size results next to rounded percentages, and keep capped games visible as incomplete outcomes.')
p('<b>3.</b> Keep the Testing section tied to its named sample and checkpoints. The fresh Hard estimate and interval should accompany a claim that Hard meets a numerical target. Additional training or a new rival redesign is not established as necessary by this corner defect.')
sub('Important limits')
p('This audit covers the release changes and nearby cases. It uses the shipped app directly, rendered printables and reproducible simulation. It is not an exhaustive new proof of every unchanged base-game rule or card. The simulator and frozen player helpers share source code; rule legality was checked independently where the change required it. Android hardware and a physical human tabletop session were not tested.')
p('For paper play, Empty Earth adds a global “are any species left?” check when the board is already barren, then uses the usual element choice and a corner tie-break. No extra deck, recurring counter or player decision is required. This is a procedure assessment, not a timed measurement of tabletop burden.')
point('Final verdict.','<b>Pass for continued playtesting, with E1 open.</b> Build identity, recovery, save compatibility, evaluator fixes and the reproduced ladder support that verdict. Fix the confirmed corner discrepancy before presenting the printed bot and app as exact counterparts. The fresh strategy results support only the measured policies and setup mix reported here.')
p('The accompanying evidence ZIP contains the importable saves, original and scratch assertions, complete game results, analysis scripts, logs, print checks and SHA-256 manifest. It contains no modified release gameplay code.','small')

def footer(canvas,doc):
    canvas.saveState()
    width,_=pagesizes.A4
    canvas.setStrokeColor(LINE)
    canvas.line(40,40,width-40,40)
    canvas.setFillColor(MUTED)
    canvas.setFont('DS',8)
    canvas.drawString(40,26,'Dominant Species Solo · v0.5.1 re-audit · 15 November 2026')
    canvas.drawRightString(width-40,26,str(doc.page))
    canvas.restoreState()

doc=SimpleDocTemplate(str(OUT),pagesize=pagesizes.A4,leftMargin=40,rightMargin=40,topMargin=40,
    bottomMargin=51,title='Dominant Species Solo v0.5.1 · Re-audit',author='OpenAI Codex')
doc.build(story,onFirstPage=footer,onLaterPages=footer)
print(OUT)

