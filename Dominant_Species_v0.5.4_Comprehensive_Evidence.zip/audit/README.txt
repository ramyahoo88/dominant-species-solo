Dominant Species Solo v0.5.4 -- Comprehensive Audit Evidence

Repository: https://github.com/ramyahoo88/dominant-species-solo
Commit: 4f32abb67c8c611e665be9427a65a54b5c3db8f2
HTML SHA-256: 4ed8110d6d15be58759fab88ec26e6611dc784812c83aecb03a77f8de44afadf
Audit date: 15 November 2026, America/Chicago (16 November UTC)

This archive accompanies Dominant_Species_v0.5.4_Comprehensive_Audit.pdf.
No production source or GitHub branch was modified. The forecast correction
in scripts/focused.cjs is an isolated diagnostic replacement, not a patch.

LAYOUT AND PREREQUISITES

Unpack the archive beside a full clone, so the parent contains both audit/
and dominant-species-solo/. Use a separate audit checkout at the commit above.
The historical-save checks require Git history, not a shallow source archive.
The audit ran with Node v24.22.1 and Python 3.12.14. The engine tests use Node
built-ins. The publication verifier needs PyMuPDF (import fitz); follow any
other dependency instructions in the repository. Report regeneration needs
ReportLab and DejaVu fonts at /usr/share/fonts/truetype/dejavu/.

QUICK REPRODUCTION (from inside dominant-species-solo/)

node --test source/rules.test.cjs
node source/smoke.cjs
node source/benchmark.cjs --selftest
python3 source/paper/verify-printables.py --output-dir ../print-check --rebuild
node ../audit/scripts/focused.cjs . ../audit/evidence
node ../audit/scripts/generated-positions.cjs . ../audit/evidence

The focused script checks all three new bot findings and writes the saves.
The generated-position script checks 320 inventory-valid synthetic positions,
8,320 card choices, 12,160 action choices, and 320 JSON copy/validation checks.
These are invariant and deterministic-choice tests, not an independent rules
oracle or proof that every generated position can arise in a complete game.

FRESH FULL-GAME EVALUATION

node source/benchmark.cjs --evaluate \
  --weights source/benchmark/tuned_weights_v4.json \
  --seed 111620260 --per-cell 60 --workers 8 \
  --modes app,m2,m1,0,1 \
  --policies tuned,majority,dominance,expansion > fresh.json

This is 4,800 games: 60 per combination of four table sizes, five rival systems
and four fixed purposeful player policies. App and Paper have different cell
seeds; this is not a paired App-versus-Paper effect estimate. The four policies
within a cell share setups. No player optimization was done in this audit.
Mode mapping: app = App rivals; m2 = Paper Easy; m1 = Paper Standard;
0 = Paper Hard; 1 = Paper Expert.

PRIOR INDEPENDENT REGRESSIONS (from inside dominant-species-solo/)

mkdir -p ../audit/evidence/prior-regressions/saves
node ../audit/evidence/prior-regressions/focused.cjs .
node ../audit/evidence/prior-regressions/rule-parity.cjs .
node ../audit/evidence/prior-regressions/remaining-ties.cjs .
node ../audit/evidence/prior-regressions/check-new-element-wording.cjs .
node ../audit/evidence/prior-regressions/mass-exodus-wording.cjs .

These scripts were retained from the earlier v0.5.4 evidence and rerun on the
audited commit. Their JSON results here are fresh. The original-saves folder
contains the two original Mammals regression fixtures used by focused.cjs.

IMPORTABLE FINDING SAVES

evidence/ice-age-wrong-mammal-save.json
  App Birds predict an Ice Age win, 16 to 12. Actual Mammals save D2 Wetland
  instead of D3 Tundra, so Mammals win 18 to 16. No intervening pawns remain.
  An isolated corrected forecast makes Birds take Fertile instead.

evidence/catastrophe-empty-center.json
  Paper Birds choose occupied E3. Literal printed weighted-removal rules
  favor empty D3. The missing occupied-target restriction explains the gap.

evidence/hibernation-quantity.json
  The app returns five eliminated Birds and protects all five. Paper text
  chooses the destination but leaves the return quantity unspecified.

These are constructed valid states reached through legal score-and-claim
steps, not naturally sampled complete-game histories. Engine validation
passed. Fresh browser import interactions could not be completed here.

OTHER EVIDENCE

manifest.json: version, runtime versions and audited source/release hashes.
focused.json: decision comparisons and diagnostic forecast result.
fresh-evaluation.json: complete raw JSON summary from the 4,800-game command.
fresh-evaluation.progress: full-game progress and completion counts.
generated-positions.json: coverage and errors for generated positions.
repository-tests.log: all 50 repository tests passed.
player-selftest.log: 24 player-harness self-test games passed.
smoke.json, smoke-repeat.json: two fresh 60-game runs.
baseline-diff.json: both fresh runs agree after excluding maxTime, while
  BASELINE_RESULTS.json differs (24,175 versus 24,169 total steps, etc.).
printables.log and printables/print-observations.json: publication checks.
printables/print-rebuild/: generated HTML and Markdown comparison products.
rendered/*contact*.png: visual evidence for all 31 publication pages.
pdf-fonts.json: extracted PDF font observations.
browser-limitations.txt: exact scope of the unavailable browser checks.
output/Audit_Text.txt: report source text, including ReportLab markup.
CHECKSUMS.json: SHA-256 of every other member in this evidence archive.

BROWSER AND INTERPRETATION LIMITS

No fresh browser pass is claimed. Playwright's matching bundled browser was
absent; installed Chromium could not start under the environment's Unix-socket
policy; the cloud browser rejected local file navigation. No policy bypass
was attempted. Previous v0.5.4 browser evidence applies to the same HTML bytes
but remains historical evidence. Browser launch diagnostics were not bundled
as passing tests. PDF text/source parity and rendering were checked; fresh
Chromium PDF pixel-identical regeneration was not completed.

No physical tabletop playtest, timed administrative study, exhaustive rules
proof or optimal-player claim is made. Simulated win rates measure the listed
policies, not human difficulty. Small differences between 60-game cells need
larger matched tests before balance changes. See the PDF for repair priorities.
