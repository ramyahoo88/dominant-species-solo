# Dominant Species Solo v0.5.5 re-audit evidence

The audit targets commit 4874b187af1474589384e7be6e173eb98183784a of ramyahoo88/dominant-species-solo. The prior release under comparison is 4f32abb. The shipped and rebuilt HTML share SHA-256 c29c1236136b73cb3d9e6fc73cfb8f5b81f993a5768a40fdb26e0cc6f05e5119.

## Open these first

- forecast-and-reminders.json gives the live results for each Mammals save, the losing Birds tie, the two card placement decisions and the earlier paper wording fixes.
- saves/ contains four importable, inventory-valid positions for the new findings. The two claim saves start with Birds choosing a Dominance Card. The two Planning saves start with the affected rival ready to draw the affected card.
- print-observations.json records each front and back, duplex trim coordinates checked to PDF precision, aid checks and generation fidelity. print-controls.log records the four deliberate faults rejected by the verifier.
- paired-summary.json gives the fresh-game sample size at each rival count and full records for any observed differences. fresh-game-manifest.jsonl records per-pair scores, winners and hashes of the full benchmark records. 620025-trace.json is the direct two-commit replay.
- verify-printables-v0.5.5.patch updates the existing repository checker. The patch affects the verifier alone.

## Reproduce

Use Node.js 22+ and Python with PyMuPDF and Markdown. From the pinned Git checkout, set <code>DS_EVIDENCE</code> to the absolute path of the extracted evidence folder and run these commands.

    git apply "$DS_EVIDENCE/verify-printables-v0.5.5.patch"
    node --test source/rules.test.cjs
    node source/smoke.cjs --check
    python3 source/build.py --output /tmp/ds-v055-audit/Dominant_Species_Solo.html
    sha256sum Dominant_Species_Solo.html /tmp/ds-v055-audit/Dominant_Species_Solo.html
    node "$DS_EVIDENCE/check-forecast-and-reminders.cjs" "$PWD" /tmp/ds-v055-audit/saves
    node "$DS_EVIDENCE/check-shipped-controls.cjs" "$PWD" /tmp/ds-v055-audit/saves
    python3 source/paper/verify-printables.py --output-dir /tmp/ds-v055-audit/print --rebuild
    python3 "$DS_EVIDENCE/check-print-controls.py" "$PWD" "$PWD/source/paper/verify-printables.py"

The matched-game script uses a temporary copy of the repository runner. It applies the paper-mode setting on both sides of the comparison. The Red Queen run uses the Expert setting of one extra pawn. The supplied summary lists which Tooth & Claw samples ran across every seat assignment for a repeat and which used only the Mammals assignment.

    python3 "$DS_EVIDENCE/run-matched.py" "$PWD" /tmp/ds-v055-audit/queen --mode queen
    python3 "$DS_EVIDENCE/run-matched.py" "$PWD" /tmp/ds-v055-audit/tooth --mode tooth --one-repeat
    python3 "$DS_EVIDENCE/run-matched.py" "$PWD" /tmp/ds-v055-audit/assignments --mode tooth --one-repeat --one-assignment --bots 2 --bots 3 --bots 4
    node source/benchmark.cjs --base 4f32abb --candidate 4874b18 --seed 620000 --bots 5 --repeats 5 --human reptiles --policy dominance --trace --workers 1

For the legacy control, add <code>--paper-options oldForecast</code> to the last command. The first four of those filtered games are neighboring Reptiles setups. The fifth is seed 620025.

The 720 generated scoring snapshots validate inventory and exercise the real card and reset handlers. Synthetic snapshots do not measure how often the findings arise in play. The Node DOM shim checks the shipped script and controls. Local Chromium launch failed before test execution, so browser rendering was unverified in this audit. The contact sheets show the shipped digital PDFs. Physical print registration and the full tuned-player evaluation were outside scope.
