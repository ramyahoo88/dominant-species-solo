// Scratch proposal only. No release source is changed.
// Define "top-left first" explicitly as uppermost, then leftmost.
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const root = __dirname;
const repo = path.resolve(process.argv[2] || path.join(root,'../dominant-species-audit-v051'));
const {load,PLAYER_REFERENCE}=require(path.join(repo,'source/benchmark/load.cjs'));
const rt=load('worktree',['game','nn/driver']);
rt.run(`
  function pTopLeftEmptyCorners(s) {
    return activeCorners(s).filter(k => !s.corners[k]).sort((a,b) => {
      const [ax,ay] = a.split(',').map(Number), [bx,by] = b.split(',').map(Number);
      return ay - by || ax - bx;
    });
  }
`);
const original=rt.get('paperPawn').toString();
const patched=original.replace('activeCorners(s).filter(k => !s.corners[k])','pTopLeftEmptyCorners(s)');
assert.notEqual(patched,original);
rt.run('paperPawn = ('+patched+')');
const fixture=JSON.parse(fs.readFileSync(path.join(root,'saves/v050-empty-abundance.json'),'utf8')).game;
const s=rt.get('validateState')(fixture);
const step=rt.get('nextStep')(s);
const choice=rt.get('paperPawn')(s,step);
const habitatStep={kind:'effect',name:'Habitat',actor:'mammals'};
const habitatBefore=rt.get('paperEffect')(s,habitatStep);
const effectOriginal=rt.get('paperEffect').toString();
const effectPatched=effectOriginal.replace('activeCorners(s).filter(k => !s.corners[k])','pTopLeftEmptyCorners(s)');
assert.notEqual(effectPatched,effectOriginal);
rt.run('paperEffect = ('+effectPatched+')');
const habitatAfter=rt.get('paperEffect')(s,habitatStep);
const available=rt.get('activeCorners')(s).filter(k=>!s.corners[k]);
const minY=Math.min(...available.map(k=>Number(k.split(',')[1])));
const minX=Math.min(...available.filter(k=>Number(k.split(',')[1])===minY).map(k=>Number(k.split(',')[0])));
assert.equal(choice.corner,`${minX},${minY}`);
assert.equal(habitatBefore.corner,'-7,-3');
assert.equal(habitatAfter.corner,choice.corner);
rt.get('runStep')(s,step,choice);
rt.get('validateState')(s);
const next=rt.get('paperPawn')(s,step);
assert.notEqual(next.corner,choice.corner,'skip the now occupied corner');
const player=load(PLAYER_REFERENCE,['player']);
const strategy={place:player.get('playerPlacement'),choose:player.get('playerChoice')};
const saved=JSON.parse(fs.readFileSync(path.join(root,'saves/published-stall-200074.json'),'utf8')).game;
const continued=rt.get('validateState')(saved);
const fromFunction=rt.get('nnContinue').toString();
const extended=fromFunction.replace('stepCount < 1800','stepCount < 12000').replace('s.turn > 30','s.turn > 120');
rt.run('const continueAudit=('+extended+')');
const outcome=rt.get('continueAudit')(continued,{cards:[],stacks:[[],[],[]]},continued.seed,continued.human,strategy,'expansion');
assert(continued.usedCards.includes('Ice Age') && continued.phase==='finished');
const result={proposal:'uppermost eligible corner, then leftmost',firstChoice:choice,
  nextCorner:next.corner,habitatFallback:{before:habitatBefore.corner,after:habitatAfter.corner},
  continuedFromTurn31:{...outcome,iceAge:true},releaseFilesChanged:false};
fs.writeFileSync(path.join(root,'top-left-prototype.json'),JSON.stringify(result,null,2)+'\n');
console.log(JSON.stringify(result,null,2));
