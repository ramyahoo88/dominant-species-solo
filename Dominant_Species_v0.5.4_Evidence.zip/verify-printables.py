"""Compare both columns of the released card PDF to their deck data."""
import hashlib
import json
import re
import runpy
import subprocess
import sys
import unicodedata
from html.parser import HTMLParser
from pathlib import Path
import fitz

root = Path(__file__).resolve().parent
repo = Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else root.parent/'dominant-species-solo'
paper = repo/'paper'
cards = fitz.open(paper/'Paper_Rivals_Cards.pdf')
rulebook = fitz.open(paper/'Paper_Rivals_Rulebook.pdf')
layout = ['mammals','reptiles','birds','amphibians','arachnids','insects']
js = """const fs=require('node:fs'),vm=require('node:vm');
 const out=vm.runInNewContext(fs.readFileSync(process.argv[1],'utf8')+';DECKS');
 console.log(JSON.stringify(out));"""
decks = json.loads(subprocess.check_output(['node','-e',js,str(repo/'source/src/decks.js')]))
checked = []
for index,animal in enumerate(layout):
    page = cards[index]
    assert animal.title() in page.get_textbox(fitz.Rect(0,0,612,43))
    for slot,card in enumerate(decks[animal]):
        x = 28.5 + slot % 2 * 252
        y = 45 + slot // 2 * 172.8
        lines = [t.strip() for t in page.get_textbox(fitz.Rect(x,y,x+252,y+172.8)).splitlines() if t.strip()]
        expected = [animal.upper(),str(slot+1),card['title']] + [
            f'{i}. {row.title()}' for i,row in enumerate(card['no']['rows'],1)
        ]
        assert lines == expected + ['Paper Rivals · try in order'], (slot,lines,expected)
        checked.append({'page':index+1,'animal':animal,'card':slot+1,'title':card['title'],'actions':card['no']['rows']})

assert len(checked) == 48
assert len(cards) == 6 and 'Generated from source/src/decks.js for app v0.5.4.' in cards[5].get_text()
ruletext = '\n'.join(page.get_text('text') for page in rulebook)
# v0.5.3 repeats table headers on continuation pages; remove only these
# three verified leading headers before comparing the complete text.
continuation_headers = []
for i, page in enumerate(rulebook):
    text = page.get_text('text')
    for prefix in ('Action\nHas a target when\n', 'Action\nWhat the rival does\n', 'Card\nThe rival chooses\n', 'Decision\nWhat the rival does\n', 'Card\nCard\n'):
        if text.startswith(prefix):
            continuation_headers.append({'page':i+1,'header':prefix.strip()})
            break
prefixes = ('Action\nHas a target when\n', 'Action\nWhat the rival does\n', 'Card\nThe rival chooses\n', 'Decision\nWhat the rival does\n', 'Card\nCard\n')
texts = []
for page in rulebook:
    text = page.get_text('text')
    for prefix in prefixes:
        if text.startswith(prefix):
            text = text[len(prefix):]; break
    texts.append(text)
ruletext = '\n'.join(texts)
assert len(continuation_headers) == 5, continuation_headers
assert 'Full display.' in ruletext and 'Barren Earth.' in ruletext
assert 'Stalls.' in ruletext
# Deck titles should appear in the deck table and again in the appendix.
for c in checked:
    assert ruletext.count(c['title']) == 2, c
assert '--paper=0 --bots 3 --seed 200000 --repeats 2' in ' '.join(ruletext.split())

class BodyText(HTMLParser):
    def __init__(self):
        super().__init__()
        self.inside = False
        self.chunks = []
        self.lists = []

    def handle_starttag(self, tag, attrs):
        if tag == 'body':
            self.inside = True
        if tag in ('ol', 'ul'):
            self.lists.append(0 if tag == 'ol' else None)
        if tag == 'li' and self.lists[-1] is not None:
            self.lists[-1] += 1
            self.chunks.append(f'{self.lists[-1]}.')

    def handle_endtag(self, tag):
        if tag == 'body':
            self.inside = False
        if tag in ('ol', 'ul'):
            self.lists.pop()

    def handle_data(self, data):
        if self.inside:
            self.chunks.append(data)


def normalized(text):
    return re.sub(r'\s+', '', unicodedata.normalize('NFKC', text))


body = BodyText()
body.feed((paper / 'Paper_Rivals_Rulebook.html').read_text())
normalized_book = normalized(''.join(body.chunks))
assert normalized_book == normalized(ruletext), 'Rulebook PDF text differs from the HTML'

report = {
    'continuationHeaders':continuation_headers, 'rulebookPages':len(rulebook), 'cardSheetPages':len(cards), 'cardsChecked':checked,
    'productionNoteOnLastCardSheet':True,
    'normalizedRulebookHTMLPDFCharactersMatched':len(normalized_book),
    'pdfSha256':{x.name:hashlib.sha256(x.read_bytes()).hexdigest() for x in paper.glob('*.pdf')},
}
if '--rebuild' in sys.argv:
    out = root/'print-rebuild'
    producer = runpy.run_path(str(repo/'source/paper/printables.py'))
    run = producer['main']
    run.__globals__['OUT'] = out
    sys.argv = ['printables.py']
    run()
    report['regeneratedTextMatches'] = {
        filename: (out/filename).read_bytes() == (paper/filename).read_bytes()
        for filename in ('Paper_Rivals_Rulebook.md','Paper_Rivals_Rulebook.html','Paper_Rivals_Cards.html')
    }
    assert all(report['regeneratedTextMatches'].values())
(root/'print-observations.json').write_text(json.dumps(report,indent=2)+'\n')
print(f"PASS {len(rulebook)} rulebook pages, {len(checked)} card identities and ordered faces in both columns")
