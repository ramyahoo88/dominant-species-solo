const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
const root=path.resolve(process.argv[2]||'dominant-species-solo');
const out=path.resolve(process.argv[3]||'audit/evidence');fs.mkdirSync(out,{recursive:true});
const {load}=require(path.join(root,'source/benchmark/load.cjs'));
const r=load('worktree');
const get=n=>r.get(n), copy=o=>JSON.parse(JSON.stringify(o));
function blank(paper=true){
 const s=get('newGame')('insects',['birds','mammals'],false,111620261,paper?{extra:0}:null);
 for(const tile of Object.values(s.tiles))for(const id of s.ids)tile.cubes[id]=0;
 return s;
}
function balance(s){for(const id of s.ids)s.animals[id].pool=get('SETUP_BY_PLAYERS')[s.ids.length][1]-1-s.animals[id].dead-Object.values(s.tiles).reduce((n,t)=>n+t.cubes[id],0);}
function save(name,s){get('validateState')(s);fs.writeFileSync(path.join(out,name+'.json'),JSON.stringify({format:get('SAVE_KEY'),game:s},null,2));}
function claim(s,actor,card,tile){
 s.phase='execution';s.cursor=get('EXECUTION').indexOf('domination-0');
 s.market=[card,null,null,null,null];s.pawns={'domination-0':{actor,card:null,focus:null}};
 const score=get('nextStep')(s); assert.equal(get('cone')(s,tile),actor);
 get('runStep')(s,score,{tile});get('runStep')(s,get('nextStep')(s),{card});
 assert.equal(get('nextStep')(s).name,card);
 get('validateState')(s);
}
const evidence={commit:require('node:child_process').execFileSync('git',['-C',root,'rev-parse','HEAD'],{encoding:'utf8'}).trim()};
// Reach a real Catastrophe effect from a legal scoring and claim sequence.
{
 const s=blank();s.tiles.C3.cubes.birds=1;
 for(const tile of ['C4','D2','D4','E4','E3'])s.tiles[tile].cubes.mammals=1;
 balance(s);claim(s,'birds','Catastrophe','C3');save('catastrophe-empty-center',s);
 const actual=get('paperEffect')(copy(s),get('nextStep')(s));
 const opps=s.ids.filter(x=>x!=='birds').sort((a,b)=>s.animals[b].vp-s.animals[a].vp||get('rank')(a)-get('rank')(b));
 const all=get('terrainIds')(s).map(tile=>{
   const c=s.tiles[tile].cubes; const own=c.birds>0;
   const present=s.ids.filter(x=>c[x]>0);
   const keep=own?'birds':present.sort((a,b)=>s.animals[a].vp-s.animals[b].vp||get('rank')(b)-get('rank')(a))[0]||null;
   const center=s.ids.reduce((n,id)=>n+(id==='birds'?-2:1)*(c[id]-(id===keep?1:0)),0);
   const hits=get('NEIGHBORS')[tile].filter(t=>s.tiles[t]).flatMap(t=>{
     const victim=opps.find(id=>s.tiles[t].cubes[id]) || (s.tiles[t].cubes.birds?'birds':null);
     return victim?[{tile:t,victim}]:[];
   });
   return {tile,keep,hits,value:center+hits.reduce((n,h)=>n+(h.victim==='birds'?-2:1),0),vp:get('TERRAIN')[s.tiles[tile].terrain].vp[0]};
 }).sort((a,b)=>b.value-a.value||b.vp-a.vp||a.tile.localeCompare(b.tile));
 assert.equal(all[0].tile,'D3');assert.notEqual(actual.tile,'D3');
 const actualTrial=copy(s);get('runStep')(actualTrial,get('nextStep')(actualTrial),actual);get('validateState')(actualTrial);
 const literalTrial=copy(s);get('runStep')(literalTrial,get('nextStep')(literalTrial),all[0]);get('validateState')(literalTrial);
 evidence.catastrophe={actual,literalBest:all[0],allChoices:all,actualRemoved:5-Object.values(actualTrial.tiles).reduce((n,t)=>n+t.cubes.mammals,0),literalRemoved:5-Object.values(literalTrial.tiles).reduce((n,t)=>n+t.cubes.mammals,0)};
}
// A matched Hibernation position with five eliminated species: quantity affects the rank test.
{
 const s=blank();s.tiles.C3.cubes.birds=1;s.animals.birds.dead=5;
 s.tiles.D3.cubes.mammals=3;
 balance(s);claim(s,'birds','Hibernation','C3');save('hibernation-quantity',s);
 const choice=get('paperEffect')(copy(s),get('nextStep')(s));assert.equal(choice.n,5);
 const trial=copy(s);get('runStep')(trial,get('nextStep')(trial),choice);get('validateState')(trial);
 evidence.hibernation={choice,protected:trial.animals.birds.ward};
}
// A final-turn app choice: the estimator saves the first Mammal, actual reset saves a higher-value one.
{
 const s=blank(false);s.corners={};s.turn=9;
 s.tiles.D3.cubes.mammals=1;s.tiles.D2.cubes.mammals=1;s.tiles.C3.cubes.birds=1;
 const key=get('VERTICES_OF').C3.find(k=>!get('CORNER_TILES')[k].some(t=>['D3','D2'].includes(t)));
 assert(key);s.corners[key]='seed';s.animals.mammals.vp=10;s.animals.birds.vp=3;
 balance(s);s.phase='execution';s.cursor=get('EXECUTION').indexOf('domination-0');
 s.market=['Ice Age','Fertile',null,null,null];s.usedCards=get('DOMINANCE').filter(c=>!s.market.includes(c));
 s.pawns={'domination-0':{actor:'birds',card:null,focus:null}};
 get('runStep')(s,get('nextStep')(s),{tile:'C3'});
 assert.equal(get('nextStep')(s).kind,'claim');assert.equal(get('nextStep')(s).actor,'birds');
 save('ice-age-wrong-mammal-save',s);
 const estimates=Object.fromEntries(s.ids.map(id=>[id,get('endEstimate')(s,id)]));
 const choice=get('botAction')(copy(s),get('nextStep')(s));assert.equal(choice.card,'Ice Age');
 const trial=copy(s);get('runStep')(trial,get('nextStep')(trial),copy(choice));
 get('runStep')(trial,get('nextStep')(trial),get('botAction')(trial,get('nextStep')(trial)));
 const extinction=get('botAction')(trial,get('nextStep')(trial));
 get('runStep')(trial,get('nextStep')(trial),extinction);get('validateState')(trial);
 assert.equal(trial.phase,'finished');assert.equal(get('standings')(trial)[0],'mammals');
 assert(estimates.birds>estimates.mammals);
 evidence.iceAge={estimates,choice,save:extinction.saved,actual:Object.fromEntries(trial.ids.map(id=>[id,trial.animals[id].vp])),winner:get('standings')(trial)[0]};
}
// Diagnostic only: project the same reset choices as the actual engine, without changing production.
{
 const s=JSON.parse(fs.readFileSync(path.join(out,'ice-age-wrong-mammal-save.json'),'utf8')).game;
 r.run(`endEstimate=function(s,id){
   const t=copy(s);for(const [a,vp]of Object.entries(icePoints(t)))earned(t,a,vp);
   t.ending=true;const step={kind:'extinction',actor:t.ids.includes('mammals')?'mammals':null};
   resolveExtinction(t,botAction(t,step).saved);return t.animals[id].vp;
 };`);
 const corrected=Object.fromEntries(s.ids.map(id=>[id,get('endEstimate')(s,id)]));
 const choice=get('botAction')(s,get('nextStep')(s));assert.equal(choice.card,'Fertile');
 evidence.iceAge.diagnosticCorrected={estimates:corrected,choice};
}
fs.writeFileSync(path.join(out,'focused.json'),JSON.stringify(evidence,null,2));console.log(JSON.stringify(evidence,null,2));
