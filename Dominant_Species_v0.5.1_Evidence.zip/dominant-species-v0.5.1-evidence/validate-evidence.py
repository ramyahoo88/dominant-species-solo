"""Check completeness and sample identity before packaging the audit."""
import hashlib
import json
from collections import Counter
from pathlib import Path

root=Path(__file__).resolve().parent
read=lambda name: json.loads((root/name).read_text())
f=read('benchmarks/fresh-results.json')
p=read('benchmarks/published-results.json')
s=read('benchmarks/fresh-summary.json')
l=read('benchmarks/published-summary.json')
assert f['commit']==p['commit']==s['commit']==l['commit']=='dec3a3bec5ed3fbe0ede969c00d1a8b51ac4f596'
assert f['done']==f['setups']==1440 and f['games']==14400 and f['errors']==0
assert len(f['rows'])==1440 and all(f['rows'])
assert p['done']==480 and p['games']==7200 and p['oldGames']==5760 and all(p['rows'])
identities=[]
profiles={'dominance','majority','expansion','v3','v4'}
for row in f['rows']:
    setup=row['setup']
    identities.append((setup['seed'],setup['human'],tuple(setup['rivals']),setup['short']))
    assert set(row['cells'])=={'app','hard'}
    assert all(set(outcomes)==profiles for outcomes in row['cells'].values())
assert len(set(identities))==1440
sizes=Counter(len(r['setup']['rivals']) for r in f['rows'])
assert sizes=={2:360,3:360,4:360,5:360}
for n in (2,3,4,5):
    rows=[r for r in f['rows'] if len(r['setup']['rivals'])==n]
    assert sorted(r['setup']['seed'] for r in rows)==list(range(910000+1000*n,910000+1000*n+360))
    assert sum(r['setup']['short'] for r in rows)==180
    assert set(Counter(r['setup']['human'] for r in rows).values())=={60}
    for mode in ('app','hard'):
        for policy in profiles:
            wins=sum(r['cells'][mode][policy]['win'] for r in rows)
            assert wins==s['levels'][mode]['sizes'][str(n)][policy]['wins']
changed=[(row['setup'],change) for row in p['rows'] for change in row['changes']]
assert len(changed)==len(l['changes'])==6
winner_changed=[(setup,c) for setup,c in changed if c['before']['winner']!=c['after']['winner']]
assert len(winner_changed)==1
setup,change=winner_changed[0]
assert setup['seed']==200018 and setup['human']=='reptiles' and len(setup['rivals'])==3
assert change['name']=='standard' and change['policy']=='expansion'
assert not p['stalls'] and p['oldStalls']==1
for row in l['table']:
    assert all(row[k]['agrees'] for k in ('easy','standard','hard','expert','app'))
    games=[r for r in p['rows'] if len(r['setup']['rivals'])==row['rivals']]
    for mode in ('easy','standard','hard','expert'):
        old=sum(out['win'] for r in games for out in r['baseline'][mode].values())
        new=row[mode]['wins']
        assert new-old==(1 if row['rivals']==3 and mode=='standard' else 0)
assert read('browser-empty-earth.json')['archivedTurn31ImportedAndSupplied']
assert read('print-observations.json')['rulebookPages']==11
assert len(read('print-observations.json')['cardsChecked'])==48
assert not read('environment.json')['gitTrackedStatus']
out={'passed':True,'freshGames':f['games'],'freshSetups':f['done'],
     'freshErrors':f['errors'],'freshStalls':f['stalls'],
     'ladderGames':p['games'],'oldPaperGames':p['oldGames'],
     'changedPaperGames':len(changed),'winnerChanges':len(winner_changed),
     'publishedCellsMatched':20,'cornerFailureIntentional':True}
(root/'validation.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
