"""Build the final re-audit after the frozen fresh batch and its summary finish."""
from pathlib import Path
import json, html
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, PageBreak, KeepTogether
from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.enums import TA_LEFT
from reportlab.lib.pagesizes import letter

ROOT=Path(__file__).resolve().parent
OUT=ROOT.parent/'deliverables';OUT.mkdir(exist_ok=True)
summary=json.loads((ROOT/'benchmarks/fresh-summary.json').read_text())
assert summary['done']==1440 and summary['games']==14400 and summary['errors']==0
parity=json.loads((ROOT/'rule-parity.json').read_text())
gap=summary['extraLogOdds']['hard'];ci=gap['approximateBootstrap95']
REPO='https://github.com/ramyahoo88/dominant-species-solo/blob/158c9d8/'
HASH='4ed8110d6d15be58759fab88ec26e6611dc784812c83aecb03a77f8de44afadf'
styles=getSampleStyleSheet()
styles.add(ParagraphStyle(name='TitleCustom',fontName='Helvetica-Bold',fontSize=23,leading=27,textColor=colors.HexColor('#163d39'),spaceAfter=14))
styles.add(ParagraphStyle(name='SectionCustom',fontName='Helvetica-Bold',fontSize=13,leading=17,textColor=colors.HexColor('#163d39'),spaceBefore=11,spaceAfter=6))
styles.add(ParagraphStyle(name='BodyCustom',fontName='Helvetica',fontSize=10,leading=14,spaceAfter=8))
styles.add(ParagraphStyle(name='SmallCustom',fontName='Helvetica',fontSize=8.5,leading=11.5,spaceAfter=5))
styles.add(ParagraphStyle(name='TableCustom',fontName='Helvetica',fontSize=9,leading=12))
styles.add(ParagraphStyle(name='CodeCustom',fontName='Courier',fontSize=8,leading=11,spaceAfter=8))
story=[]
def p(text,style='BodyCustom'): return Paragraph(text,styles[style])
def add(text,style='BodyCustom'): story.append(p(text,style))
def section(text): add(text,'SectionCustom')
def table(rows,widths):
    t=Table([[p(str(cell),'TableCustom') for cell in row] for row in rows],colWidths=widths,repeatRows=1,hAlign='LEFT')
    t.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),colors.HexColor('#e9f0ed')),('VALIGN',(0,0),(-1,-1),'TOP'),('LINEBELOW',(0,0),(-1,0),.6,colors.HexColor('#718d83')),('LINEBELOW',(0,1),(-1,-1),.35,colors.HexColor('#d3dfd8')),('LEFTPADDING',(0,0),(-1,-1),7),('RIGHTPADDING',(0,0),(-1,-1),7),('TOPPADDING',(0,0),(-1,-1),6),('BOTTOMPADDING',(0,0),(-1,-1),6)]))
    story.append(t);story.append(Spacer(1,9))
def source(label,path): return f'<link href="{REPO+path}" color="#196f78">{label}</link>'
def page(): story.append(PageBreak())

add('Dominant Species Solo<br/>v0.5.4 re-audit','TitleCustom')
add('15 November 2026 | Main at 158c9d848e3722863d9dbce391eb1bd5ca75d624','SmallCustom')
add('<b>Verdict: passes the requested fixes and rule changes; suitable for continued playtesting.</b> One low-priority, pre-existing omission remains in the printed Mass Exodus procedure. Clarify that fallback before describing the paper instructions as an exact account of every app choice. No production code was changed.')
add(f'<b>Fresh Hard X35:</b> {gap["mean3to5"]:+.2f}; approximate 95% interval {ci[0]:+.2f} to {ci[1]:+.2f}. All 14,400 fresh games finished; {summary["errors"]} errors and {summary["stalls"]} turn-cap stalls. This is a scripted-player comparison, not a human win-rate forecast.')
section('P2 - Mass Exodus needs its occupied-tile fallback')
add('<b>Severity: low, printed rule omission. Pre-existing in v0.5.3.</b> The first sentence says to choose the tile without the rival\'s species holding the most opposing species. It gives no option when the rival occupies every tile. The app first filters to occupied tiles with a neighbor, then <i>prefers</i> a tile without its species. It can therefore choose a tile it occupies.')
add('<b>Reproduction:</b> import <font name="Courier">mass-exodus-own-everywhere.json</font>. Mammals occupy all seven tiles; Insects have three species on D3. After a normal score-and-claim sequence, the app resolves Mass Exodus from D3: the Mammal goes to D2 and the three Insects go to D4. There is no tile satisfying the printed first sentence. The fixture passes save validation; the released HTML previews, applies and undoes the move correctly. v0.5.3 makes the same choice.')
add('<b>Suggested replacement for the first sentence:</b> "Among occupied tiles with an adjacent tile on Earth, prefer one without its own species; then choose the one holding the most opposing species. Break ties by higher first-place value, then board order." Keep the existing destination instructions.')
add('This preserves the app and its measured results. It adds a fallback, not a new decision rule.', 'SmallCustom')
add('Sources: '+source('RULES.md, Mass Exodus','source/paper/RULES.md#L124')+'; '+source('paperEffect, Mass Exodus','source/paper/paper.js#L505')+'; printed rulebook p. 6. Evidence: <font name="Courier">mass-exodus-wording.json</font>, <font name="Courier">browser-mass-exodus.json</font>.','SmallCustom')
add('GMT\'s rulebook says to resolve as much of a chosen Dominance Card as possible (p. 18). The app\'s fallback is consistent with that requirement. <link href="https://www.gmtgames.com/living_rules/DS3_Rulebook-web_FINAL.pdf" color="#196f78">GMT rulebook</link>.','SmallCustom')

page();add('Requested fixes and app / paper parity','TitleCustom')
table([
 ['Check','Result'],
 ['A1: turn-1 scaled Easy','Pass. With five rivals: each rival returns 1 pawn and has 2; the player takes 1 extra and has 4. The legacy v0.5.2 save instead says to return 2, leaving 1 per rival and 3 for the player. Both verified in Chromium.'],
 ['P1: five printed priorities','Pass. Wanderlust: leftmost usable box element. Metamorphosis: printed type, then element order. Immigrants: earliest second added copy. Aquatic: Habitat\'s element fallback. Catastrophe: lower food-chain animal at equal lowest VP. All five archived browser positions pass.'],
 ['Migration placement','Pass. An independent first-move test checked 300 generated boards / 1,050 rival decisions: 781 permitted and 269 blocked. Rescue, spare-cube/rank restrictions and Birds\' two-tile reach agree. Planning previews leave the state unchanged.'],
 ['Rival-only dominance ties','Pass. 1,500 constructed cases cover match count first, then species, then food chain; ties including the player, absent animals and zero matches. A browser example gives the card to Insects in a new game and Mammals in a legacy game.'],
 ['Five card skips','Pass. Both sides of all five predicates, the empty bag, Amphibians\' printed third element, all-skipped fallback, and Niche Biomes after tile scoring. The fallback follows the priority list, not the order of cards in the market.'],
 ['Empty Earth','Pass. No species anywhere and player-only species both enable the exception. One surviving rival species disables it globally. New and legacy browser fixtures place the first empty corner in board order, and undo/reload correctly.'],
 ['Level table','Pass. The printed table gives pawn adjustments only, including the five-rival Easy exception. No descriptive difficulty claims remain in that table.']
],[132,384])
add('Migration\'s normal placement test is not a guarantee that the pawn will move later: earlier actions can change the board. The printed last-resort instruction can also fill an otherwise useless open space. Those are stated rules, not discrepancies.','SmallCustom')
add('The five new card skips implement the listed conditions; they do not detect every possible no-effect card. If all available cards are skipped, the priority list still supplies a card.','SmallCustom')

page();add('Older saves and release verification','TitleCustom')
add('Saves were created with the actual historical source, imported into v0.5.4, re-exported, imported again and reloaded in Chromium. Their pawn counts and saved rule flags remain intact. The new Migration test, five card skips and expanded Empty Earth also pass on each migrated state.')
table([
 ['Original version','Tie rule retained','Planning / five-rival Easy'],
 ['v0.3.6, v0.3.9','Rival ties remain undominated','Normal Initiative order; 3 pawns each'],
 ['v0.4.1','Food chain only','Normal Initiative order; 2 per rival, 3 for player'],
 ['v0.5.0, v0.5.1, v0.5.2','Food chain only','Rivals plan first; 1 per rival, 3 for player'],
 ['v0.5.3','Food chain only','Rivals plan first; scaled Easy: 2 per rival, 4 for player'],
 ['New v0.5.4','Most species, then food chain','Rivals plan first; scaled Easy: 2 per rival, 4 for player']
],[133,153,230])
add('The saved <font name="Courier">speciesTie</font> flag controls the new tie rule. Importing a pre-v0.5.4 game does not add it. The browser Help explains the older tie rule. The older level name is recovered where necessary without changing the saved pawn counts.')
section('Release checks')
table([
 ['Check','Evidence'],
 ['Exact build','The shipped root HTML and a separate source build both match the supplied SHA-256. 472,594 bytes.'],
 ['Repository checks','48/48 rules tests pass; tuned-player self-test passes.'],
 ['Setup coverage','96 human / rival-count / level combinations and JSON round trips; all 16 rival-count / level combinations exercised through the setup UI.'],
 ['Browser behavior','The two original Extinction positions still pass preview, apply, undo/replay and reload. Five P1 positions pass. Eleven additional saved-rule/action checks pass. No page errors or HTTP(S) requests in the successful offline audit runs.'],
 ['Print consistency','Markdown and both print HTML files regenerate identically. All rulebook text matches the PDF after removing the five verified repeated table headers. All 48 printed card faces match the deck data; all 12 rulebook pages visually checked.']
],[133,383])
add('Build SHA-256','SmallCustom');add(HASH[:32]+'<br/>'+HASH[32:],'CodeCustom')
add('The source checkout remained unchanged. This re-audit does not claim a new full-game rules certification or physical playtesting.','SmallCustom')

page();add('Fresh Hard X35','TitleCustom')
add(f'<b>X35 = {gap["mean3to5"]:+.3f}</b>, approximate 95% matched-setup bootstrap interval <b>{ci[0]:+.3f} to {ci[1]:+.3f}</b>. The project\'s comparison threshold is +0.20.')
def percent(x): return f'{x:.1f}%'
rows=[['Rivals','Hard v4','App v4','Extra log-odds','95% interval']]
for n in (2,3,4,5):
    h=summary['levels']['hard']['sizes'][str(n)]['v4'];a=summary['levels']['app']['sizes'][str(n)]['v4'];g=gap['perSize'][str(n)]
    rows.append([str(n)+(' (control)' if n==2 else ''),f'{h["wins"]}/360<br/>{percent(h["winPct"])}',f'{a["wins"]}/360<br/>{percent(a["winPct"])}',f'{g["point"]:+.3f}',f'{g["approximateBootstrap95"][0]:+.3f} to {g["approximateBootstrap95"][1]:+.3f}'])
table(rows,[88,93,93,105,137])
add('The metric subtracts the stronger v3/v4 player\'s App advantage over its best fixed policy from v4\'s Hard advantage over its best fixed policy, on a log-odds scale. X35 averages that contrast equally across three, four and five rivals; two rivals are a separate control. A negative result means the tuned player gains less extra advantage against Paper Hard than against App rivals.')
section('Frozen sample and uncertainty')
add('360 matched setups at each table size; 1,440 setups and 14,400 games in total. Each setup is played by the Domination, majority, expansion, tuned v3 and tuned v4 player policies at both Paper Hard and App. Human animals and rival combinations are balanced; every table size has 180 short and 180 full games. The v3/v4 weights were frozen, not retuned.')
add('Fresh seed block 1,140,000: 1,142,000-1,142,359 (two rivals), 1,143,000-1,143,359 (three), 1,144,000-1,144,359 (four), 1,145,000-1,145,359 (five). These ranges were absent from the repository\'s recorded studies and the preceding audit\'s seed block.')
add('3,000 bootstrap draws resample whole matched setups within each rival-count stratum and reselect the best comparators on every draw. Logits use the release analysis bounds [0.005, 0.995]. The independent exact-count result agrees with the repository reporting helper to displayed precision.')
add('The normal 30-turn cap and step-by-step state validation were retained. The optimized loader was checked against the standard VM loader on 24 matched setups / 240 games; all recorded per-game results, margins, turn/step counts and counters agree. No failed or capped outcomes were silently removed.')
add('Reproduce with the commands and scripts in the accompanying Evidence ZIP. It includes raw outcomes, the analysis, loadable positions and successful browser logs. These results compare the named scripts. They do not establish human difficulty, enjoyment or tabletop administrative burden.','SmallCustom')

def footer(c,doc):
    c.setStrokeColor(colors.HexColor('#cbd9d2'));c.line(48,41,564,41)
    c.setFont('Helvetica',8);c.setFillColor(colors.HexColor('#52645c'))
    c.drawString(48,28,'Dominant Species Solo v0.5.4 | Independent re-audit | 15 November 2026')
    c.drawRightString(564,28,str(doc.page))
doc=SimpleDocTemplate(str(OUT/'Dominant_Species_v0.5.4_Reaudit.pdf'),pagesize=letter,leftMargin=48,rightMargin=48,topMargin=44,bottomMargin=56,title='Dominant Species Solo v0.5.4 Re-audit',author='ChatGPT')
doc.build(story,onFirstPage=footer,onLaterPages=footer)
print(OUT/'Dominant_Species_v0.5.4_Reaudit.pdf')
