const path=require('node:path'),fs=require('node:fs'),assert=require('node:assert/strict');
const repo=path.resolve(process.argv[2]||'../dominant-species-solo');
const rt=require(path.join(repo,'source/benchmark/load.cjs')).load('worktree');
Object.assign(rt.get('globalThis'),{assert});
const rows=rt.run(`(() => {
 const result=[];
 function base(){const s=newGame('birds',['mammals','arachnids'],true,1053100,{extra:0});s.phase='execution';s.cursor=EXECUTION.length;s.turn=3;s.corners={};s.animals.mammals.added=['water','sun'];return s;}
 const cases=[
 ['Regression',s=>{s.boxes.regression=['sun','water'];s.pawns['regression-0']={actor:'mammals',card:null,focus:null};s.pending.push({kind:'loss',actor:'mammals',source:'Regression',due:regressionDue(s,'mammals')});},c=>c.elements[0],'sun'],
 ['Disease',s=>s.pending.push({kind:'loss',actor:'mammals',source:'Disease',due:{threats:unique(s.animals.mammals.added),drops:1}}),c=>c.elements[0],'water'],
 ['Metamorphosis removed disk',s=>{s.usedCards.push('Metamorphosis');s.pending.push({kind:'effect',actor:'mammals',name:'Metamorphosis',tile:'D3'});},c=>c.out,'water'],
 ['Immigrants ordinary discard',s=>{addCube(s,'E4','mammals',3);s.pending.push({kind:'immigrant',actor:'mammals'});},c=>c.type,'water']];
 for(const [name,setup,pick,expected] of cases){const s=base();setup(s);validateState(s);const step=nextStep(s);const choice=botAction(s,step);assert.equal(pick(choice),expected);runStep(s,step,choice);validateState(s);result.push({name,choice});}
 return result;
})()`);
fs.writeFileSync(path.join(__dirname,'new-element-wording.json'),JSON.stringify(rows,null,2)+'\n');console.log(JSON.stringify(rows,null,2));
