"""Write matched-game counts and a per-game digest from completed benchmark JSONs."""
from hashlib import sha256
from pathlib import Path
import argparse
import json


def digest(game):
    return sha256(json.dumps(game, sort_keys=True, separators=(",", ":")).encode()).hexdigest()


def scores(game):
    return {animal: seat["vp"] for animal, seat in game["seats"].items()}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("audit", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--full-tooth", action="store_true")
    args = parser.parse_args()
    runs = args.audit / "runs"
    args.output.mkdir(parents=True, exist_ok=True)
    cases, manifests, differences = [], [], []
    for mode, directory in [
        ("tooth", runs if args.full_tooth else runs / "one-repeat"),
        ("queen", runs / "verified"),
    ]:
        for rivals in range(2, 6):
            path = directory / f"match-{mode}-{rivals}.json"
            sample = "full" if args.full_tooth or mode == "queen" else "one-repeat"
            if (not path.exists() or not path.stat().st_size) and mode == "tooth" and not args.full_tooth:
                path = runs / "one-assignment" / path.name
                sample = "one-assignment"
            if not path.exists() or not path.stat().st_size:
                assert mode == "tooth" and not args.full_tooth, f"missing expected run {path.name}"
                continue
            data = json.loads(path.read_bytes())
            assert data["baseRef"].startswith("4f32abb") and data["candidateRef"].startswith("4874b18")
            games = data["games"]
            row = {"mode": mode, "rivals": rivals, "sample": sample, "pairs": len(games),
                   "playerWinsBase": data["base"]["humanWins"], "playerWinsCandidate": data["candidate"]["humanWins"],
                   "resultChanges": 0, "winnerChanges": 0, "stalledPairs": 0}
            for base, candidate in games:
                for key in ("human", "seed", "policy", "rivals", "short", "openingSupply"):
                    assert base[key] == candidate[key]
                assert len(base["rivals"]) == rivals
                scenario = {key: base[key] for key in ("human", "seed", "policy", "rivals", "short")}
                row["resultChanges"] += int(base != candidate)
                row["winnerChanges"] += int(base["winner"] != candidate["winner"])
                row["stalledPairs"] += int(base.get("stalled", False) or candidate.get("stalled", False))
                manifests.append({
                    "mode": mode, **scenario, "winners": [base["winner"], candidate["winner"]],
                    "scores": [scores(base), scores(candidate)], "digests": [digest(base), digest(candidate)],
                })
                if base != candidate:
                    differences.append({"mode": mode, **scenario, "base": base, "candidate": candidate})
            cases.append(row)
    assert {row["mode"] for row in cases} == {"tooth", "queen"}
    with (args.output / "fresh-game-manifest.jsonl").open("w") as out:
        for record in manifests:
            print(json.dumps(record, separators=(",", ":")), file=out)

    direct, restored = [
        json.loads((runs / f"620025-{kind}.json").read_bytes())["games"] for kind in ("release", "control")
    ]
    direct_pair = next(pair for pair in direct if pair[0]["seed"] == 620025)
    assert all(base == candidate for base, candidate in restored)
    assert [game["winner"] for game in direct_pair] == ["reptiles", "birds"]
    report = {
        "freshSeed": 1265000, "policies": ["majority", "dominance", "expansion"],
        "freshComparison": cases, "freshResultDifferences": differences,
        "oldForecastControl": {"exactRecordedPairs": len(restored),
                               "seed620025": {"base": scores(direct_pair[0]), "candidate": scores(direct_pair[1])}},
    }
    (args.output / "paired-summary.json").write_text(json.dumps(report, indent=2) + "\n")
    trace_path = runs / "620025-trace.json"
    if trace_path.exists() and trace_path.stat().st_size:
        trace = json.loads(trace_path.read_bytes())["games"]
        anchor = next(pair for pair in trace if pair[0]["seed"] == 620025)
        (args.output / "620025-trace.json").write_text(json.dumps(anchor, indent=2) + "\n")
    print(json.dumps(cases, indent=2))


if __name__ == "__main__":
    main()
