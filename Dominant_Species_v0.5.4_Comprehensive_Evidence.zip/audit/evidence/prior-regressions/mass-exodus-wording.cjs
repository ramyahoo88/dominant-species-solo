// Printed Mass Exodus fallback omission, also present in v0.5.3.
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
const repo=path.resolve(process.argv[2]||'../dominant-species-solo');
const {load}=require(path.join(repo,'source/benchmark/load.cjs'));
const r=load('worktree');r.get('globalThis').assert=assert;
const out=r.run(`(()=>{
 const s=newGame('birds',['mammals','insects'],false,11405477,{extra:0});
 for(const t of terrainIds(s))for(const a of s.ids)removeCube(s,t,a,s.tiles[t].cubes[a],'pool');
 for(const t of terrainIds(s))addCube(s,t,'mammals',1);
 addCube(s,'D3','insects',3);
 s.turn=3;s.phase='execution';s.cursor=EXECUTION.indexOf('domination-0');
 s.pawns['domination-0']={actor:'mammals',card:null,focus:null};s.market=['Mass Exodus',null,null,null,null];
 validateState(s);assert.equal(cone(s,'E4'),'mammals');
 runStep(s,nextStep(s),{tile:'E4'});assert.equal(nextStep(s).kind,'claim');
 runStep(s,nextStep(s),botAction(s,nextStep(s)));validateState(s);
 const step=nextStep(s);assert.equal(step.name,'Mass Exodus');
 const choice=botAction(s,step);assert.equal(choice.tile,'D3');
 const literalTargets=terrainIds(s).filter(t=>!s.tiles[t].cubes.mammals);
 assert.equal(literalTargets.length,0);
 const after=copy(s);runStep(after,step,choice);validateState(after);
 return {save:{format:SAVE_KEY,game:s},step,choice,literalTargets,
   after:{cubes:Object.fromEntries(terrainIds(after).map(t=>[t,after.tiles[t].cubes]))}};
})()`);
const old=load('e5ecc40');old.get('globalThis').fixture=JSON.parse(JSON.stringify(out.save.game));
out.v053Choice=old.run('botAction(fixture,nextStep(fixture))');
assert.equal(out.v053Choice.tile,out.choice.tile);
fs.writeFileSync(path.join(__dirname,'saves/mass-exodus-own-everywhere.json'),JSON.stringify(out.save)+'\n');
delete out.save;
fs.writeFileSync(path.join(__dirname,'mass-exodus-wording.json'),JSON.stringify(out,null,2)+'\n');
console.log(JSON.stringify(out,null,2));
