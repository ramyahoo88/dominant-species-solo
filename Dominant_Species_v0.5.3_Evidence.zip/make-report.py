from pathlib import Path
from xml.sax.saxutils import escape
import hashlib,json
from reportlab.platypus import SimpleDocTemplate,Paragraph,Spacer,Table,TableStyle,PageBreak,Image,KeepTogether
from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet,ParagraphStyle
from reportlab.lib.enums import TA_LEFT
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont

ROOT=Path(__file__).resolve().parent
OUT=ROOT.parent/'deliverables';OUT.mkdir(exist_ok=True)
S=json.loads((ROOT/'benchmarks/fresh-summary.json').read_text())
X=S['extraLogOdds']['hard'];point=X['mean3to5'];lo,hi=X['approximateBootstrap95']
assert S['done']==1440 and S['games']==14400 and S['errors']==0
font=Path('/usr/share/fonts/truetype/dejavu')
for name,file in [('DS','DejaVuSans.ttf'),('DSB','DejaVuSans-Bold.ttf')]:pdfmetrics.registerFont(TTFont(name,str(font/file)))
pdfmetrics.registerFontFamily('DS',normal='DS',bold='DSB',italic='DS',boldItalic='DSB')
styles=getSampleStyleSheet()
styles.add(ParagraphStyle(name='BodyDS',fontName='DS',fontSize=9.6,leading=14,spaceAfter=7,textColor=colors.HexColor('#22332e')))
styles.add(ParagraphStyle(name='TitleDS',parent=styles['BodyDS'],fontName='DSB',fontSize=24,leading=29,spaceAfter=10))
styles.add(ParagraphStyle(name='HeadDS',parent=styles['BodyDS'],fontName='DSB',fontSize=14,leading=19,spaceBefore=11,spaceAfter=7))
styles.add(ParagraphStyle(name='SmallDS',parent=styles['BodyDS'],fontSize=8,leading=11,spaceAfter=5))
styles.add(ParagraphStyle(name='CellDS',parent=styles['BodyDS'],fontSize=8.4,leading=12,spaceAfter=0))
styles.add(ParagraphStyle(name='NoteDS',parent=styles['BodyDS'],backColor=colors.HexColor('#edf3ef'),borderPadding=9,spaceBefore=16,spaceAfter=16))
def p(text,style='BodyDS'):return Paragraph(text,styles[style])
def h(text):return p(text,'HeadDS')
def table(rows,widths):
    t=Table([[p(str(c),'CellDS') for c in row] for row in rows],colWidths=widths,repeatRows=1,hAlign='LEFT')
    t.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),colors.HexColor('#dfe9e3')),('VALIGN',(0,0),(-1,-1),'TOP'),('LINEBELOW',(0,0),(-1,0),.8,colors.HexColor('#527166')),('LINEBELOW',(0,1),(-1,-1),.4,colors.HexColor('#c9d6ce')),('TOPPADDING',(0,0),(-1,-1),7),('BOTTOMPADDING',(0,0),(-1,-1),7)]))
    return t
BASE='https://github.com/ramyahoo88/dominant-species-solo/blob/e5ecc40/'
def src(path,line,label):return f'<link href="{BASE}{path}#L{line}" color="#246e61"><u>{label}</u></link>'
def ci(a,b):return f'{a:+.2f} to {b:+.2f}'
target=('The estimate and its 95% interval are below the +0.20 target.' if hi<=.20 else
        'The estimate meets the +0.20 target, but the 95% interval crosses it.' if point<=.20 else
        'The estimate exceeds +0.20; its 95% interval overlaps the target.' if lo<=.20 else
        'The estimate and its 95% interval exceed the +0.20 target.')
story=[p('Dominant Species Solo<br/>v0.5.3 re-audit','TitleDS'),p('15 November 2026 | e5ecc40, with log-only follow-up f989466','SmallDS'),
 p('<b>Pass for continued playtesting, with two follow-ups.</b> The Mammals Extinction fix and scaled-Easy engine/save behavior pass. Correct the opening setup instructions and finish five printed priorities and fallbacks. No gameplay code was changed in this audit.','NoteDS'),
 h('A1 - Scaled Easy: opening instructions give the old counts'),
 p('<b>Medium severity; new in v0.5.3.</b> Start a Paper Easy game with five rivals. The selection screen correctly says two pawns per rival and four for you. On the next screen, however, the instructions say to set out three per animal and return two per rival. A player following that text ends with one per rival and three for themself, while the saved game uses two and four.'),
 Image(str(ROOT/'screenshots/scaled-easy-instruction-detail.png'),width=302,height=166.5),Spacer(1,8),
 p('<b>Smallest correction:</b> make the opening instructions use the saved <b>scaledEasy</b> flag. For those games, each rival returns one pawn and you take one extra; spell out the final counts, two and four. Keep the old wording for older Easy saves without that flag. Do not infer this from rival count and difficulty alone: older saves intentionally keep one and three.'),
 p(src('source/src/ui.js',337,'Opening instruction')+' | '+src('source/paper/paper.js',573,'Correct setup arithmetic'),'SmallDS'),
 h('Verified release'),
 p('The shipped HTML and an independent rebuild are byte-identical: <b>469,517 bytes</b>. f989466 changes only AUDIT_RESPONSE_v0.5.2.md and HARD_BALANCE_LOG.md. The checkout remained unchanged.'),
 p('SHA-256: 8a0a7d17ef37b1e01249a8f6a5bf2b393<br/>d8f72c6fc700219d8c2150a1ccfc56b','SmallDS'),
 PageBreak(),h('Extinction and the requested tie revisions'),
 table([['Original saved position','v0.5.3 Paper result','Verification'],
 ['Seed 960021, turn 5, Reptiles vs five Hard rivals','Saves B2 Sea instead of C2','Original archive imported; preview, apply, undo/replay and reload passed.'],
 ['Controlled tundra position, seed 520081','Saves C3; C3 and D3 retain one Mammal each; +3 Survival VP','Original archive imported and applied. App rivals retain D3 and their old behavior.']], [152,162,210]),
 Spacer(1,7),p('The new chooser prioritizes first-place value, then board order. The 17 prior controlled positions pass with the corrected C3 expectation. Ten positions also pass through the shipped HTML. Regression and Disease ordering is consistent with the new text: Regression-box order and earliest-added order respectively.'),
 p('The general Ties paragraph and the previously requested tile/corner priorities now match their tested app choices, including Abundance/Habitat, Depletion, Speciation, Wanderlust, Aquatic/Blight, Migration, Mass Exodus, Competition, Fertile and Mammals.'),
 h('P1 - Five choices still need printed priorities'),
 p('<b>Low severity; pre-existing omissions.</b> These are remaining ambiguities rather than regressions in the new tile/corner wording. Each example is a valid state, was applied through the engine and was reproduced through the released browser controls. The proposed text preserves the existing app behavior.'),
 table([['Row / reproduction','Exact wording to add'],
 ['<b>Wanderlust</b><br/>Mammals use both Sun and Meat; the box is Sun, Meat. The app takes Sun from position 1.', '"Take the leftmost element in the box that it uses."'],
 ['<b>Metamorphosis</b><br/>Sun and Water each occur once near Mammals; Meat occurs zero times. The app swaps Grass for Sun. The printed-type preference does not resolve this tie.', '"Among equally useful bag elements, prefer its printed type; if still tied, use Meat, Sun, Seed, Water, Grub, Grass order."'],
 ['<b>Immigrants</b><br/>Added disks are Water, Sun, Sun, Water, in that order. Both types are duplicated; the app discards Sun.', '"If several added types are duplicated, discard the type whose second copy was added earliest."'],
 ['<b>Aquatic</b><br/>No Meat remains in the bag. Mammals added Water, then Sun. The app takes Water; the row only specifies its printed element.', '"Choose the element using Habitat’s element priority."'],
 ['<b>Catastrophe</b><br/>Birds and Arachnids at C3 both have 10 VP. Mammals keep the Arachnid.', '"At equal lowest VP, keep the animal lower in the food chain."']], [250,274]),
 Spacer(1,7),p(src('source/paper/paper.js',248,'Wanderlust chooser')+' | '+src('source/paper/paper.js',496,'Metamorphosis chooser')+' | '+src('source/paper/paper.js',509,'Immigrants chooser')+' | '+src('source/paper/paper.js',362,'Aquatic fallback')+' | '+src('source/paper/paper.js',417,'Catastrophe survivor'),'SmallDS'),
 PageBreak(),h('Hard X35 on fresh seeds'),
 p(f'<b>X35 = {point:+.2f}</b>; 95% matched-setup bootstrap interval <b>{ci(lo,hi)}</b>. {target}','NoteDS'),
 p('1,440 matched setups, 14,400 games. Each setup was played by Domination, majority, expansion, tuned v3 and tuned v4, against both Paper Hard and App rivals. All weights stayed frozen. Each rival count has 360 setups, balanced across human animals, rival combinations and 180 full / 180 short decks. Opening supplies were asserted equal across each set of ten games.'),
 table([['Rivals','Domination','Majority','Expansion','Tuned v3','Tuned v4']]+[
 [str(n)]+[f"{S['levels']['hard']['sizes'][str(n)][v]['wins']} / {S['levels']['app']['sizes'][str(n)][v]['wins']}" for v in ['dominance','majority','expansion','v3','v4']] for n in range(2,6)], [44,96,96,96,96,96]),
 p('Wins are Paper Hard / App, each out of 360. Top-score ties are resolved by the game\'s food-chain rule.','SmallDS'),
 table([['Rivals','Excess log-odds','95% interval']]+[
 [str(n),f"{X['perSize'][str(n)]['point']:+.2f}",ci(*X['perSize'][str(n)]['approximateBootstrap95'])] for n in range(2,6)]+[
 ['3-5 average',f'{point:+.2f}',ci(lo,hi)]],[100,180,244]),
 Spacer(1,7),p('X35 uses the same metric as the previous audit: v4\'s log-odds advantage over the strongest fixed policy at Hard, minus the stronger v3/v4 advantage over the strongest fixed policy against App rivals. Average equally across three, four and five rivals. The bootstrap resamples complete matched setups within each rival count 3,000 times and reselects the strongest comparator on each draw. Logits are bounded at 0.005 and 0.995, matching the release helper.'),
 p(f"<b>Errors: {S['errors']}; stalls: {S['stalls']}.</b> The benchmark retained its 30-turn cap and validated state at every step. The normal VM loader exactly matched the optimized loader on 24 setups / 240 games. The independent statistic agrees with the repository reporting helper to displayed precision."),
 p('Seed ranges: 1,022,000-1,022,359; 1,023,000-1,023,359; 1,024,000-1,024,359; 1,025,000-1,025,359. These blocks were absent from the repository\'s recorded studies when the run began. This is a fixed-policy test, not a measured human win rate. It does not retune players or include the separately reported pb5 policy.'),
 PageBreak(),h('Scaled Easy, saves and print checks'),
 table([['Check','Result'],
 ['Initial pawn counts','96 engine cases: all six human animals, two to five rivals, four levels. Sixteen corresponding setup combinations passed in the shipped browser. Five-rival Easy is player 4 / rivals 2. All other combinations keep their prior counts.'],
 ['New and older saves','New Easy saves record scaledEasy and preserve counts after reload and export/import. An actual v0.5.2 Easy save keeps player 3 / rivals 1 after loading and starting Planning.'],
 ['Full browser game','Five-rival Easy, full deck: reached scoring in 618 UI steps with 186 rival applies. Undo/replay, reload and export/import passed; zero page errors or HTTP(S) requests. Chromium 131, offline, 390 px.'],
 ['Repository checks','All 44 rule tests passed. Tuner self-test passed (24 games). The normal offline browser smoke check passed.'],
 ['Recovery','The three prior stall seeds reach Ice Age on turns 6, 6 and 5. The archived turn-31 position reaches Ice Age on turn 33.'],
 ['Rulebook and cards','Markdown and both printable HTML files regenerate identically. All 11 rulebook PDF pages match the HTML text after whitespace/list normalization and removing three repeated continuation headers. All 48 card faces match their deck data. Layout visually checked across the full rulebook.'],
 ['Difficulty in print','Setup step 2 and the level table correctly state scaled Easy. The printed five-rival Easy figure is 47%, consistent with the release ladder data; that Easy win-rate study was not independently rerun here.']], [128,396]),
 h('Evidence and reproduction'),
 p('The companion evidence ZIP includes untouched original Extinction saves, the new and legacy Easy saves, the five residual priority/fallback saves, engine assertions, browser scripts/results, individual fresh-game results, metric calculations, release verification and a SHA-256 manifest.'),
 p('See README.md in the ZIP for commands. Node 24.22.1, Python 3.12, Playwright and Chromium 131.0.6778.204 were used. The optimized benchmark loader loads the same source modules and frozen-player adapter as the normal VM loader; it changes execution packaging only.'),
 p('Recommended follow-up: correct A1 and add the five P1 priorities, then rebuild the HTML and printables. Verify the new and legacy setup instructions and the five supplied priority/fallback saves. These wording changes need no balance retuning.'),
 p('This audit covers the requested release changes and the fresh Hard test. It is not a new exhaustive audit of the base game. No physical tabletop playtest or separate Claude mirror check was performed.','SmallDS')]

def footer(canvas,doc):
    canvas.setStrokeColor(colors.HexColor('#c9d6ce'));canvas.line(44,35,568,35)
    canvas.setFont('DS',8);canvas.setFillColor(colors.HexColor('#52665d'))
    canvas.drawString(44,23,'Dominant Species Solo | v0.5.3 audit | 15 November 2026')
    canvas.drawRightString(568,23,str(doc.page))
dest=OUT/'Dominant_Species_v0.5.3_Reaudit.pdf'
doc=SimpleDocTemplate(str(dest),pagesize=(612,792),leftMargin=44,rightMargin=44,topMargin=36,bottomMargin=46,title='Dominant Species Solo v0.5.3 re-audit',author='OpenAI')
doc.build(story,onFirstPage=footer,onLaterPages=footer)
print(dest)
