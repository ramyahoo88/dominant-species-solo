// Reproduce the complete release ladder and compare every Paper game with v0.5.0.
// Hash the returned decisions and outcome, while retaining all changed-game details.
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const {createHash} = require('node:crypto');
const BASE = 'c19e382079a3d118729b49f5d25b9f9eb04de942';
const {Worker,isMainThread,workerData,parentPort} = require('node:worker_threads');
const OFFSETS = {easy:-2,standard:-1,hard:0,expert:1,app:null};
const POLICIES = ['majority','dominance','expansion'];
const REPEATS = {2:2,3:2,4:4,5:20};
const SEED = 200000;
const root = __dirname;

function combos(values, n) {
  return n===0 ? [[]] : values.flatMap((v,i)=>combos(values.slice(i+1),n-1).map(xs=>[v,...xs]));
}
function makeCases(food) {
  const all = [];
  for (const n of [5,4,3,2]) {
    let i=0;
    for (let r=0;r<REPEATS[n];r++) for (const human of food) for (const rivals of combos(food.filter(a=>a!==human),n)) {
      const seed=SEED+i++;
      all.push({human,rivals,seed,short:(seed+r)%2===0});
    }
    assert.equal(i,120);
  }
  return all;
}

function worker() {
  const {repo,jobs} = workerData;
  const {load,PLAYER_REFERENCE} = require(path.join(repo,'source/benchmark/load.cjs'));
  const r = load(PLAYER_REFERENCE,['player']);
  const strategy = {place:r.get('playerPlacement'),choose:r.get('playerChoice')};
  const modes = Object.fromEntries(Object.entries(OFFSETS).map(([name,offset])=>{
    const rt = load('worktree',['game']);
    rt.run(`
      Object.assign(PAPER,{place:${offset!==null},all:${offset!==null},extraAP:${offset??0}});
      let auditBoard;
      const auditEnter = enterSupply;
      enterSupply = (s,v) => {auditBoard=s; return auditEnter(s,v);};
    `);
    return [name,rt];
  }));
  const oldModes=Object.fromEntries(Object.entries(OFFSETS).filter(([name])=>name!=='app').map(([name,offset])=>{
    const rt=load(BASE,['game']);
    rt.run(`Object.assign(PAPER,{place:true,all:true,extraAP:${offset}})`);
    return [name,rt];
  }));
  const digest=v=>createHash('sha256').update(JSON.stringify(v)).digest('hex');
  for (const {i,setup} of jobs) {
    const outcomes = {}, baseline = {}, changes = [];
    let opening;
    for (const [name,rt] of Object.entries(modes)) {
      const g=rt.get('playBenchmark');
      outcomes[name]={};
      if(name!=='app')baseline[name]={};
      for(const policy of POLICIES) {
        const v=g({...setup,policy},strategy,true);
        if (opening === undefined) opening=v.openingSupply;
        assert.equal(v.openingSupply,opening);
        outcomes[name][policy] = {win:v.winner===setup.human,winner:v.winner,turns:v.turns,steps:v.steps,margin:v.humanMargin,
          stalled:!!v.stalled,traceHash:digest(v)};
        if(v.stalled) outcomes[name][policy].stateAtCap=rt.run('copy(auditBoard)');
        if(name!=='app') {
          const before=oldModes[name].get('playBenchmark')({...setup,policy},strategy,true);
          assert.equal(before.openingSupply,opening);
          baseline[name][policy]={win:before.winner===setup.human,winner:before.winner,turns:before.turns,
            steps:before.steps,margin:before.humanMargin,stalled:!!before.stalled,traceHash:digest(before)};
          if(digest(before)!==digest(v)) {
            const diff=v.events.findIndex((event,i)=>JSON.stringify(event)!==JSON.stringify(before.events[i]));
            changes.push({name,policy,before:baseline[name][policy],after:outcomes[name][policy],
              firstChangedEvent:{index:diff,before:before.events[diff],after:v.events[diff]}});
          }
        }
      }
    }
    parentPort.postMessage({i,setup,outcomes,baseline,changes});
  }
}
async function main() {
  const repo=path.resolve(process.argv[2]||path.join(root,'../../dominant-species-audit-v051'));
  const threads=Number(process.argv[3]||4);
  const {load,resolveVersion}=require(path.join(repo,'source/benchmark/load.cjs'));
  const all=makeCases([...load('worktree').get('FOOD')]);
  const buckets=Array.from({length:threads},()=>[]);
  all.forEach((setup,i)=>buckets[i%threads].push({setup,i}));
  const rows=new Array(all.length);
  let done=0, games=0, stalls=0, oldGames=0, oldStalls=0;
  const commit=resolveVersion('HEAD');
  const persist=()=>{
    const tmp=path.join(root,'published-results.tmp');
    fs.writeFileSync(tmp,JSON.stringify({commit,seed:SEED,repeats:REPEATS,offsets:OFFSETS,
      profiles:POLICIES,done,games,stalls,oldGames,oldStalls,base:BASE,rows}));
    fs.renameSync(tmp,path.join(root,'published-results.json'));
  };
  await Promise.all(buckets.map(jobs=>new Promise((resolve,reject)=>{
    const w=new Worker(__filename,{workerData:{repo,jobs}});
    w.on('message',v=>{
      rows[v.i]=v;
      for(const outcome of Object.values(v.outcomes).flatMap(Object.values)){games++;stalls+=Number(outcome.stalled);}
      for(const outcome of Object.values(v.baseline).flatMap(Object.values)){oldGames++;oldStalls+=Number(outcome.stalled);}
      if(++done%30===0){persist();console.error(`${done}/${all.length} setups, ${games}+${oldGames} games, ${stalls}/${oldStalls} new/old stalls`);}
    });
    w.once('error',reject);
    w.once('exit',code=>code===0 ? resolve() : reject(Error('Worker died '+code)));
  })));
  assert.equal(done,480);
  const published=JSON.parse(fs.readFileSync(path.join(repo,'source/paper/ladder.json'),'utf8')).rows;
  const table = published.map(row=>{
    const select=rows.filter(r=>r.setup.rivals.length===row.rivals);
    const result={rivals:row.rivals};
    for (const name of Object.keys(OFFSETS)) {
      const games=select.flatMap(r=>Object.values(r.outcomes[name]));
      assert.equal(games.length,360);
      const wins=games.filter(g=>g.win).length, observed=Math.round(100*wins/games.length);
      result[name]={wins,sample:games.length,observed,printed:row[name],stalls:games.filter(g=>g.stalled).length,
        agrees:observed===row[name]};
    }
    return result;
  });
  persist();
  fs.writeFileSync(path.join(root,'published-summary.json'),JSON.stringify({commit,base:BASE,seed:SEED,games,stalls,oldGames,oldStalls,table,changes:rows.flatMap(r=>r.changes.map(change=>({setup:r.setup,...change})))},null,2)+'\n');
  console.log(JSON.stringify({games,stalls,table},null,2));
}
if(isMainThread)main().catch(e=>{console.error(e);process.exitCode=1;});
else worker();
