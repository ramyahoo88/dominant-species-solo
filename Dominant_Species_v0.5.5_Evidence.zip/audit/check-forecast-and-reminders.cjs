const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const repo = path.resolve(process.argv[2]);
const output = path.resolve(process.argv[3]);
const {load} = require(path.join(repo, 'source/benchmark/load.cjs'));

function review() {
  const points = s => Object.fromEntries(s.ids.map(id => [id, s.animals[id].vp]));
  const envelope = s => ({format: 'dominant-species-solo-v1', game: s});
  function finish(source, forcedSave) {
    const t = copy(source);
    let step = nextStep(t);
    if (step.kind === 'claim') runStep(t, step, {card: 'Ice Age'});
    step = nextStep(t);
    assert.equal(step.name, 'Ice Age');
    runStep(t, step, botAction(t, step));
    for (let i = 0; t.phase !== 'finished' && i < 200; i++) {
      step = nextStep(t);
      const choice = step.kind === 'extinction' && forcedSave !== undefined
        ? {saved: forcedSave} : botAction(t, step);
      if (step.kind === 'extinction' && choice.saved) {
        assert.ok(extinctionOptions(t, 'mammals').includes(choice.saved));
      }
      runStep(t, step, choice);
      validateState(t);
    }
    assert.equal(t.phase, 'finished');
    return {vp: points(t), winner: standings(t)[0],
      extinction: t.log.findLast(entry => entry.title === 'Extinction and Survival').body};
  }

  function startClaim(s, tile) {
    s.phase = 'execution';
    s.turn = 9;
    s.cursor = EXECUTION.length;
    s.market = ['Ice Age', 'Fertile', null, null, null];
    s.usedCards = DOMINANCE.filter(card => !s.market.includes(card));
    s.scored = [tile];
    s.pending = [{kind: 'claim', actor: 'birds', tile, focus: null}];
    assert.equal(cone(s, tile), 'birds');
    validateState(s);
    return s;
  }

  function blank(human, rivals, seed, paper = null) {
    const s = newGame(human, rivals, false, seed, paper);
    for (const id of s.ids) {
      for (const tile of occupied(s, id)) removeCube(s, tile, id, s.tiles[tile].cubes[id], 'pool');
    }
    s.corners = {};
    return s;
  }

  function plan(s, actor, card) {
    s.phase = 'planning';
    s.initiative = [actor, ...s.initiative.filter(id => id !== actor)];
    s.paper.pre = s.initiative.filter(id => s.rivals.includes(id));
    for (const id of s.ids) s.animals[id].remaining = s.animals[id].ap;
    s.decks[actor].queue = [card, ...s.decks[actor].queue.filter(id => id !== card)];
    validateState(s);
    const t = copy(s);
    assert.equal(currentPlanner(t).actor, actor);
    const placement = botPlacement(t);
    assert.equal(placement.card, card);
    validateState(t);
    return placement;
  }

  const baseline = validateState(copy(fixture));
  const baselineBefore = JSON.stringify(baseline);
  const forecast = finalProjection(baseline);
  const actual = finish(baseline);
  assert.deepEqual(forecast, {mammals: 18, birds: 16, insects: 0});
  assert.deepEqual(forecast, actual.vp);
  assert.equal(botAction(baseline, nextStep(baseline)).card, 'Fertile');
  PAPER.oldForecast = true;
  const legacy = Object.fromEntries(baseline.ids.map(id => [id, endEstimate(baseline, id)]));
  assert.deepEqual(legacy, {mammals: 12, birds: 16, insects: 0});
  assert.equal(botAction(baseline, nextStep(baseline)).card, 'Ice Age');
  delete PAPER.oldForecast;
  assert.equal(JSON.stringify(baseline), baselineBefore);

  const ward = copy(baseline);
  ward.animals.mammals.ward.D3 = 1;
  const shared = copy(baseline);
  addCube(shared, 'D3', 'birds', 1);
  for (const example of [ward, shared]) {
    validateState(example);
    assert.deepEqual(finalProjection(example), finish(example).vp);
  }

  const human = blank('mammals', ['birds', 'insects'], 551114);
  human.animals.mammals.vp = 10;
  human.animals.birds.vp = 11;
  human.corners[VERTICES_OF.E3.find(key => !VERTICES_OF.D2.includes(key))] = 'seed';
  addCube(human, 'D2', 'mammals', 1);
  addCube(human, 'E3', 'mammals', 1);
  addCube(human, 'E3', 'birds', 1);
  startClaim(human, 'E3');
  const humanOptions = Object.fromEntries(extinctionOptions(human, 'mammals').map(tile => [tile, finish(human, tile)]));
  const humanProjection = finalProjection(human);
  assert.equal(humanOptions.D2.winner, 'birds');
  assert.equal(humanOptions.E3.winner, 'mammals');
  assert.deepEqual(humanProjection, humanOptions.D2.vp);
  assert.equal(botAction(human, nextStep(human)).card, 'Ice Age');

  const tied = copy(baseline);
  tied.animals.birds.vp += 2;
  validateState(tied);
  const tieForecast = finalProjection(tied);
  const tieActual = finish(tied);
  assert.equal(tieForecast.birds, tieForecast.mammals);
  assert.deepEqual(tieForecast, tieActual.vp);
  assert.equal(tieActual.winner, 'mammals');
  assert.equal(botAction(tied, nextStep(tied)).card, 'Ice Age');

  const migration = blank('birds', ['mammals', 'insects'], 551115, {extra: 1});
  addCube(migration, 'C4', 'mammals', 2);
  addCube(migration, 'C4', 'birds', 2);
  migration.corners[VERTICES_OF.C4.find(key => VERTICES_OF.D4.includes(key))] = 'meat';
  validateState(migration);
  assert.ok(legalNeighbors(migration, 'C4', 'mammals').includes('D4'));
  assert.equal(migration.tiles.D4.cubes.mammals, 0);
  assert.ok(match(migration, 'C4', 'mammals') && match(migration, 'D4', 'mammals'));
  assert.ok(pLosesRank(migration, 'C4', 'mammals'));
  assert.equal(paperLegal(migration, 'mammals', 'migration', 0), false);
  const migrationChoice = plan(migration, 'mammals', 0);
  assert.equal(migrationChoice.slot, 'speciation-0');

  const abundance = blank('birds', ['reptiles', 'insects'], 551116, {extra: 1});
  abundance.turn = 2;
  addCube(abundance, 'C3', 'birds', 1);
  abundance.corners[VERTICES_OF.C3[0]] = 'seed';
  abundance.boxes.abundance = ['sun', 'water'];
  validateState(abundance);
  assert.equal(paperBarren(abundance), false);
  assert.equal(paperEmptyEarth(abundance), true);
  assert.equal(paperLegal(abundance, 'reptiles', 'abundance', 0), true);
  const abundanceChoice = plan(abundance, 'reptiles', 4);
  assert.equal(abundanceChoice.slot, 'abundance-0');
  assert.match(abundanceChoice.reason, /Card action 1/);

  const catastrophe = validateState(copy(catFixture));
  const catStep = nextStep(catastrophe);
  const catChoice = botAction(catastrophe, catStep);
  assert.equal(catChoice.tile, 'E3');
  runStep(catastrophe, catStep, catChoice);
  validateState(catastrophe);
  const hibernation = validateState(copy(hibFixture));
  const hibStep = nextStep(hibernation);
  const hibChoice = botAction(hibernation, hibStep);
  assert.deepEqual([hibChoice.tile, hibChoice.n], ['D3', 5]);
  runStep(hibernation, hibStep, hibChoice);
  validateState(hibernation);
  assert.equal(hibernation.animals.birds.ward.D3, 5);

  // Variation is intentional and conservation-checked. These are generated
  // last-action snapshots, not a sample of games played from setup.
  let seed = 1265555;
  const pick = n => {
    seed = (Math.imul(seed, 1664525) + 1013904223) >>> 0;
    return Math.floor(seed / 2 ** 32 * n);
  };
  const generated = [];
  for (const mode of ['tooth', 'queen']) {
    for (const mammals of ['absent', 'rival', 'human']) {
      const totals = {mode, mammals, positions: 0, withEndangeredMammals: 0, withMultipleSaves: 0,
        withHibernationProtection: 0, actualResolutions: 0, winningSaveMissed: 0};
      for (let i = 0; i < 120; i++) {
        const others = shuffle({rng: seed}, FOOD.filter(id => id !== 'mammals'));
        const humanId = mammals === 'human' ? 'mammals' : others.shift();
        const rivalIds = [...(mammals === 'rival' ? ['mammals'] : []), ...others].slice(0, 2 + pick(3 + Number(mammals !== 'absent')));
        const s = blank(humanId, rivalIds, seed, mode === 'queen' ? {extra: 1} : null);
        s.phase = 'execution';
        s.turn = 12;
        s.cursor = EXECUTION.length;
        s.usedCards = [...DOMINANCE];
        const actor = s.rivals[0];
        s.pending = [{kind: 'effect', actor, tile: 'D3', name: 'Ice Age', focus: null}];
        for (const t of terrainIds(s)) {
          if (pick(5) === 0) s.tiles[t].terrain = 'tundra';
          for (const id of s.ids) {
            const cubes = pick(5);
            addCube(s, t, id, cubes);
            if (cubes && pick(5) === 0) s.animals[id].ward[t] = 1 + pick(cubes);
          }
        }
        for (const id of s.ids) s.animals[id].vp = pick(30);
        for (const key of activeCorners(s)) {
          const type = ELEMENT_IDS[pick(ELEMENT_IDS.length)];
          if (!pick(4) && bagCount(s, type)) s.corners[key] = type;
        }
        validateState(s);
        totals.positions++;
        totals.withHibernationProtection += Number(s.ids.some(id => Object.keys(s.animals[id].ward).length));
        const saves = mammals === 'absent' ? [] : extinctionOptions(s, 'mammals');
        totals.withEndangeredMammals += Number(saves.length > 0);
        totals.withMultipleSaves += Number(saves.length > 1);
        const before = JSON.stringify(s);
        const prediction = finalProjection(s);
        assert.deepEqual(finalProjection(s), prediction);
        if (mammals === 'human' && saves.length) {
          const possible = saves.map(tile => finish(s, tile));
          totals.actualResolutions += possible.length;
          assert.equal(prediction.mammals, Math.max(...possible.map(result => result.vp.mammals)));
          const selected = possible.find(result => JSON.stringify(result.vp) === JSON.stringify(prediction));
          assert.ok(selected);
          if (selected.winner !== 'mammals' && possible.some(result => result.winner === 'mammals')) totals.winningSaveMissed++;
        } else {
          assert.deepEqual(prediction, finish(s).vp);
          totals.actualResolutions++;
        }
        assert.equal(JSON.stringify(s), before);
      }
      generated.push(totals);
    }
  }
  return {
    original: {forecast, actual, legacy, currentChoice: botAction(baseline, nextStep(baseline)).card,
      protected: finish(ward), shared: finish(shared)},
    humanSave: {choices: humanOptions, forecast: humanProjection, card: botAction(human, nextStep(human)).card,
      iceAgeValue: cardValue(human, 'birds', 'Ice Age', 'E3'), fertileValue: cardValue(human, 'birds', 'Fertile', 'E3')},
    tie: {forecast: tieForecast, actual: tieActual, card: botAction(tied, nextStep(tied)).card,
      iceAgeValue: cardValue(tied, 'birds', 'Ice Age', 'C3'), fertileValue: cardValue(tied, 'birds', 'Fertile', 'C3')},
    reminders: {migration: migrationChoice, abundance: abundanceChoice},
    printFixes: {catastrophe: catChoice, hibernation: hibChoice, hibernationProtected: hibernation.animals.birds.ward.D3},
    generated,
    saves: {'human-mammals-can-win': envelope(human), 'birds-losing-tie': envelope(tied),
      'migration-loses-rank': envelope(migration), 'abundance-empty-earth': envelope(abundance)},
  };
}

const runtime = load('worktree', ['game']);
const getFixture = name => {
  const saved = JSON.parse(fs.readFileSync(path.join(repo, 'source/fixtures', name)));
  return saved.game ?? saved;
};
Object.assign(runtime.get('globalThis'), {
  assert,
  fixture: getFixture('gpt-v054c-ice-age-wrong-mammal-save.json'),
  catFixture: getFixture('gpt-v054c-catastrophe-empty-center.json'),
  hibFixture: getFixture('gpt-v054c-hibernation-quantity.json'),
});
const result = runtime.run('(' + review.toString() + ')()');
fs.mkdirSync(output, {recursive: true});
for (const [label, state] of Object.entries(result.saves)) {
  fs.writeFileSync(path.join(output, label + '.json'), JSON.stringify(state, null, 2) + '\n');
}
delete result.saves;
console.log(JSON.stringify(result, null, 2));
