"use strict";

// Usage: node verify-aquatic.cjs REPO FIXTURE_DIR
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');

const repo = path.resolve(process.argv[2]);
const fixtures = path.resolve(process.argv[3]);
const {load} = require(path.join(repo, 'source/benchmark/load.cjs'));
const refs = ['ffa795b14d3618864345c520549d1120c7d3987b', '6a9e7fba95c113d2017b45bbf494de985f26bac8'];

const expected = [
  {seed: 731260, app: 'B5', paper: 'A2'},
  {seed: 731290, app: 'D5', paper: 'C1'},
];
const results = [];
for (const ref of refs) {
  const runtime = load(ref);
  for (const entry of expected) {
    const {seed, app, paper} = entry;
    const fixture = JSON.parse(fs.readFileSync(path.join(fixtures, `aquatic-seed-${seed}.json`), 'utf8'));
    runtime.get('globalThis').fixture = fixture;
    const observation = runtime.run(`(() => {
      const s = fixture.game;
      s.version = VERSION;
      validateState(s);
      const step = nextStep(s);
      const actor = step.actor;
      if (step.name !== 'Aquatic' || s.animals[actor].pool !== 0) throw new Error('Unexpected saved decision');
      const decision = botAction(s, step);
      const cornerOrder = (a,b) => {
        const [ax,ay] = a.split(',').map(Number), [bx,by] = b.split(',').map(Number);
        return ax - bx || ay - by;
      };
      const candidates = Object.entries(s.tiles).filter(([,t]) => ['sea','wetland'].includes(t.terrain))
        .map(([tile,t]) => ({tile, terrain:t.terrain, cubes:t.cubes[actor],
          value:t.terrain === 'sea' ? 9 : 8,
          corner:VERTICES_OF[tile].filter(k => !s.corners[k]).sort(cornerOrder)[0] || null}));
      if (!elementOptions(s).includes('water') || actor !== 'amphibians') throw new Error('Expected Water to be available');
      // Putting Water on any of these open corners makes the candidate match. Zero species means no rank improvement.
      const printed = candidates.filter(c => c.corner).sort((a,b) => b.value - a.value || a.tile.localeCompare(b.tile))[0];
      const before = Object.fromEntries(terrainIds(s).map(t => [t,cone(s,t)]));
      const applied = choice => {
        const t = copy(s);
        runStep(t,nextStep(t),choice);
        validateState(t);
        return {tile:choice.tile,corner:choice.corner,disk:t.corners[choice.corner],n:choice.n,
          changedCones:terrainIds(t).filter(id => cone(t,id) !== before[id]),
          cubePositionsUnchanged:JSON.stringify(t.tiles) === JSON.stringify(s.tiles)};
      };
      return {version:VERSION,turn:s.turn,actor,rivals:s.rivals.length,level:s.paper.level,candidates,
        app:applied(decision),paper:applied({...decision,tile:printed.tile,corner:printed.corner})};
    })()`);
    assert.equal(observation.app.tile, app);
    assert.equal(observation.paper.tile, paper);
    assert.equal(observation.app.n, 0);
    assert.equal(observation.paper.n, 0);
    assert(observation.app.cubePositionsUnchanged && observation.paper.cubePositionsUnchanged);
    results.push({ref, seed, ...observation});
  }
}
console.log(JSON.stringify(results, null, 2));
