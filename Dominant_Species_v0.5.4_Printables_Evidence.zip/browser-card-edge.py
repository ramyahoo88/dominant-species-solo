import json
from pathlib import Path
from playwright.sync_api import sync_playwright
ROOT=Path(__file__).resolve().parent
REPO=ROOT.parent/'dominant-species-solo'
KEY='dominant-species-solo-v1'
with sync_playwright() as pw:
 b=pw.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox'])
 ctx=b.new_context(viewport={'width':390,'height':850},offline=True)
 p=ctx.new_page();errors=[];network=[]
 p.on('pageerror',lambda e:errors.append(str(e)))
 p.on('request',lambda r:network.append(r.url) if r.url.startswith(('http:','https:')) else None)
 p.goto((REPO/'Dominant_Species_Solo.html').as_uri())
 p.locator('#import-file').set_input_files(ROOT/'saves/aquatic.json')
 p.wait_for_function('(k)=>JSON.parse(localStorage.getItem(k))?.game?.seed===11505401',arg=KEY)
 get=lambda:p.evaluate('(k)=>JSON.parse(localStorage.getItem(k)).game',KEY)
 before=get();assert before['animals']['birds']['pool']==1
 p.get_by_role('button',name='Show Birds move',exact=True).click()
 preview=p.locator('.result-box').first.inner_text();assert 'Aquatic at D2 Wetland' in preview and 'Add 1 cube' in preview
 assert get()==before
 p.get_by_role('button',name='Applied · Continue',exact=True).click();after=get()
 assert after['tiles']['D2']['cubes']['birds']==2 and after['animals']['birds']['pool']==0
 p.get_by_role('button',name='Undo',exact=True).click();assert get()==before
 assert not errors and not network
 out={'browser':b.version,'preview':preview,'pool':1,'actualTarget':'D2','fourSpeciesLiteralTarget':'E2','applyUndo':True,'errors':errors,'network':network}
 b.close()
(ROOT/'browser-card-edge.json').write_text(json.dumps(out,indent=2)+'\n')
print('PASS: Aquatic small-pool choice in shipped HTML; import, preview, apply, undo; zero errors or network requests')
