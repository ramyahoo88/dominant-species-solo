const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
const repo=path.resolve(process.argv[2]||'../dominant-species-solo');
const r=require(path.join(repo,'source/benchmark/load.cjs')).load('worktree');r.get('globalThis').assert=assert;
const out=r.run(`(()=>{
 const s=newGame('birds',['mammals','insects','reptiles'],false,11505402,{extra:0});
 for(const t of terrainIds(s))for(const a of s.ids)removeCube(s,t,a,s.tiles[t].cubes[a],'pool');
 const tile='E3',vp=pFirstVP(s,tile),out=[];
 function check(label,cubes,expected){
  for(const a of s.ids)removeCube(s,tile,a,s.tiles[tile].cubes[a],'pool');
  for(const [a,n]of Object.entries(cubes))addCube(s,tile,a,n);
  validateState(s);const before=cone(s,tile),score=paperHitScore(s,tile,'mammals','insects');
  s.tiles[tile].cubes.mammals--;const after=cone(s,tile);s.tiles[tile].cubes.mammals++;
  assert.equal(score,expected);out.push({label,before,after,cubes,score,expected});
 }
 check('dominant last species',{mammals:1,insects:1},2.5*vp+6);
 check('non-dominant last species',{mammals:1,insects:2},1.5*vp);
 check('dominance lost but victim still present',{mammals:2,insects:1,reptiles:2},vp);
 return out;
})()`);fs.writeFileSync(path.join(__dirname,'competition-check.json'),JSON.stringify(out,null,2)+'\n');console.log(JSON.stringify(out,null,2));
