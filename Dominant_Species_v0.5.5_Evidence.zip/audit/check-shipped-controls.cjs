// Exercise the exact script shipped in the HTML under a minimal DOM shim.
// This checks generated markup and JS handlers, not Chromium rendering.
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const repo = path.resolve(process.argv[2]);
const saves = path.resolve(process.argv[3]);
const html = fs.readFileSync(path.join(repo, 'Dominant_Species_Solo.html'), 'utf8');
const source = html.match(/<script>([\s\S]*?)<\/script>/)[1];
const storageKey = 'dominant-species-solo-v1';

function fixture(name) {
  const data = JSON.parse(fs.readFileSync(path.join(repo, 'source/fixtures', name + '.json')));
  return data.game ? data : {format: storageKey, game: data};
}

function start(saved) {
  const nodes = new Map();
  const docListeners = new Map();
  const storage = new Map(saved ? [[storageKey, JSON.stringify(saved)]] : []);
  function element(id) {
    if (!nodes.has(id)) {
      nodes.set(id, {
        listeners: new Map(), innerHTML: '', textContent: '', querySelectorAll: () => [], querySelector: () => null,
        addEventListener(name, fn) { this.listeners.set(name, fn); },
        focus() {}, showModal() { this.open = true; }, close() { this.open = false; },
      });
    }
    return nodes.get(id);
  }
  const document = {
    getElementById: element,
    addEventListener(name, fn) { docListeners.set(name, fn); },
  };
  const localStorage = {
    getItem: k => storage.get(k) ?? null,
    setItem: (k, v) => storage.set(k, v),
    removeItem: k => storage.delete(k),
  };
  const context = vm.createContext({document, localStorage});
  vm.runInContext(source, context, {filename: 'Dominant_Species_Solo.html'});
  assert.equal(element('version').textContent, 'v0.5.5');
  return {
    text: () => element('main').innerHTML,
    modal: () => element('modal').innerHTML,
    state: () => JSON.parse(storage.get(storageKey)),
    click: action => docListeners.get('click')({target: {closest: () => ({dataset: {do: action}})}}),
  };
}

const setup = start();
assert.match(setup.text(), /Tooth &amp; Claw · app rivals/);
assert.match(setup.text(), /The Red Queen · printed rivals/);
setup.click('help');
assert.match(setup.modal(), /Tooth &amp; Claw/);
assert.match(setup.modal(), /The Red Queen/);

const forecast = start(fixture('gpt-v054c-ice-age-wrong-mammal-save'));
assert.match(forecast.text(), /Tooth &amp; Claw/);
forecast.click('preview');
assert.match(forecast.text(), /Take Fertile\./);
forecast.click('apply');
assert.equal(forecast.state().game.pending[0].name, 'Fertile');

const oldEasy = start(fixture('gpt-v053-legacy-v052-five-easy'));
const scaledEasy = start(fixture('gpt-v053-new-five-easy'));
for (const ui of [oldEasy, scaledEasy]) {
  assert.match(ui.text(), /The Red Queen, Easy/);
  assert.equal(ui.state().game.version, '0.5.5');
}
assert.match(oldEasy.text(), /returns 2 action pawns/);
assert.match(scaledEasy.text(), /returns 1 action pawn and you take 1 extra/);
assert.equal(oldEasy.state().game.paper.speciesTie, undefined);

for (const [name, label] of [
  ['migration-loses-rank', 'Red Queen, Card action 2: Speciation.'],
  ['abundance-empty-earth', 'Red Queen, Card action 1: Abundance.'],
]) {
  const ui = start(JSON.parse(fs.readFileSync(path.join(saves, name + '.json'))));
  ui.click('draw');
  assert.ok(ui.text().includes(label), label);
  ui.click('next');
  assert.ok(ui.state().game.log.at(-1).body.includes(label));
}

console.log('PASS exact shipped script in Node: setup and Help names, Fertile preview/apply, legacy and scaled Easy, and both Red Queen card reveals.');
