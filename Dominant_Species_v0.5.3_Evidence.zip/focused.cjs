const fs = require('node:fs');
const path = require('node:path');
const assert = require('node:assert/strict');
const repo = path.resolve(process.argv[2] || '../dominant-species-solo');
const {load} = require(path.join(repo,'source/benchmark/load.cjs'));
const rt = load('worktree',['game']);
const old = load('db81d8d',['game']);
Object.assign(rt.get('globalThis'), {assert});
const facts = rt.run(`(() => {
  const matrix=[];
  for (const human of FOOD) for (const n of [2,3,4,5]) for (const extra of [-2,-1,0,1]) {
    const rivals=FOOD.filter(x=>x!==human).slice(0,n);
    const s=newGame(human,rivals,false,1053000+n,{extra});
    const base=SETUP_BY_PLAYERS[n+1][0], scaled=n===5 && extra===-2;
    assert.equal(s.animals[human].ap,base+Number(scaled));
    assert(rivals.every(id=>s.animals[id].ap===base+(scaled?-1:extra)));
    assert.equal(!!s.paper.scaledEasy,scaled);
    validateState(s);
    const saved=copy(s); validateState(saved); assert.deepEqual(saved,s);
    const supplies=makeSupplies(saved,saved.seed);
    enterSupply(saved,nextSupply(saved,supplies,saved.seed));
    assert(saved.ids.every(id=>saved.animals[id].remaining===saved.animals[id].ap));
    validateState(saved);
    matrix.push({human,n,extra,player:s.animals[human].ap,rivals:rivals.map(id=>s.animals[id].ap)});
  }
  return {matrix};
})()`);
facts.originalSaves=[];
for (const [filename,expected] of [['mammals-extinction-played','B2'],['mammals-extinction-tie','C3']]) {
  const archive=path.join(__dirname,'original-saves',filename+'.json');
  const original=JSON.parse(fs.readFileSync(archive)).game;
  rt.get('globalThis').original=original;
  rt.get('globalThis').expected=expected;
  facts.originalSaves.push(rt.run(`(() => {
    const s=copy(original); validateState(s); const before=copy(s);
    const step=nextStep(s); const choice=botAction(s,step);
    assert.equal(choice.saved,expected); assert.deepEqual(s,before,'Preview does not mutate state');
    runStep(s,step,choice); validateState(s);
    const app=copy(original); delete app.paper;delete app.paperRivals;validateState(app);
    const appChoice=botAction(app,nextStep(app));
    return {seed:s.seed,turn:before.turn,chosen:choice.saved,appChoice:appChoice.saved,
      survivalChange:s.animals.mammals.vp-before.animals.mammals.vp,
      mammalCubes:Object.fromEntries(Object.entries(s.tiles).filter(([,v])=>v.cubes.mammals).map(([k,v])=>[k,v.cubes.mammals]))};
  })()`));
}
const legacy=old.run(`newGame('amphibians',FOOD.filter(a=>a!=='amphibians'),false,1053007,{extra:-2})`);
fs.writeFileSync(path.join(__dirname,'saves/legacy-v052-five-easy.json'),JSON.stringify({format:'dominant-species-solo-v1',game:legacy}));
rt.get('globalThis').legacy=JSON.parse(JSON.stringify(legacy));
facts.legacy=rt.run(`(() => {
  validateState(legacy);
  assert.equal(legacy.animals[legacy.human].ap,3);
  assert(legacy.rivals.every(id=>legacy.animals[id].ap===1));
  assert(!legacy.paper.scaledEasy);
  const supplies=makeSupplies(legacy,legacy.seed);
  enterSupply(legacy,nextSupply(legacy,supplies,legacy.seed));
  validateState(legacy);
  assert.equal(legacy.animals[legacy.human].remaining,3);
  assert(legacy.rivals.every(id=>legacy.animals[id].remaining===1));
  return {player:3,rivals:1,preservedAfterPlanning:true};
})()`);
fs.writeFileSync(path.join(__dirname,'focused-results.json'),JSON.stringify(facts,null,2)+'\n');
console.log(JSON.stringify({matrixCases:facts.matrix.length,originalSaves:facts.originalSaves,legacy:facts.legacy},null,2));
