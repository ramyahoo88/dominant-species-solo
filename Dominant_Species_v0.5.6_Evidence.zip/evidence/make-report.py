from pathlib import Path
from xml.sax.saxutils import escape
import hashlib
import json
import zipfile

from reportlab.lib import colors
from reportlab.lib.enums import TA_LEFT
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.utils import ImageReader
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, PageBreak

root = Path(__file__).resolve().parents[1]
repo = root.parent / 'dominant-species-v056'
out = root / 'output'
out.mkdir(exist_ok=True)
pdf = out / 'Dominant_Species_v0.5.6_Reaudit.pdf'
fonts = Path('/usr/share/fonts/truetype/dejavu')
pdfmetrics.registerFont(TTFont('Audit', str(fonts / 'DejaVuSans.ttf')))
pdfmetrics.registerFont(TTFont('AuditBold', str(fonts / 'DejaVuSans-Bold.ttf')))
pdfmetrics.registerFontFamily('Audit', normal='Audit', bold='AuditBold', italic='Audit', boldItalic='AuditBold')
green = colors.HexColor('#254c3f')
ink = colors.HexColor('#23312d')
style = ParagraphStyle('body', fontName='Audit', fontSize=9, leading=13.5, textColor=ink, spaceAfter=7)
small = ParagraphStyle('small', parent=style, fontSize=7.7, leading=11)
title = ParagraphStyle('title', parent=style, fontName='AuditBold', fontSize=21, leading=26, textColor=green, spaceAfter=13)
sub = ParagraphStyle('sub', parent=style, fontName='AuditBold', fontSize=13, leading=18, textColor=green, spaceAfter=10)
table_style = ParagraphStyle('table', parent=style, fontSize=8.1, leading=11.6, spaceAfter=0)
story = []

def p(text, fmt=style):
    story.append(Paragraph(text, fmt))

def table(headers, rows, widths):
    data = [[Paragraph('<b>' + escape(x) + '</b>', table_style) for x in headers]]
    data += [[Paragraph(escape(str(x)), table_style) for x in row] for row in rows]
    t = Table(data, colWidths=widths, repeatRows=1, hAlign='LEFT')
    t.setStyle(TableStyle([
        ('BACKGROUND', (0,0), (-1,0), colors.HexColor('#e6eee8')),
        ('GRID', (0,0), (-1,-1), .4, colors.HexColor('#b9c9bf')),
        ('VALIGN', (0,0), (-1,-1), 'TOP'),
        ('LEFTPADDING', (0,0), (-1,-1), 7), ('RIGHTPADDING', (0,0), (-1,-1), 7),
        ('TOPPADDING', (0,0), (-1,-1), 6), ('BOTTOMPADDING', (0,0), (-1,-1), 6),
    ]))
    story.extend([t, Spacer(1,10)])

def footer(c, doc):
    c.setStrokeColor(colors.HexColor('#b9c9bf'))
    c.line(42, 37, 570, 37)
    c.setFillColor(green)
    c.setFont('Audit', 7.4)
    c.drawString(42, 24, 'Dominant Species Solo v0.5.6 | 95c67db | 15 November 2026')
    c.drawRightString(570, 24, str(doc.page))

p('Dominant Species Solo<br/>v0.5.6 re-audit', title)
p('<b>Forecast fixes and cards-only deck/save logic pass the checks performed. Two release issues remain.</b> '
  'The distributed PDFs contain earlier text, and the global reference controls show the wrong guidance during cards-only play. '
  'Real-browser phone testing could not be completed in this environment.')
p('Audited commit <b>95c67db8385929c0b22b551d129b137c0248b1c9</b>, fetched from main. '
  'The 570,895-byte standalone HTML rebuild is byte-identical to the release.', small)
p('SHA-256<br/>bd7afbb90abc3f1727baacb3d7fa6e170ad3db37ce801eb058ad00fd42218530', small)

p('<b>P1 - Medium. The three distributed PDFs lag behind their current sources.</b> '
  'The rulebook and aid PDFs say v0.5.6 but omit the newly agreed added-element ordering, Competition half-points, '
  'Migration timing, Speciation and Block the leader clarifications. The app’s embedded documents and generated HTML contain those updates. '
  'The card PDF and the rulebook’s card appendix also use earlier Migration and Abundance reminders.')
p('The unmodified verifier stops at “standalone Mammals front 1: text missing or changed.” '
  'This is a real publication mismatch. Regenerate all three PDFs from the committed sources, then require '
  '<b>verify-printables.py</b> and <b>check_print_fit.py</b> to pass against the files that will be released.')

p('<b>C1 - Medium. Global reference controls ignore cards-only mode.</b> '
  'Start The Red Queen · cards only, then open the header’s <b>Bot decks</b>. The dialog presents Tooth &amp; Claw’s '
  'condition checks and Yes/No branches. Mammals’ Food Chain Advantage can show the Yes sequence '
  'Speciation → Competition → Domination, while its Red Queen sequence is Migration → Speciation → Abundance. '
  'A player using that dialog as a reference can operate the wrong rival rules.')
p('The header’s <b>How to play</b> also starts with full-board entry and confirmation instructions. '
  'Make both controls follow the selected mode. For Red Queen, reuse the same card rendering and built-in rules used on its main screen. '
  'The dedicated <b>Rules</b> and <b>Player aids</b> buttons already supply the correct updated documents. '
  'Relevant code is source/src/controls.js, lines 192 and 204, with the header controls in source/src/index.html.')

table(['Earlier finding', 'v0.5.6 result'], [
    ['F1, human Mammals', 'Pass. Forecast 17–16 for Mammals, and Birds choose Fertile. Actual final scoring with the Savannah save matches.'],
    ['F2, losing tie', 'Pass. Forecast 18–18, Mammals win by food chain, and Birds choose Fertile. The one-VP Birds lead variant chooses Ice Age.'],
    ['P3, card reminders', 'Updated in source, HTML and app. PDF wording differs. See P1.'],
], [136,392])

story.append(PageBreak())
p('Cards-only mode and built-in rules', sub)
p('The exact JavaScript from the shipped HTML was exercised under a minimal DOM shim. '
  'This covers the handlers and markup used by the normal controls. It provides no browser layout or iframe-rendering guarantee.')
table(['Coverage', 'Observed result'], [
    ['624 configurations', 'All six human animals, every combination of two to five rivals, and all four difficulty levels. Pawn/cube reminders agree with setup counts, including five-rival Easy.'],
    ['43,200 interleaved draws', 'Every eight-card cycle contains each card exactly once. The ninth draw reshuffles. Drawing one rival leaves every other deck unchanged.'],
    ['5,400 saved-state replays', 'Restoring before a cycle boundary reproduces the same draw, deck order and random state.'],
    ['Normal controls', 'Setup, draw, Undo, redraw, reload, JSON export/import and new-game settings passed. Invalid imports preserve the active save. Full and cards-only formats route to the correct mode.'],
    ['Long sessions', 'The 200-entry history cap and 60-entry Undo cap preserve deck state. Undoing and replaying the last 60 draws reproduces the same save.'],
    ['All 48 card faces', 'Names, numbers, animal identity, food-chain position, three actions, target reminders, weak-action styling and legend match generated printable HTML.'],
    ['Rules and ten aids', 'Embedded text matches the generated HTML. All source outputs, including rq_embed.js, rebuild byte-for-byte. Both document buttons assign the expected sandboxed frame content.'],
], [136,392])
p('The in-app rules contain the new acquisition-order procedure, exact Competition halves, per-space Speciation wording, '
  'per-move Migration check and explanation of Block the leader. The two Abundance exceptions remain on aid 1, which the new card reminder references. '
  'Deck drawing during Planning and the instruction to draw no new card for Initiative or Instinct agree with the Red Queen rules.')

p('<b>Forecast coverage.</b> The earlier independent scoring harness was updated to judge the human Mammals save by final place, '
  'then lead over the best opponent, then Mammals VP. It checked 720 constructed endgame positions and 1,396 actual endgame resolutions. '
  'The sample covers both rival systems, Mammals absent/as rival/as human, Hibernation protection, tundra and 358 positions with multiple legal Mammals saves.')
p('Every projection matched the applicable real scoring outcome or a best human save under the stated ordering. '
  'No winning Mammals save was missed, and forecasts left the input state untouched. Ice Age values were positive only for the projected winner. '
  'The v055Forecast switch reproduced v0.5.5 projections across all 720 positions. These are targeted scoring positions, not difficulty estimates.')

story.append(PageBreak())
p('Publication evidence and verification limits', sub)
table(['Document', 'Mismatch in the shipped PDF'], [
    ['Rulebook', 'Missing the added-element ordering paragraph and the new Block the leader, Speciation, Migration and Competition wording.'],
    ['Player aids', 'Changed text is missing on sheets 1, 2, 4 and 9. In particular, sheet 4 still lacks the added-element ordering procedure.'],
    ['Cards and rulebook appendix', 'Each contains 30 Migration reminders saying “a spare species (no rank lost)” instead of “1 of 2+ species (no rank lost)”, plus two Abundance reminders saying “Empty Earth: any” instead of “exceptions: aid 1”.'],
], [136,392])
p('All 96 front instances and 96 back instances were checked across the standalone cards and rulebook appendix. '
  'After explicitly accounting for the two recorded card-text differences, card identities, actions, weak markers, back powers and cut rectangles passed. '
  'Digital long-edge duplex alignment had zero measured point offset. The rulebook remains 20 pages, with 8 rules pages and 12 card pages, '
  'and the aids contain 10 pages. PDF renders of the affected pages confirm that the missing clarification text was never included.')
p('The evidence script records prose failures and continues other checks. Its temporary expectations for the earlier PDF card wording are disclosed in '
  'printable-review.json. They do not change the release verdict. The original verifier failure is preserved in logs/printables.log.')

table(['Check', 'Result'], [
    ['Standalone build', 'Exact SHA-256 match to the shipped release.'],
    ['Repository rules suite', '58 passed, zero failed.'],
    ['Smoke baseline', '60-game results match the unchanged baseline.'],
    ['Benchmark self-test', '24 games, no reported errors.'],
    ['Printable source generation', 'Rulebook Markdown, three HTML files and rq_embed.js match on rebuild.'],
    ['Shipped PDF fidelity', 'Fails. Regeneration is needed.'],
    ['Browser and print-layout suite', 'Could not run successfully in this environment.'],
], [180,348])
p('Playwright’s expected browser executable is absent. The installed Chromium fails to start because the environment denies its required socket. '
  'The cloud-browser fallback rejects local-file URLs. Phone layout, real iframe scrolling, browser download behavior and the browser-based print-fit '
  'check remain unverified here. No fresh difficulty comparison was run, following the stated decision to skip remeasurement.')
p('The evidence archive contains the runnable checks, four earlier reproduction saves, detailed results and exact failure logs. '
  'README.md gives commands to repeat the audit at the pinned commit. The inspected release checkout has no source edits.', small)

SimpleDocTemplate(str(pdf), pagesize=(612,792), rightMargin=42, leftMargin=42,
                  topMargin=42, bottomMargin=49, title='Dominant Species Solo v0.5.6 re-audit',
                  author='Codex').build(story, onFirstPage=footer, onLaterPages=footer)
print(pdf)
