# Dominant Species Solo v0.5.1 re-audit evidence

Reviewed release `dec3a3bec5ed3fbe0ede969c00d1a8b51ac4f596`, private repository `ramyahoo88/dominant-species-solo`. The release sources were unchanged. Root shipment and two independent output paths contain the same 466,737 bytes, SHA-256 `c90c42b66127d25f39cdedee493e1321e3ada0360f995358e40094392cd9b492`.

Use a full-history checkout at that commit. Scripts require Node, Python 3, and (for UI tests) Playwright plus Chromium. Print verification uses PyMuPDF and Python-Markdown. Paths below assume this extracted directory is the working directory and `REPO` is the absolute path to the checkout. Chromium is supplied with `DS_AUDIT_CHROMIUM`. No simulation jobs used the user's PC.

## Release and behavior

```sh
python3 "$REPO/source/build.py" --output rebuilt.html
cmp rebuilt.html "$REPO/Dominant_Species_Solo.html"
sha256sum rebuilt.html
node --test "$REPO/source/rules.test.cjs"
node "$REPO/source/benchmark.cjs" --selftest
node empty-earth.cjs "$REPO"
python3 run-browser.py "$REPO/source/browser_test.py"
python3 run-browser.py "$REPO/source/browser_restart_test.py"
python3 run-browser.py "$REPO/source/browser_game_test.py" paper=1 full 4 5
DS_AUDIT_REPO="$REPO" python3 browser-empty-earth.py
python3 verify-printables.py "$REPO" --rebuild
```

The custom UI test opens the tracked HTML offline at a 390-pixel viewport. It imports the original v0.5.0 turn-31 archive, enters the recorded physical supply through the controls, verifies Barren Earth Planning, then exports and reloads the opening round after one rival placement. Execution fixtures exercise preview/apply, reload, Undo/redo and export/import in v0.5.0, v0.4.1 and v0.3.9 saves. The v0.4.1/v0.3.9 fixtures are constructed empty positions from those releases' constructors, preserving cube conservation. The execution-stage v0.5.0 fixture is derived from the archived position. The original archive itself is an actual prior benchmark save.

`empty-earth.json` records boundary assertions including one surviving human or rival cube, empty box, occupied corner, all corners occupied, and changes between Planning and Execution. Old saves retain their saved offsets, names, Planning and cone rules. Empty Earth is intentionally applied to all Paper saves.

## E1 — printed corner order differs from the app

Import `saves/v050-empty-abundance.json` in the shipped HTML. Click **Show Mammals move**, then **Applied · Continue**. The preview and result put Grub from Abundance position 2 at **A1 corner 1**, shared by A1/B1/B2 (`-7,-3`). The board is empty of species and disks. A1 corners 5 and 6 (`-10,-4`, `-8,-4`) are both strictly above and left of that choice. Neither is excluded by the rules.

The rulebook's Execution Abundance row (page 4; source `source/paper/RULES.md:86`) says “top-left first.” `paper.js:162` selects `empty[0]`, inherited from insertion order, without a geometric sort. `rules.test.cjs:639` assumes the first stored corner means top-left.

```sh
# This assertion intentionally FAILS on the pinned release.
node empty-earth.cjs "$REPO" --assert-top-left

# Scratch-only proposal. Does not edit the checkout.
node top-left-prototype.cjs "$REPO"
```

The proposed convention is **uppermost eligible corner, then leftmost**. Numeric coordinate sorting gives C1 corner 5 (`-4,-6`) in this position and skips it after it is occupied. Continuing the original turn-31 game with this proposal finishes at turn 33. The shipped recovery finishes at turn 37. This is a tested proposal, not a release change or a new difficulty calibration. Reuse the explicit convention in Habitat's equivalent fallback and document it before release.

## Known stalled seeds and the archived game

```sh
node benchmarks/recovery.cjs "$REPO"
```

`recovery.json` records both rules on seed 200074 (Birds, five rivals, Standard, expansion, short), 3880523955 (Insects, five, Easy, majority, full), and 3722144011 (Birds, five, Easy, majority, short). They finish under v0.5.1 on turns 9, 10 and 18 respectively. It also records the complementary deck lengths for the latter two seeds. The original turn-31 archive reaches Ice Age on turn 37 with the released code. Diagnostic continuations allow 120 turns, while the ordinary benchmark runs retain the release's 30-turn cap.

## Benchmark fixes

```sh
python3 benchmark-fixes.py "$REPO"
```

B1 rejects duplicate rival counts and normalized mode aliases before reporting any games. The ordinary two-game Easy command still reports 1/2. B2 reports the three-rival subset's +0.29 and marks X35 unavailable because four and five are absent. Duplicate Paper or App rows fail. The complete old fresh sample produces byte-identical output under old and new helpers. Its rounded-input output is +0.18; the previous audit's exact-count value was +0.186 (reported +0.19). The release-form inputs in this bundle are that prior sample, not the new fresh run.

## Full ladder and fresh Hard/App comparison

```sh
node benchmarks/ladder-replay.cjs "$REPO" 5
node benchmarks/fresh.cjs "$REPO" 10
python3 benchmarks/fresh-summary.py
python3 verify-metric.py "$REPO"
```

The ladder replay runs all 7,200 distinct released-table games, plus all 5,760 Paper games under the actual v0.5.0 engine at `c19e382079a3d118729b49f5d25b9f9eb04de942`. Every game's returned decision trace and outcome are hashed. Changed games retain their first different event and both results. This is stronger than comparing only rounded win percentages. It uses the release's block 200000 and repeats 2/2/4/20 by rival count, yielding 360 games per table cell. Detailed results and summary are `published-results.json` and `published-summary.json`.

The fresh comparison freezes 360 setups for each of two, three, four and five rivals, with seeds 912000–912359, 913000–913359, 914000–914359 and 915000–915359. Five policies (dominance, majority, expansion, tuned v3 and tuned v4) play each setup against App and Hard 0. Total is 14,400 games, 360 per policy/mode/count cell. Animal combinations and full/short decks are balanced. Opening supply is asserted equal across each matched set. Later draws may diverge when decisions change. No weights are fitted on this sample.

The log-odds metric follows `source/benchmark/balance/final_eval.py`: tuned v4's edge over the best fixed policy at Hard, minus the better App edge of v3 or v4, calculated separately for each rival count. X35 is the equal-weight mean over counts 3, 4 and 5. Exact win counts are used before rounding. Approximate 95% intervals bootstrap whole matched setups within count, recomputing the best fixed and App comparator on each of 3,000 resamples. These intervals measure variation across this tested setup mix, not uncertainty over all possible human strategies. `verify-metric.py` exports this sample into `fresh-release-form-hard.json` and `fresh-release-form-app.json`, runs the repository's helper, and checks that its displayed values agree with the independent calculation.

## Coverage limits

This is a targeted release audit using the rendered 11-page rulebook, both columns of six card sheets, shipped controls and reproducible scripted games. All 48 numbered Paper faces are checked against their source actions. It is not a new exhaustive review of every base-game card, a human tabletop playtest, a new tuner training run, or Android hardware testing. The frozen player helpers and simulation engine are shared code, so simulations cannot independently establish every base-game rule. The report distinguishes the confirmed corner mismatch from proposed wording and from measured balance uncertainty.

GMT's original-game third-printing Living Rules (2012), page 11, allow Abundance on any vacant Earth corner, including perimeter corners. The Paper restriction and Empty Earth exception are bot selection rules. Publisher source: <https://www.gmtgames.com/living_rules/DS3_Rulebook-web_FINAL.pdf>.

Verify the extracted evidence with `sha256sum -c SHA256SUMS.txt`. Browser screenshots and browser binaries are omitted from the delivered bundle. The source checkout is obtained from the repository.
