# Dominant Species Solo v1.0.0 audit evidence

Release `6a9e7fba95c113d2017b45bbf494de985f26bac8`. Baseline `ffa795b14d3618864345c520549d1120c7d3987b` (v0.5.7).

## Reproduce Aquatic in the app

1. Open `Dominant_Species_Solo.html` from the audited release in Chromium.
2. Import `fixtures/aquatic-seed-731290.json`. This opens Amphibians' Aquatic effect on turn 5 of a four-rival Expert game. There are zero Amphibian cubes left in the gene pool.
3. Select **Show Amphibians move**. The app puts Water on D5 Wetland, changing the C5 and D5 dominance cones. The rulebook priorities put Water on C1 Sea. Zero additions leave all ranks unchanged, and Sea has the higher first-place value.
4. Repeat with `fixtures/aquatic-seed-731260.json` if you want to check the board-order tie. The app puts Water on B5 Sea. The printed rule chooses A2 Sea at the same value.

`logs/aquatic-detail.json` gives the candidates, the expected and actual corner, and the cone changes in both versions. The two fixture files came directly from independently seeded games. Importing a save replaces the game in the open tab.

## Re-run the checks

Use a clone with both commits in its history. The indicated release should be checked out for the repository suites. Node 24.22.1, Python 3.12, Playwright and Chromium 146.0.7680.31 were used for this audit. The print checks also use PyMuPDF, pypdf and Markdown.

```sh
node scripts/compare-release.cjs /path/to/repo ./new-run
node scripts/verify-aquatic.cjs /path/to/repo ./fixtures
python3 scripts/check-browser-release.py /path/to/v0.5.7/Dominant_Species_Solo.html /path/to/v1.0.0/Dominant_Species_Solo.html ./fixtures /path/to/chromium
```

From the checked-out release repository:

```sh
node --test source/rules.test.cjs
node source/smoke.cjs --check
node source/redqueen_fuzz.cjs 10 912700
python3 source/build.py --output /tmp/DS_v1_audit_rebuilt.html
cmp Dominant_Species_Solo.html /tmp/DS_v1_audit_rebuilt.html
python3 source/paper/verify-printables.py --rebuild-pdfs --output-dir /tmp/DS_v1_audit_print
python3 source/paper/check_print_fit.py
```

`scripts/use-system-chromium.py` can run a repository test with a specified Chromium instead of the Playwright default. Set `DS_AUDIT_CHROMIUM` to that executable. `verify-printables.py` also reads that variable on its own.

`runs/release-comparison.json` records the 120 game pairs and their settings. Each turn uses the same seeded physical draws and a fixed reference player policy on both builds. The three policies prioritize majorities, dominance or expansion. The release comparison verifies all decisions and serialized states with the version field set aside. Replays of 16 old guided checkpoints start during the opening rival placements. The 160 separate stress games use the repository's erratic player.

## Sources

- [Audited GitHub commit](https://github.com/ramyahoo88/dominant-species-solo/commit/6a9e7fba95c113d2017b45bbf494de985f26bac8)
- [The Red Queen rulebook](https://github.com/ramyahoo88/dominant-species-solo/blob/6a9e7fba95c113d2017b45bbf494de985f26bac8/paper/The_Red_Queen_Rulebook.md)
- [GMT Living Rules](https://www.gmtgames.com/living_rules/DS3_Rulebook-web_FINAL.pdf)
- [Dominant Species Vassal module 5.2](https://vassalengine.org/library/projects/Dominant_Species)
