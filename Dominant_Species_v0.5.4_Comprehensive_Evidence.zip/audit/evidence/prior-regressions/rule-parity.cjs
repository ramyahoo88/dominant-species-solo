const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
const repo=path.resolve(process.argv[2]||'../dominant-species-solo');
const {load,PLAYER_REFERENCE}=require(path.join(repo,'source/benchmark/load.cjs'));
const rt=load('worktree',['game']);rt.get('globalThis').assert=assert;
const result=rt.run(`(() => {
 const out={migration:{positions:0,actors:0,allowed:0,blocked:0},ties:{cases:0},cards:[],emptyEarth:[],saves:{}};
 let rng=114054;const random=()=>{rng=(Math.imul(rng,1664525)+1013904223)>>>0;return rng/4294967296;};
 const take=a=>a[Math.floor(random()*a.length)];
 const base=(h='birds',r=['mammals','insects'])=>newGame(h,r,false,114054,{extra:0});
 const clear=s=>{for(const t of terrainIds(s))for(const id of s.ids)removeCube(s,t,id,s.tiles[t].cubes[id],'pool');};
 const rankOn=(s,t,a)=>Object.entries(s.tiles[t].cubes).filter(([,n])=>n>0).sort(([a,x],[b,y])=>y-x||FOOD.indexOf(a)-FOOD.indexOf(b)).findIndex(([id])=>id===a);
 // Independent translation of the printed first-move rule. It does not call any paper chooser.
 function allowed(s,a) {
   const choices=[];
   for(const from of terrainIds(s)) {
     const count=s.tiles[from].cubes[a];if(!count)continue;
     const rescue=match(s,from,a)===0;
     if(!rescue) {
       if(count<2)continue;
       const before=rankOn(s,from,a);s.tiles[from].cubes[a]--;const after=rankOn(s,from,a);s.tiles[from].cubes[a]++;
       if(after<0||after>before)continue;
     }
     const one=NEIGHBORS[from].filter(t=>s.tiles[t]);
     const dest=new Set(one);
     if(a==='birds')for(const mid of one)for(const t of NEIGHBORS[mid])if(t!==from&&s.tiles[t])dest.add(t);
     for(const to of dest)if(match(s,to,a)>0&&(rescue||!s.tiles[to].cubes[a]))choices.push({from,to,rescue,count});
   }
   return choices;
 }
 for(let n=0;n<300;n++) {
   const h=FOOD[n%6],r=FOOD.filter(x=>x!==h).slice(0,2+n%4),s=base(h,r);clear(s);s.corners={};
   for(const k of activeCorners(s))if(random()<.3)s.corners[k]=take(ELEMENT_IDS);
   for(const a of s.ids)for(let i=0;i<12;i++)addCube(s,take(terrainIds(s)),a,1);
   validateState(s);out.migration.positions++;
   for(const a of r) {
     const before=JSON.stringify(s),opts=allowed(s,a),planned=paperLegal(s,a,'migration',0),first=paperMigration(s,a,1);
     assert.equal(planned,opts.length>0);assert.equal(first.moves.length>0,opts.length>0);
     assert.equal(JSON.stringify(s),before,'Migration preview must not change the state');
     if(first.moves.length)assert(opts.some(o=>o.from===first.moves[0].from&&o.to===first.moves[0].to));
     out.migration.actors++;out.migration[planned?'allowed':'blocked']++;
   }
 }
 // Match priority, species priority, food chain, human ties, zero matches and absent animals.
 for(const h of FOOD) {
   const s=base(h,FOOD.filter(x=>x!==h));clear(s);const t='D3';
   for(let k=0;k<250;k++) {
     clear(s);s.corners={};for(const v of VERTICES_OF[t].slice(0,k%5))s.corners[v]=ANIMALS[h].el;
     for(const a of s.ids){s.animals[a].added=Array(k%3).fill(ANIMALS[a].el);addCube(s,t,a,Math.floor(random()*5));}
     validateState(s);
     const vals=s.ids.filter(a=>s.tiles[t].cubes[a]>0).map(a=>({a,m:match(s,t,a),n:s.tiles[t].cubes[a]}));
     const max=Math.max(0,...vals.map(x=>x.m)),leaders=vals.filter(x=>x.m===max);
     let expected=null;
     if(max>0&&leaders.length===1)expected=leaders[0].a;
     else if(max>0&&leaders.every(x=>x.a!==h))expected=leaders.sort((x,y)=>y.n-x.n||FOOD.indexOf(x.a)-FOOD.indexOf(y.a))[0]?.a??null;
     assert.equal(cone(s,t),expected);out.ties.cases++;
   }
 }
 const cardTest=(label,card,mutate,skip)=>{
   const s=base();mutate(s);validateState(s);
   assert.equal(paperCardIdle(s,'mammals',card),skip,label);
   const fallback=card==='Niche Biomes'?'Ice Age':'Fertile';s.market=[card,fallback,null,null,null];
   const choice=paperClaim(s,'mammals','E4').card;
   const expected=skip?fallback:card;assert.equal(choice,expected,label);
   out.cards.push({label,card,skip,choice});
 };
 cardTest('no added element','Metamorphosis',()=>{},true);
 cardTest('added element and bag','Metamorphosis',s=>s.animals.mammals.added=['sun'],false);
 cardTest('equal element counts','Disease',s=>{s.animals.mammals.added=['sun'];s.animals.insects.added=['grass'];},true);
 cardTest('opponent has more and an added disk','Disease',s=>s.animals.insects.added=['grass'],false);
 cardTest('nobody ahead on VP','Niche Biomes',()=>{},true);
 cardTest('opponent ahead on VP','Niche Biomes',s=>s.animals.insects.vp=1,false);
 cardTest('first on track','Nocturnal',s=>s.initiative=['mammals','birds','insects'],true);
 cardTest('not first on track','Nocturnal',s=>s.initiative=['birds','mammals','insects'],false);
 cardTest('no eliminated species','Hibernation',()=>{},true);
 cardTest('one eliminated species','Hibernation',s=>{s.animals.mammals.pool--;s.animals.mammals.dead++;},false);
 // Amphibians' extra printed Water does not make Disease useful when no added disk can be removed.
 const d=base('birds',['mammals','amphibians']);assert.equal(paperCardIdle(d,'mammals','Disease'),true);
 d.animals.amphibians.added=['water'];assert.equal(paperCardIdle(d,'mammals','Disease'),false);
 out.cards.push({label:'Amphibian printed versus removable elements',pass:true});
 // Deplete the physical bag without inventing disks: 31 tiles, normal tile mix, 20 of each element.
 const emptyBag=base('birds',FOOD.filter(a=>a!=='birds'));clear(emptyBag);emptyBag.corners={};
 for(const terrain of DRAW_TERRAIN){const t=frontTiles(emptyBag)[0];emptyBag.tiles[t]={terrain,cubes:Object.fromEntries(emptyBag.ids.map(a=>[a,0]))};}
 emptyBag.stacks=Array.from({length:3},()=>({left:0,face:null}));
 const supply=ELEMENT_IDS.flatMap(t=>Array(20).fill(t));
 for(const a of emptyBag.ids)emptyBag.animals[a].added=Array.from({length:6-ANIMALS[a].affinity},()=>supply.shift());
 for(const row of elementRows)emptyBag.boxes[row]=Array.from({length:4},()=>supply.shift());
 for(const k of activeCorners(emptyBag))if(supply.length)emptyBag.corners[k]=supply.shift();
 assert.equal(supply.length,0);validateState(emptyBag);assert.equal(elementOptions(emptyBag).length,0);
 assert.equal(paperCardIdle(emptyBag,'mammals','Metamorphosis'),true);
 emptyBag.market=['Metamorphosis','Fertile',null,null,null];assert.equal(paperClaim(emptyBag,'mammals','D3').card,'Fertile');
 delete emptyBag.corners[Object.keys(emptyBag.corners).at(-1)];validateState(emptyBag);
 assert.equal(paperCardIdle(emptyBag,'mammals','Metamorphosis'),false);
 out.cards.push({label:'empty bag versus one returned physical disk',pass:true});
 const all=base();all.initiative=['mammals','birds','insects'];all.market=['Hibernation','Nocturnal','Niche Biomes','Disease','Metamorphosis'];
 assert.equal(paperClaim(all,'mammals','E4').card,'Metamorphosis');out.cards.push({label:'all five skipped: priority list, not market order',choice:'Metamorphosis'});
 // Claim happens AFTER scoring; Niche Biomes must use the new VP total.
 const n=base();clear(n);addCube(n,'E4','mammals',1);n.corners={[VERTICES_OF.E4[0]]:'meat'};
 n.phase='execution';n.cursor=EXECUTION.indexOf('domination-0');n.pawns['domination-0']={actor:'mammals',card:null,focus:null};
 n.market=['Niche Biomes','Ice Age',null,null,null];n.animals.insects.vp=3;
 assert.equal(paperCardIdle(n,'mammals','Niche Biomes'),false);
 runStep(n,nextStep(n),{tile:'E4'});const claim=nextStep(n);assert.equal(claim.kind,'claim');
 assert.equal(n.animals.mammals.vp,4);assert.equal(botAction(n,claim).card,'Ice Age');validateState(n);
 out.cards.push({label:'Niche Biomes checks VP after scoring',vp:n.animals.mammals.vp,choice:'Ice Age'});
 // Empty Earth applies even with a surviving player, and is global (not one eliminated rival).
 for(const legacy of [false,true])for(const kind of ['empty','human-only','one-rival']) {
   const s=base('mammals',['birds','insects']);clear(s);s.corners={};s.turn=3;
   if(legacy){s.version='0.5.3';delete s.paper.speciesTie;}
   if(kind!=='empty')addCube(s,'D3','mammals',1);
   if(kind==='one-rival')addCube(s,'D3','insects',1);
   s.boxes.abundance=['water',null,null,null];s.phase='execution';s.cursor=EXECUTION.indexOf('abundance-0');
   s.pawns['abundance-0']={actor:'birds',card:null,focus:null};validateState(s);
   const expected=kind!=='one-rival';assert.equal(paperEmptyEarth(s),expected);
   assert.equal(paperLegal(s,'birds','abundance',0),expected);
   const c=botAction(s,nextStep(s));if(expected){assert.equal(c.corner,pBoardOrder(activeCorners(s))[0]);const after=copy(s);runStep(after,nextStep(after),c);validateState(after);}
   out.emptyEarth.push({legacy,kind,enabled:expected,choice:c});
   if(kind==='human-only')out.saves['empty-earth-'+(legacy?'legacy':'new')]={format:SAVE_KEY,game:s};
 }
 // A real pre-claim fixture distinguishes new and saved dominance rules.
 const s=base();clear(s);s.corners={[VERTICES_OF.E4[0]]:'sun'};addCube(s,'E4','mammals',1);addCube(s,'E4','insects',2);
 s.turn=3;s.phase='execution';s.cursor=EXECUTION.indexOf('domination-0');s.pawns['domination-0']={actor:'mammals',card:null,focus:null};
 s.market=['Fertile',null,null,null,null];validateState(s);
 assert.equal(cone(s,'E4'),'insects');out.saves['species-tie-new']={format:SAVE_KEY,game:copy(s)};
 delete s.paper.speciesTie;s.version='0.5.3';out.saves['species-tie-legacy']={format:SAVE_KEY,game:copy(s)};
 validateState(s);assert.equal(cone(s,'E4'),'mammals');
 return out;
})()`);
// Load genuine historical newGame outputs, rather than relabeling new states.
result.history=[];
for(const ref of ['ab9acc8','4ac6bd8','d84e7e9','24d8b5f','dec3a3b','db81d8d','e5ecc40']){
 const old=load(ref,['game']);
 const s=old.run("newGame('amphibians',['mammals','reptiles','birds','arachnids','insects'],false,114054,{extra:"+(ref==='ab9acc8'||ref==='4ac6bd8'?'0':ref==='d84e7e9'?'-1':'-2')+"})");
 const original=JSON.parse(JSON.stringify(s));rt.get('globalThis').legacy=s;
 const imported=rt.run('validateState(legacy)');
 for(const key of ['rivalTie','planFirst','speciesTie','scaledEasy'])assert.equal(imported.paper[key],original.paper[key]);
 assert.deepEqual(JSON.parse(JSON.stringify(imported.animals)),original.animals);
 const once=JSON.stringify(imported);rt.get('globalThis').legacy=JSON.parse(once);rt.run('validateState(legacy)');assert.equal(JSON.stringify(rt.get('legacy')),once);
 const name='legacy-'+original.version.replaceAll('.','');result.saves[name]={format:'dominant-species-solo-v1',game:original};
 const universalRules=rt.run(`(()=>{
   const s=copy(legacy);for(const t of terrainIds(s))for(const a of s.ids)removeCube(s,t,a,s.tiles[t].cubes[a],'pool');
   s.turn=3;s.corners={[VERTICES_OF.C4[0]]:'water',[VERTICES_OF.D4[0]]:'water'};addCube(s,'C4','birds',1);
   assert.equal(paperLegal(s,'birds','migration',0),false);PAPER.oldMigTest=true;assert.equal(paperLegal(s,'birds','migration',0),true);delete PAPER.oldMigTest;
   s.market=['Metamorphosis','Fertile',null,null,null];assert.equal(paperClaim(s,'birds','C4').card,'Fertile');
   removeCube(s,'C4','birds',1,'pool');addCube(s,'D3',s.human,1);assert.equal(paperEmptyEarth(s),true);validateState(s);
   return {migration:true,cardSkips:true,emptyEarth:true};
 })()`);
 result.history.push({ref,version:original.version,originalRules:original.paper,importedRules:JSON.parse(JSON.stringify(imported.paper)),player:imported.animals[imported.human].ap,rival:imported.animals[imported.rivals[0]].ap,universalRules});
}
for(const [name,value]of Object.entries(result.saves))fs.writeFileSync(path.join(__dirname,'saves',name+'.json'),JSON.stringify(value)+'\n');
delete result.saves;
fs.writeFileSync(path.join(__dirname,'rule-parity.json'),JSON.stringify(result,null,2)+'\n');
console.log(JSON.stringify(result,null,2));
